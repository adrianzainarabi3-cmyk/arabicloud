'use strict';
// ===== ArabiCloud v2.1 Frontend =====
const $ = (s,r=document) => r.querySelector(s);
const $$ = (s,r=document) => [...r.querySelectorAll(s)];
const esc = v => String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const GIB=1024**3, MIB=1024**2;
const ls={get:k=>{try{return localStorage.getItem(k);}catch{return null;}},set:(k,v)=>{try{localStorage.setItem(k,v);}catch{}}};

// ===== STATE =====
const S={
  config:{},user:null,csrf:'',view:'dashboard',
  entries:[],parent:null,search:'',layout:ls.get('ac-layout')||'list',
  workloads:[],jobs:[],nodes:[],adminUsers:[],adminOverview:null,
  localNode:null,detectionRunning:false,nasList:[],nasMachines:[],currentMachine:null,nasParent:null,
  generation:0,
};

// ===== ICONS =====
const I={
  server:'M4 5h16v4H4zm0 10h16v4H4zm3-7.5h.01M3 12h18M7 17.5h.01',
  container:'M3 4h18v7H3zm0 9h18v7H3zM8 4v7m8-7v7M8 13v7m8-7v7',
  cpu:'M9 3H7a2 2 0 0 0-2 2v2m4-4h6m-6 0v18m6-18v18M15 3h2a2 2 0 0 1 2 2v2M5 9H3m0 6h2M21 9h-2m2 6h-2M7 21H5a2 2 0 0 1-2-2v-2m14 4h2a2 2 0 0 0 2-2v-2',
  ram:'M2 6h20v12H2zm4 0v12M12 6v12M18 6v12M6 10h2m4 0h2m4 0h2M6 14h2m4 0h2m4 0h2',
  disk:'M2 7h20v10H2zM6 11h.01M6 15h.01M10 11h8M10 15h4',
  network:'M4 6h16M4 12h16M4 18h16',
  dashboard:'M3 3h8v8H3zm10 0h8v8h-8zM3 13h8v8H3zm10 5h8m-4-4v8',
  users:'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M10 7a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm7.5-1A3.5 3.5 0 1 1 21 9.5M23 21v-2a4 4 0 0 0-3-3.87',
  settings:'m9 3-1 2.5-2.5 1L3 8l2.5 2.5L6 13h6l.5-2.5L15 8l-2.5-2-1-2.5H9zm7 9a4 4 0 1 1-8 0 4 4 0 0 1 8 0z',
  file:'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6',
  folder:'M3 7V5h6l2 2h10v14H3V7z',
  plus:'M12 5v14M5 12h14',
  close:'m6 6 12 12M6 18 18 6',
  check:'m5 12 4 4L19 6',
  chevron:'m9 5 7 7-7 7',
  search:'M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z',
  eye:'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zm13 0a3 3 0 1 1-6 0 3 3 0 0 1 6 0z',
  eyeOff:'M17.94 17.94A10 10 0 0 1 12 19c-7 0-11-7-11-7a18.06 18.06 0 0 1 5.06-5.94M9.9 4.24A9 9 0 0 1 12 4c7 0 11 7 11 7a18 18 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24M1 1l22 22',
  upload:'M12 16V3m-5 5 5-5 5 5M4 15v6h16v-6',
  download:'M12 3v13m-5-5 5 5 5-5M4 16v5h16v-5',
  trash:'M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7',
  edit:'m15 3 6 6-12 12H3v-6z',
  logout:'M9 21H3V3h6M8 12h13m-5-5 5 5-5 5',
  power:'M18.36 6.64a9 9 0 1 1-12.73 0M12 2v10',
  play:'M5 3l14 9-14 9V3z',
  stop:'M5 5h14v14H5z',
  restart:'M1 4v6h6M23 20v-6h-6M20.49 9A9 9 0 0 0 5.64 5.64L1 10M23 14l-4.64 4.36A9 9 0 0 1 3.51 15',
  info:'M12 2a10 10 0 1 0 0 20A10 10 0 0 0 12 2zm0 7v4m0 4h.01',
  alert:'M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0zM12 9v4m0 4h.01',
  shield:'m12 3 8 4v5c0 5-8 9-8 9S4 17 4 12V7z',
  activity:'M3 12h4l3-8 4 16 3-8h4',
  clock:'M12 8v4l3 3M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0z',
  menu:'M3 6h18M3 12h18M3 18h18',
  image:'M3 4h18v16H3V4zm0 12 5-5 4 4 3-3 6 6M16 8h.01',
  archive:'M4 3h16v4H4zm1 4h14v13H5z',
  video:'M3 5h13v14H3V5zm13 5 5-3v10l-5-3',
  storage:'M3 4h18v4H3zm0 8h18v4H3zm0 8h18v4H3z',
  key:'M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0 3 3L22 7l-3-3m-3.5 3.5L19 4',
  globe:'M12 2a10 10 0 1 0 0 20A10 10 0 0 0 12 2zM2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z',
  box:'M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z',
  terminal:'M4 4h16v16H4zm3.5 6.5 3 3-3 3m5 0h3',
  heartbeat:'M3 12h4l3-8 4 16 3-8h4',
  sun:'M12 3v1m0 16v1M3 12h1m16 0h1M5.6 5.6l.7.7m11.4 11.4.7.7m0-12.8-.7.7M6.3 17.7l-.7.7M16 12a4 4 0 1 1-8 0 4 4 0 0 1 8 0z',
  moon:'M20.9 13A9 9 0 0 1 11 3.1 9 9 0 1 0 20.9 13z',
  nas:'M3 3h18v4H3zm0 7h18v4H3zm0 7h18v4H3zM7 5h.01M7 12h.01M7 19h.01',
  layers:'M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5',
  radar:'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 0v10m0 0 7-7',
  refresh:'M23 4v6h-6M1 20v-6h6M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15',
};
const ic=(n,c='')=>`<svg class="${c}" viewBox="0 0 24 24" aria-hidden="true"><path d="${I[n]||I.file}"/></svg>`;
const ibtn=(action,icon,title,cls='')=>`<button type="button" class="icon-btn ${cls}" data-action="${action}" title="${esc(title)}">${ic(icon)}</button>`;

// ===== API =====
async function api(route,opts={}){
  const headers={...opts.headers};
  if(opts.body&&typeof opts.body!=='string'){opts.body=JSON.stringify(opts.body);headers['Content-Type']='application/json';}
  if(opts.method&&opts.method!=='GET')headers['X-CSRF-Token']=S.csrf;
  const res=await fetch(route,{...opts,headers,credentials:'same-origin'});
  let data;
  try{data=await res.json();}catch{throw Object.assign(new Error('Unexpected server response.'),{status:res.status});}
  if(!res.ok){
    if(res.status===401&&S.user){S.user=null;renderAuth();}
    throw Object.assign(new Error(data.error||'Request failed.'),{status:res.status});
  }
  return data;
}

// ===== TOAST =====
function toast(msg,type=''){
  const div=document.createElement('div');
  div.className=`toast${type?' '+type:''}`;
  div.textContent=msg;
  $('#toast').append(div);
  setTimeout(()=>div.remove(),4500);
}

// ===== MODALS =====
let _modalClose=null;
function modal(title,body,actions='',size=''){
  closeModal();
  const el=document.createElement('div');
  el.className='modal-backdrop';
  el.id='active-modal';
  el.innerHTML=`<div class="modal${size?' '+size:''}" role="dialog" aria-modal="true">
    <div class="modal-header"><h2>${esc(title)}</h2>${ibtn('close-modal','close','Close')}</div>
    <div id="modal-body">${body}</div>
    ${actions?`<div class="modal-actions">${actions}</div>`:''}
  </div>`;
  document.body.append(el);
  el.querySelector('.modal input,button')?.focus();
  const trap=e=>{if(e.key==='Escape')closeModal();};
  document.addEventListener('keydown',trap);
  _modalClose=()=>document.removeEventListener('keydown',trap);
  return el;
}
function closeModal(){
  if(_modalClose){_modalClose();_modalClose=null;}
  document.querySelectorAll('.modal-backdrop').forEach(el=>el.remove());
}
function modalError(msg){
  let err=$('#active-modal .modal-error');
  if(!err){err=document.createElement('div');err.className='modal-error';$('#active-modal #modal-body').append(err);}
  err.textContent=msg;err.scrollIntoView({block:'nearest'});
}
function modalSuccess(msg){
  let s=$('#active-modal .modal-success');
  if(!s){s=document.createElement('div');s.className='modal-success';$('#active-modal #modal-body').append(s);}
  s.textContent=msg;
}

// ===== UTILS =====
const fmtSize=b=>{if(!b)return'0 B';const u=['B','KB','MB','GB','TB'],n=Math.min(Math.floor(Math.log(b)/Math.log(1024)),4);return`${(b/1024**n).toFixed(n>1?1:0)} ${u[n]}`;};
const fmtDate=v=>v?new Date(v).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'}):'—';
const fmtDateTime=v=>v?new Date(v).toLocaleString(undefined,{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}):'—';
const fmtAge=v=>{if(!v)return'—';const s=(Date.now()-v)/1000;if(s<60)return'just now';if(s<3600)return`${Math.floor(s/60)}m ago`;if(s<86400)return`${Math.floor(s/3600)}h ago`;return fmtDate(v);};
const fmtMB=mb=>mb>=1024?`${(mb/1024).toFixed(1)} GB`:`${mb} MB`;
const pct=(u,t)=>t>0?Math.min(100,Math.round(u/t*100)):0;
const barClass=p=>p>=85?'high':p>=65?'med':'low';
const badge=(label,cls)=>`<span class="badge ${cls}">${esc(label)}</span>`;
const statusBadge=s=>{
  const dot=`<span class="badge-dot${['running','ready','connected','online'].includes(s)?' pulse':''}"></span>`;
  return`<span class="badge ${s}">${dot}${esc(s)}</span>`;
};
const roleBadge=r=>badge(r,r);

function applyBrand(){
  const c=S.config;
  document.title=c.siteName||'ArabiCloud';
  document.documentElement.style.setProperty('--accent',c.accent||'#6366f1');
  document.documentElement.style.setProperty('--accent-soft',`${c.accent||'#6366f1'}18`);
  $('#favicon').href=c.favicon||'/mark.svg';
  $$('[data-brand-name]').forEach(el=>el.textContent=c.siteName||'ArabiCloud');
  $$('[data-brand-logo]').forEach(el=>{el.src=c.logo||'/mark.svg';});
}

// ===== SIDEBAR =====
function renderSidebar(){
  const u=S.user;
  const isAdmin=u&&['admin','owner'].includes(u.role);
  const pending=S.jobs.filter(j=>['queued','running'].includes(j.status)).length;
  const nav=[
    {id:'dashboard',icon:'dashboard',label:'Dashboard'},
    {id:'containers',icon:'container',label:'Containers',badge:S.workloads.filter(w=>w.workloadType==='container'&&w.status!=='deleted').length||''},
    {id:'nas',icon:'nas',label:'NAS & Storage'},
    {id:'storage',icon:'storage',label:'File Storage'},
    '---',
    {id:'jobs',icon:'activity',label:'Jobs',badge:pending||''},
    {id:'settings-account',icon:'settings',label:'Account'},
    ...isAdmin?[
      '---admin',
      {id:'admin-nodes',icon:'server',label:'Nodes'},
      {id:'admin-users',icon:'users',label:'Users'},
      {id:'admin-workloads',icon:'box',label:'Workloads'},
      {id:'admin-jobs',icon:'heartbeat',label:'All Jobs'},
      {id:'admin-nas',icon:'nas',label:'NAS Servers'},
      {id:'admin-settings',icon:'settings',label:'Settings'},
    ]:[],
  ];
  const sb=document.createElement('aside');
  sb.className='sidebar';sb.id='sidebar';
  sb.innerHTML=`
    <div class="brand">
      <img data-brand-logo src="${esc(S.config.logo||'/mark.svg')}" alt="">
      <span data-brand-name>${esc(S.config.siteName||'ArabiCloud')}</span>
    </div>
    <nav class="nav" id="main-nav">
      ${nav.map(n=>{
        if(n==='---')return'<div class="nav-divider"></div>';
        if(n==='---admin')return`<div class="nav-divider"></div><div class="nav-label">Administration</div>`;
        return`<button data-view="${n.id}" class="${S.view===n.id?'active':''}" type="button">
          ${ic(n.icon)} ${esc(n.label)}
          ${n.badge?`<span class="badge-count">${n.badge}</span>`:''}
        </button>`;
      }).join('')}
    </nav>
    <div class="sidebar-footer">
      <div class="sidebar-user">
        <div class="avatar ${u?.role||''}">${(u?.displayName||u?.username||'?').slice(0,2).toUpperCase()}</div>
        <div class="sidebar-user-info">
          <strong>${esc(u?.displayName||u?.username||'')}</strong>
          <small>${esc(u?.role||'')}</small>
        </div>
        ${ibtn('logout','logout','Sign out')}
      </div>
    </div>
  `;
  return sb;
}

// ===== MAIN RENDER =====
function renderApp(){
  S.generation++;
  const app=$('#app');
  app.innerHTML=`
    <div id="screen-shade" class="screen-shade" data-action="close-sidebar"></div>
    <div id="sidebar-mount"></div>
    <main class="workspace">
      <header class="topbar">
        <div class="topbar-left">
          <button class="mobile-menu-btn icon-btn" data-action="toggle-sidebar">${ic('menu')}</button>
          <div class="topbar-title" id="topbar-title">${esc(viewTitle(S.view))}</div>
        </div>
        <div class="topbar-right">
          <button class="icon-btn" data-action="appearance" title="Change theme">${ic(window.JTGTheme?.theme==='dark'?'moon':'sun')}</button>
          <div class="topbar-sep"></div>
          ${ibtn('logout','logout','Sign out')}
        </div>
      </header>
      <div class="content" id="main-content"></div>
    </main>
  `;
  $('#sidebar-mount').replaceWith(renderSidebar());
  // Restore desktop sidebar collapsed state
  if(window.innerWidth>680&&ls.get('ac-sidebar-collapsed')==='1'){
    $('#sidebar')?.classList.add('collapsed');
    $('.workspace')?.classList.add('sidebar-collapsed');
  }
  renderView();
  applyBrand();
}

const viewTitle=v=>({
  dashboard:'Dashboard',containers:'Containers',vps:'VPS Instances',
  storage:'Storage',nas:'NAS & Storage',jobs:'Jobs',
  'settings-account':'Account Settings',
  'admin-nodes':'Nodes','admin-users':'User Management',
  'admin-workloads':'All Workloads','admin-jobs':'All Jobs',
  'admin-nas':'NAS Servers','admin-settings':'System Settings',
  'nas-machine':'NAS Machine',
}[v]||'ArabiCloud');

function navigate(view){
  S.view=view;
  $$('.sidebar .nav button').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
  const t=$('#topbar-title');if(t)t.textContent=viewTitle(view);
  renderView();
}

async function renderView(){
  const mc=$('#main-content');if(!mc)return;
  switch(S.view){
    case 'dashboard':return renderDashboard(mc);
    case 'containers':return renderWorkloads(mc,'container');
    case 'storage':return renderStorage(mc);
    case 'nas':return renderNASUser(mc);
    case 'jobs':return renderJobs(mc);
    case 'settings-account':return renderAccountSettings(mc);
    case 'admin-nodes':return renderAdminNodes(mc);
    case 'admin-users':return renderAdminUsers(mc);
    case 'admin-workloads':return renderAdminWorkloads(mc);
    case 'admin-jobs':return renderAdminJobs(mc);
    case 'admin-nas':return renderAdminNAS(mc);
    case 'admin-settings':return renderAdminSettings(mc);
    default:mc.innerHTML=`<div class="empty-state"><div class="empty-state-icon">${ic('info')}</div><h3>Coming soon</h3></div>`;
  }
}

// ===== DASHBOARD =====
async function renderDashboard(mc){
  mc.innerHTML=`<div class="skeleton skeleton-card mb"></div><div class="grid-2"><div class="skeleton skeleton-card"></div><div class="skeleton skeleton-card"></div></div>`;
  try{
    const [meData,wData,nasData]=await Promise.all([api('/api/me'),api('/api/workloads'),api('/api/admin/nas').catch(()=>({servers:[]}))]);
    S.csrf=meData.csrf;S.user=meData.user;S.workloads=wData.workloads||[];S.nasList=nasData.servers||[];
    const u=S.user;
    const containers=S.workloads.filter(w=>w.workloadType==='container');
    const running=S.workloads.filter(w=>w.status==='running');
    const sp=pct(u.used,u.quota);
    mc.innerHTML=`
      <div class="page-header">
        <div class="page-header-left">
          <h1>Welcome, ${esc(u.displayName||u.username)}</h1>
          <p>Infrastructure overview for ArabiCloud</p>
        </div>
        <div class="page-header-actions">
          <button class="btn sm" data-action="new-container">${ic('plus')} New Container</button>
        </div>
      </div>
      <div class="stats-grid">
        <div class="stat-card"><div class="stat-card-head"><div class="stat-card-icon green">${ic('activity')}</div></div><div class="stat-card-value">${running.length}</div><div class="stat-card-label">Running Workloads</div></div>
        <div class="stat-card"><div class="stat-card-head"><div class="stat-card-icon blue">${ic('container')}</div></div><div class="stat-card-value">${containers.length}</div><div class="stat-card-label">Containers</div></div>
        <div class="stat-card"><div class="stat-card-head"><div class="stat-card-icon purple">${ic('nas')}</div></div><div class="stat-card-value">${S.nasList.length||0}</div><div class="stat-card-label">NAS Servers</div></div>
        <div class="stat-card"><div class="stat-card-head"><div class="stat-card-icon orange">${ic('storage')}</div></div>
          <div class="stat-card-value">${sp}%</div><div class="stat-card-label">Storage Used</div>
          <div class="quota-bar"><div class="progress mt-sm"><i style="width:${sp}%;background:${sp>85?'var(--danger)':sp>65?'var(--warning)':'var(--success)'}"></i></div>
          <div class="progress-label"><span>${fmtSize(u.used)}</span><span>${fmtSize(u.quota)}</span></div></div>
        </div>
      </div>
      ${S.workloads.length?`
        <div class="panel">
          <div class="panel-header"><h2>Recent Workloads</h2><button class="btn soft sm" data-action="goto-containers">${ic('chevron')} View all</button></div>
          <div class="workload-grid" style="padding:16px">${S.workloads.slice(0,6).map(workloadCard).join('')}</div>
        </div>`:`
        <div class="panel">
          <div class="empty-state" style="min-height:200px">
            <div style="width:56px;height:56px;border-radius:14px;display:flex;align-items:center;justify-content:center;margin-bottom:16px;background:var(--accent-soft);color:var(--accent-text)">${ic('server')}</div>
            <h3 style="font-size:15px;margin-bottom:5px">No workloads yet</h3>
            <p style="font-size:12px;color:var(--muted);max-width:320px;line-height:1.7">Deploy your first container or VPS to get started.</p>
            <div class="flex" style="gap:10px;margin-top:16px">
              <button class="btn" data-action="new-container">${ic('container')} New Container</button>
            </div>
          </div>
        </div>`}
    `;
  }catch(e){mc.innerHTML=`<div class="notice error">${ic('alert')} Failed to load dashboard: ${esc(e.message)}</div>`;}
}

// ===== WORKLOAD CARD =====
function workloadCard(w){
  const isVps=w.workloadType==='vps';
  return`<div class="workload-card">
    <div class="workload-card-header">
      <div class="workload-icon ${isVps?'vps-type':'container-type'}">${ic(isVps?'server':'container')}</div>
      <div style="flex:1;min-width:0">
        <div class="workload-card-title">${esc(w.name)}</div>
        <div class="workload-card-sub">${esc(w.image||w.osTemplate||'')}</div>
      </div>
      ${statusBadge(w.status)}
    </div>
    <div class="workload-card-meta">
      <span class="workload-meta-item">${ic('cpu')} ${w.cpuAllocated}v</span>
      <span class="workload-meta-item">${ic('ram')} ${fmtMB(w.ramAllocated)}</span>
      <span class="workload-meta-item">${ic('disk')} ${w.diskAllocated}GB</span>
      ${w.ipAddress?`<span class="ip-chip">${esc(w.ipAddress)}</span>`:''}
    </div>
    <div class="workload-card-actions">
      ${w.status==='running'?`<button class="btn sm secondary" data-action="stop-workload" data-id="${esc(w.id)}">${ic('stop')} Stop</button>`:''}
      ${w.status==='stopped'?`<button class="btn sm success" data-action="start-workload" data-id="${esc(w.id)}">${ic('play')} Start</button>`:''}
      <button class="btn sm secondary" data-action="view-workload-logs" data-id="${esc(w.id)}" data-type="${esc(w.workloadType)}">${ic('terminal')} Logs</button>
      <button class="btn sm danger" data-action="delete-workload" data-id="${esc(w.id)}">${ic('trash')}</button>
    </div>
  </div>`;
}

// ===== WORKLOADS VIEW =====
async function renderWorkloads(mc,type){
  mc.innerHTML=`<div class="skeleton skeleton-card"></div>`;
  try{
    const data=await api(`/api/workloads?type=${type}`);
    S.workloads=data.workloads||[];
    const items=S.workloads;
    const isVps=type==='vps';
    mc.innerHTML=`
      <div class="page-header">
        <div class="page-header-left"><h1>${isVps?'VPS Instances':'Containers'}</h1><p>${items.length} ${isVps?'VPS instance':'container'}${items.length!==1?'s':''}</p></div>
        <div class="page-header-actions">
          <button class="btn secondary sm" data-action="refresh-view">${ic('refresh')} Refresh</button>
          <button class="btn sm" data-action="new-container">${ic('plus')} New Container</button>
        </div>
      </div>
      ${items.length?`<div class="workload-grid">${items.map(workloadCard).join('')}</div>`:`
        <div class="panel"><div class="empty-state">
          <div style="width:56px;height:56px;border-radius:14px;display:flex;align-items:center;justify-content:center;margin-bottom:16px;background:var(--accent-soft);color:var(--accent-text)">${ic(isVps?'server':'container')}</div>
          <h3 style="font-size:15px;margin-bottom:5px">No ${isVps?'VPS instances':'containers'}</h3>
          <p style="font-size:12px;color:var(--muted);max-width:320px;line-height:1.7">Deploy your first ${isVps?'virtual machine':'Docker container'}.</p>
          <button class="btn mt" data-action="new-${type}">${ic('plus')} Deploy ${isVps?'VPS':'Container'}</button>
        </div></div>`}
    `;
  }catch(e){mc.innerHTML=`<div class="notice error">${ic('alert')} ${esc(e.message)}</div>`;}
}

// ===== STORAGE VIEW =====
async function renderStorage(mc){
  mc.innerHTML=`<div class="skeleton skeleton-card mb"></div>`;
  try{
    const data=await api('/api/me');
    const u=data.user;
    const sp=pct(u.used,u.quota);
    mc.innerHTML=`
      <div class="page-header">
        <div class="page-header-left"><h1>Storage</h1><p>Encrypted personal file storage</p></div>
        <div class="page-header-actions"><button class="btn sm" id="upload-btn">${ic('upload')} Upload Files</button></div>
      </div>
      <div class="stats-grid" style="grid-template-columns:repeat(3,1fr)">
        <div class="stat-card"><div class="stat-card-head"><div class="stat-card-icon purple">${ic('storage')}</div></div><div class="stat-card-value">${fmtSize(u.used)}</div><div class="stat-card-label">Used</div></div>
        <div class="stat-card"><div class="stat-card-head"><div class="stat-card-icon green">${ic('check')}</div></div><div class="stat-card-value">${fmtSize(u.quota-u.used)}</div><div class="stat-card-label">Available</div></div>
        <div class="stat-card"><div class="stat-card-head"><div class="stat-card-icon blue">${ic('disk')}</div></div><div class="stat-card-value">${sp}%</div><div class="stat-card-label">Used</div>
          <div class="quota-bar"><div class="progress mt-sm"><i style="width:${sp}%;background:${sp>85?'var(--danger)':sp>65?'var(--warning)':'var(--success)'}"></i></div></div>
        </div>
      </div>
      <div class="panel" id="file-panel">
        <div class="fm-toolbar"><h2 style="font-size:14px;font-weight:600">Files</h2></div>
        <div id="file-content"><div class="skeleton skeleton-row"></div></div>
      </div>
    `;
    loadFiles();
    $('#upload-btn')?.addEventListener('click',()=>$('#file-picker').click());
    $('#file-picker').onchange=e=>{if(e.target.files.length)handleUploadFiles(e.target.files);e.target.value='';};
  }catch(e){mc.innerHTML=`<div class="notice error">${ic('alert')} ${esc(e.message)}</div>`;}
}

async function loadFiles(){
  const fc=$('#file-content');if(!fc)return;
  try{
    const data=await api(`/api/entries?view=files${S.parent?'&parent='+S.parent:''}`);
    S.entries=data.entries;
    if(!S.entries.length){fc.innerHTML=`<div class="empty-state"><div style="width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;margin-bottom:12px;background:var(--accent-soft);color:var(--accent-text)">${ic('folder')}</div><h3>No files</h3><p style="font-size:12px;color:var(--muted)">Upload files to get started.</p></div>`;return;}
    fc.innerHTML=`<div class="table-wrap"><table><thead><tr>
      <th>Name</th><th>Size</th><th>Modified</th><th style="width:80px"></th>
    </tr></thead><tbody>
      ${S.entries.map(e=>`<tr>
        <td><button class="file-name-cell" data-action="open-entry" data-id="${esc(e.id)}" data-kind="${esc(e.kind)}">
          <div class="file-icon ${fileIconClass(e)}">${ic(fileIconName(e))}</div>
          <strong>${esc(e.name)}</strong>
        </button></td>
        <td class="text-muted">${e.kind==='file'?fmtSize(e.size):'—'}</td>
        <td class="text-muted nowrap">${fmtDate(e.updatedAt)}</td>
        <td><div class="cell-actions">
          ${e.kind==='file'?`<a href="/api/entries/${e.id}/download" class="icon-btn" title="Download" download>${ic('download')}</a>`:''}
          ${ibtn('delete-entry','trash','Delete','danger')}
        </div></td>
      </tr>`).join('')}
    </tbody></table></div>
    <div class="panel-footer"><span>${S.entries.length} item${S.entries.length!==1?'s':''}</span><span>${ic('shield')} AES-256-GCM encrypted</span></div>`;
  }catch(e){if(fc)fc.innerHTML=`<div class="notice error">${ic('alert')} ${esc(e.message)}</div>`;}
}

async function handleUploadFiles(files){
  for(const file of files){
    toast(`Uploading ${file.name}…`);
    try{
      const res=await fetch('/api/upload',{method:'POST',headers:{'X-CSRF-Token':S.csrf,'X-File-Name':encodeURIComponent(file.name),'Content-Length':String(file.size),...(S.parent?{'X-Parent-Id':S.parent}:{})},body:file,credentials:'same-origin'});
      const data=await res.json();
      if(!res.ok)throw new Error(data.error||'Upload failed');
      toast(`${file.name} uploaded`,'success');
      loadFiles();
    }catch(e){toast(`Upload failed: ${e.message}`,'error');}
  }
}

function fileIconClass(e){if(e.kind==='folder')return'folder';if(e.mime?.startsWith('image/'))return'image';if(['zip','rar','7z','gz'].includes(e.name?.split('.').pop()?.toLowerCase()))return'archive';if(e.mime?.startsWith('video/'))return'media';return'default';}
function fileIconName(e){if(e.kind==='folder')return'folder';if(e.mime?.startsWith('image/'))return'image';if(e.mime?.startsWith('video/'))return'video';if(['zip','rar','7z','gz'].includes(e.name?.split('.').pop()?.toLowerCase()))return'archive';return'file';}

// ===== NAS & STORAGE — MACHINE LIST =====
async function renderNASUser(mc){
  mc.innerHTML=`<div class="skeleton skeleton-card mb"></div><div class="skeleton skeleton-card"></div>`;
  try{
    const data=await api('/api/nas/machines');
    S.nasMachines=data.machines||[];
    mc.innerHTML=`
      <div class="page-header">
        <div class="page-header-left">
          <h1>NAS & Storage</h1>
          <p>${S.nasMachines.length} machine${S.nasMachines.length!==1?'s':''} · Create a storage machine, then upload files into it</p>
        </div>
        <div class="page-header-actions">
          <button class="btn secondary sm" data-action="refresh-view">${ic('refresh')} Refresh</button>
          <button class="btn sm" data-action="new-nas-machine">${ic('plus')} New NAS Machine</button>
        </div>
      </div>
      ${S.nasMachines.length?`
        <div class="nas-grid">${S.nasMachines.map(nasMachineCard).join('')}</div>
      `:`
        <div class="panel"><div class="empty-state" style="min-height:240px">
          <div style="width:60px;height:60px;border-radius:14px;display:flex;align-items:center;justify-content:center;margin-bottom:16px;background:var(--accent-soft);color:var(--accent-text)">${ic('nas')}</div>
          <h3 style="font-size:16px;font-weight:700;margin-bottom:8px">No NAS machines yet</h3>
          <p style="font-size:13px;color:var(--muted);max-width:380px;line-height:1.8;margin-bottom:20px">
            Create a NAS machine first — it runs as a Docker container on your node.
            Once it's up, open it and upload your files directly from the browser.
          </p>
          <button class="btn" data-action="new-nas-machine">${ic('plus')} Create NAS Machine</button>
        </div></div>`}
    `;
  }catch(e){mc.innerHTML=`<div class="notice error">${ic('alert')} ${esc(e.message)}</div>`;}
}

function nasMachineCard(m){
  const usedGB=(m.used_bytes||0)/1024/1024/1024;
  const usedPct=pct(m.used_bytes||0,(m.quota_gb||50)*1024*1024*1024);
  const typeLabels={samba:'Samba (SMB)',minio:'MinIO',sftp:'SFTP',webdav:'WebDAV',nextcloud:'Nextcloud',filebrowser:'File Browser',generic:'Custom'};
  return`<div class="nas-card" style="cursor:pointer" data-action="open-nas-machine" data-id="${esc(m.id)}">
    <div class="nas-card-header">
      <div class="nas-card-icon">${ic('nas')}</div>
      <div style="flex:1;min-width:0">
        <div style="font-size:14px;font-weight:700">${esc(m.name)}</div>
        <div style="font-size:11px;color:var(--muted);margin-top:2px">${typeLabels[m.machine_type]||m.machine_type}</div>
      </div>
      ${statusBadge(m.status)}
    </div>
    <div style="margin-top:12px">
      <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--muted);margin-bottom:5px">
        <span>${ic('storage')} Storage</span>
        <span>${usedGB.toFixed(1)} GB / ${m.quota_gb} GB</span>
      </div>
      <div class="progress"><i style="width:${usedPct}%;background:${usedPct>85?'var(--danger)':usedPct>65?'var(--warning)':'var(--accent)'}"></i></div>
    </div>
    ${m.ip_address?`<div style="margin-top:10px;display:flex;align-items:center;gap:6px"><span class="ip-chip">${esc(m.ip_address)}:${m.access_port}</span><span style="font-size:10px;color:var(--muted)">${esc(m.access_protocol)}</span></div>`:''}
    <div style="display:flex;gap:6px;margin-top:12px;justify-content:flex-end">
      <button class="btn sm soft" data-action="open-nas-machine" data-id="${esc(m.id)}">${ic('folder')} Browse Files</button>
      <button class="btn sm danger" data-action="delete-nas-machine" data-id="${esc(m.id)}" onclick="event.stopPropagation()">${ic('trash')}</button>
    </div>
  </div>`;
}

// ===== NAS MACHINE FILE BROWSER =====
async function renderNASMachineBrowser(mc, machineId){
  S.view='nas-machine';
  mc.innerHTML=`<div class="skeleton skeleton-card mb"></div>`;
  try{
    const [machData, filesData]=await Promise.all([
      api(`/api/nas/machines/${machineId}`),
      api(`/api/nas/machines/${machineId}/files${S.nasParent?'?parent='+S.nasParent:''}`),
    ]);
    S.currentMachine=machData.machine;
    const m=S.currentMachine;
    const files=filesData.files||[];
    const usedPct=pct(m.used_bytes||0,(m.quota_gb||50)*1024**3);

    mc.innerHTML=`
      <div class="page-header">
        <div class="page-header-left">
          <div style="display:flex;align-items:center;gap:10px">
            <button class="icon-btn" data-action="goto-nas" title="Back to NAS">${ic('chevron')} </button>
            <div>
              <div style="display:flex;align-items:center;gap:8px">
                <h1 style="font-size:18px">${esc(m.name)}</h1>
                ${statusBadge(m.status)}
              </div>
              <p style="font-size:12px;color:var(--muted)">
                ${fmtSize(m.used_bytes||0)} used of ${m.quota_gb}GB · ${machData.fileCount} file${machData.fileCount!==1?'s':''}
              </p>
            </div>
          </div>
        </div>
        <div class="page-header-actions">
          <button class="btn secondary sm" data-action="new-nas-folder">${ic('folder')} New Folder</button>
          <button class="btn sm" id="nas-upload-btn">${ic('upload')} Upload Files</button>
        </div>
      </div>
      <div class="progress mb" style="height:5px">
        <i style="width:${usedPct}%;background:${usedPct>85?'var(--danger)':usedPct>65?'var(--warning)':'var(--accent)'}"></i>
      </div>
      ${m.status==='error'?`<div class="notice error mb">${ic('alert')} Machine has an error. Files are still accessible but the container may not be running.</div>`:''}
      ${m.status==='creating'?`<div class="notice info mb">${ic('clock')} Machine is being provisioned. You can already upload files — they will be available once it starts.</div>`:''}
      <div class="panel" id="nas-file-panel">
        <div style="padding:14px 18px;border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between">
          <div style="font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px">
            ${S.nasParent?`<button class="icon-btn" data-action="nas-go-up">${ic('chevron')}</button>`:''}
            ${ic('folder')} ${S.nasParent?'Folder':'Root'}
          </div>
          <span style="font-size:11px;color:var(--muted)">${files.length} item${files.length!==1?'s':''}</span>
        </div>
        ${files.length?`
          <div class="table-wrap"><table><thead><tr>
            <th>Name</th><th>Size</th><th>Modified</th><th style="width:80px"></th>
          </tr></thead><tbody>
            ${files.map(f=>`<tr>
              <td><button class="file-name-cell" data-action="${f.kind==='folder'?'nas-open-folder':'nas-preview-file'}" data-id="${esc(f.id)}" data-kind="${esc(f.kind)}">
                <div class="file-icon ${f.kind==='folder'?'folder':fileIconClass(f)}">${ic(f.kind==='folder'?'folder':fileIconName(f))}</div>
                <strong>${esc(f.name)}</strong>
              </button></td>
              <td class="text-muted">${f.kind==='file'?fmtSize(f.size):'—'}</td>
              <td class="text-muted nowrap">${fmtDate(f.updated_at)}</td>
              <td><div class="cell-actions">
                ${f.kind==='file'?`<a href="/api/nas/files/${f.id}/download" class="icon-btn" title="Download" download>${ic('download')}</a>`:''}
                <button class="icon-btn danger" data-action="delete-nas-file" data-id="${esc(f.id)}" data-name="${esc(f.name)}" title="Delete">${ic('trash')}</button>
              </div></td>
            </tr>`).join('')}
          </tbody></table></div>
        `:`
          <div class="empty-state" style="min-height:180px">
            <div style="width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;margin-bottom:12px;background:var(--accent-soft);color:var(--accent-text)">${ic('upload')}</div>
            <h3 style="font-size:14px;margin-bottom:6px">No files here</h3>
            <p style="font-size:12px;color:var(--muted);margin-bottom:14px">Upload files to get started.</p>
            <button class="btn sm" id="nas-upload-btn2">${ic('upload')} Upload Files</button>
          </div>
        `}
      </div>
      <input type="file" id="nas-file-picker" multiple hidden>
    `;

    // Wire upload buttons
    const doUpload=()=>$('#nas-file-picker').click();
    $('#nas-upload-btn')?.addEventListener('click',doUpload);
    $('#nas-upload-btn2')?.addEventListener('click',doUpload);
    $('#nas-file-picker').onchange=async e=>{
      if(!e.target.files.length)return;
      await handleNASUpload(machineId,e.target.files);
      e.target.value='';
      renderNASMachineBrowser(mc,machineId);
    };
  }catch(e){mc.innerHTML=`<div class="notice error">${ic('alert')} ${esc(e.message)}</div>`;}
}

async function handleNASUpload(machineId, files){
  for(const file of files){
    toast(`Uploading ${file.name}…`);
    try{
      const res=await fetch(`/api/nas/machines/${machineId}/upload`,{
        method:'POST',
        headers:{
          'X-CSRF-Token':S.csrf,
          'X-File-Name':encodeURIComponent(file.name),
          'Content-Length':String(file.size),
          ...(S.nasParent?{'X-Parent-Id':S.nasParent}:{}),
        },
        body:file,
        credentials:'same-origin',
      });
      const data=await res.json();
      if(!res.ok)throw new Error(data.error||'Upload failed');
      toast(`${file.name} uploaded`,'success');
    }catch(e){toast(`Upload failed: ${e.message}`,'error');}
  }
}

function nasCard(n){
  return`<div class="nas-card">
    <div class="nas-card-header">
      <div class="nas-card-icon">${ic('nas')}</div>
      <div style="flex:1;min-width:0">
        <div style="font-size:14px;font-weight:600">${esc(n.name)}</div>
        <div style="font-size:11px;color:var(--muted);font-family:monospace">${esc(n.endpoint)}</div>
      </div>
      ${statusBadge(n.status)}
    </div>
    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:4px">
      ${badge(n.nas_type,'info')}${n.location?badge(n.location,'member'):''}
    </div>
    ${n.last_error?`<div class="notice error" style="margin-top:10px;font-size:11px">${ic('alert')} ${esc(n.last_error)}</div>`:''}
    <div style="font-size:11px;color:var(--muted);margin-top:10px">Last check: ${fmtAge(n.last_health)}</div>
  </div>`;
}

// ===== JOBS VIEW =====
async function renderJobs(mc){
  mc.innerHTML=`<div class="skeleton skeleton-card"></div>`;
  try{
    const data=await api('/api/jobs');S.jobs=data.jobs||[];
    mc.innerHTML=`
      <div class="page-header">
        <div class="page-header-left"><h1>Jobs</h1><p>Provisioning and lifecycle jobs</p></div>
        <div class="page-header-actions"><button class="btn secondary sm" data-action="refresh-view">${ic('refresh')} Refresh</button></div>
      </div>
      <div class="panel">
        ${S.jobs.length?`<div class="table-wrap"><table><thead><tr>
          <th>Job ID</th><th>Type</th><th>Status</th><th>Created</th>
        </tr></thead><tbody>
          ${S.jobs.map(j=>`<tr>
            <td class="cell-mono">${j.id.slice(0,8)}</td>
            <td>${esc(j.job_type)}</td>
            <td>${statusBadge(j.status)}</td>
            <td class="text-muted">${fmtDateTime(j.created_at)}</td>
          </tr>`).join('')}
        </tbody></table></div>`:`
        <div class="empty-state"><div style="width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;margin-bottom:12px;background:var(--accent-soft);color:var(--accent-text)">${ic('activity')}</div><h3>No jobs yet</h3></div>`}
      </div>
    `;
  }catch(e){mc.innerHTML=`<div class="notice error">${ic('alert')} ${esc(e.message)}</div>`;}
}

// ===== ACCOUNT SETTINGS =====
async function renderAccountSettings(mc){
  const u=S.user;
  mc.innerHTML=`
    <div class="page-header"><div class="page-header-left"><h1>Account Settings</h1></div></div>
    <div class="settings-grid">
      <div class="settings-card">
        <h2>Profile</h2><p>Your account and resource usage.</p>
        <div style="display:flex;align-items:center;gap:14px;padding:14px;background:var(--surface-soft);border-radius:10px;margin-bottom:20px">
          <div class="avatar lg ${u?.role}">${(u?.displayName||u?.username||'?').slice(0,2).toUpperCase()}</div>
          <div>
            <strong>${esc(u?.displayName||'')}</strong>
            <div class="text-muted" style="font-size:12px">@${esc(u?.username||'')} · ${esc(u?.email||'')}</div>
            <div style="margin-top:4px">${roleBadge(u?.role||'member')}</div>
          </div>
        </div>
        <div class="grid-2" style="font-size:12px">
          <div><div class="text-muted">Member since</div><strong>${fmtDate(u?.createdAt)}</strong></div>
          <div><div class="text-muted">Last login</div><strong>${fmtAge(u?.lastLogin)}</strong></div>
          <div><div class="text-muted">Storage quota</div><strong>${fmtSize(u?.quota||0)}</strong></div>
          <div><div class="text-muted">Storage used</div><strong>${fmtSize(u?.used||0)}</strong></div>
        </div>
      </div>
      <div class="settings-card">
        <h2>Change Password</h2><p>You will be signed out after changing your password.</p>
        <div class="field"><label>Current Password</label><div class="password-wrap"><input id="cur-pw" type="password" placeholder="Current password">${ibtn('toggle-password','eye','Show')}</div></div>
        <div class="field"><label>New Password</label><div class="password-wrap"><input id="new-pw" type="password" minlength="8" placeholder="At least 8 characters">${ibtn('toggle-password','eye','Show')}</div></div>
        <div class="field"><label>Confirm New Password</label><div class="password-wrap"><input id="confirm-pw" type="password" placeholder="Repeat new password">${ibtn('toggle-password','eye','Show')}</div></div>
        <div id="pw-error" class="modal-error" hidden></div>
        <button class="btn full mt" data-action="change-password">${ic('key')} Change Password</button>
      </div>
      <div class="settings-card">
        <h2>Appearance</h2><p>Choose your preferred color theme.</p>
        <div class="theme-picker">
          ${[['light','Light','Clean'],['dark','Dark','Focused'],['system','System','Adaptive']].map(([v,l,d])=>`
            <div class="theme-option ${window.JTGTheme?.preference===v?'active':''}" data-theme-choice="${v}">
              <div class="theme-swatch ${v}"></div><strong>${l}</strong><small>${d}</small>
            </div>`).join('')}
        </div>
      </div>
      <div class="settings-card">
        <h2>Sessions</h2><p>Manage active login sessions.</p>
        <button class="btn danger full" data-action="revoke-all-sessions">${ic('logout')} Revoke All Other Sessions</button>
      </div>
    </div>
  `;
}

// ===== ADMIN: NODES =====
async function renderAdminNodes(mc){
  mc.innerHTML=`<div class="skeleton skeleton-card mb"></div>`;
  try{
    const [nodesData,localData]=await Promise.all([
      api('/api/admin/nodes'),
      api('/api/admin/local-node').catch(()=>({localNode:null})),
    ]);
    S.nodes=nodesData.nodes||[];
    S.localNode=localData.localNode;
    const {detectionData,providerStatuses={},warnings=[]}=localData;

    mc.innerHTML=`
      <div class="page-header">
        <div class="page-header-left"><h1>Nodes</h1><p>${S.nodes.length} node${S.nodes.length!==1?'s':''} registered</p></div>
        <div class="page-header-actions">
          <button class="btn secondary sm" data-action="run-local-detection" id="detect-btn">${ic('radar')} Run Detection</button>
          <button class="btn secondary sm" data-action="refresh-nodes">${ic('refresh')} Refresh</button>
          <button class="btn sm" data-action="add-node">${ic('plus')} Add Remote Node</button>
        </div>
      </div>
      ${S.detectionRunning?`<div class="detection-running"><div class="spinner"></div>Detection is running — this may take a few seconds…</div>`:''}
      ${S.localNode?localNodeDetail(S.localNode,detectionData,providerStatuses,warnings):''}
      <div id="nodes-grid-wrap">
        ${S.nodes.filter(n=>!n.is_local).length?`
          <div style="font-size:13px;font-weight:700;color:var(--muted);letter-spacing:.5px;margin-bottom:14px;display:flex;align-items:center;gap:8px">
            REMOTE NODES <span style="flex:1;height:1px;background:var(--line)"></span>
          </div>
          <div class="node-grid">${S.nodes.filter(n=>!n.is_local).map(nodeCard).join('')}</div>
        `:S.localNode?'':`
          <div class="panel"><div class="empty-state">
            <div style="width:56px;height:56px;border-radius:14px;display:flex;align-items:center;justify-content:center;margin-bottom:16px;background:var(--accent-soft);color:var(--accent-text)">${ic('server')}</div>
            <h3 style="font-size:15px;margin-bottom:5px">No nodes configured</h3>
            <p style="font-size:12px;color:var(--muted);max-width:320px;line-height:1.7">Run local detection or add a remote Docker, KVM, or Proxmox node.</p>
            <div class="flex" style="gap:10px;margin-top:16px">
              <button class="btn soft" data-action="run-local-detection">${ic('radar')} Detect Local</button>
              <button class="btn" data-action="add-node">${ic('plus')} Add Remote</button>
            </div>
          </div></div>`}
      </div>
    `;
  }catch(e){mc.innerHTML=`<div class="notice error">${ic('alert')} ${esc(e.message)}</div>`;}
}

function localNodeDetail(node,dd,ps,warnings){
  const cpu=pct(node.cpu_allocated,node.cpu_cores||1);
  const ram=pct(node.ram_allocated,node.ram_total||1);
  const disk=pct(node.disk_allocated,node.disk_total||1);
  const dockerStatus=ps.docker||'not_installed';
  const kvmStatus=ps.kvm||'not_available';
  const proxmoxStatus=ps.proxmox||'not_installed';
  const statusColor=s=>['ready','connected'].includes(s)?'var(--success)':['detected'].includes(s)?'var(--info)':'var(--muted)';
  return`<div class="local-node-detail">
    <div class="local-node-header">
      <div class="local-node-title">
        <div class="local-node-icon">${ic('radar')}</div>
        <div>
          <div style="display:flex;align-items:center;gap:8px">
            <strong style="font-size:16px;font-weight:700">${esc(node.name)}</strong>
            ${badge('Local Node','local-node')}
            ${statusBadge(node.status)}
          </div>
          <div style="font-size:12px;color:var(--muted);margin-top:3px;font-family:monospace">${esc(node.hostname)} · ${esc(node.ip_address)}</div>
        </div>
      </div>
      <div class="flex flex-gap-sm">
        <button class="btn secondary sm" data-action="run-local-detection">${ic('refresh')} Re-detect</button>
        <button class="btn secondary sm" data-action="view-node-workloads" data-id="${esc(node.id)}">${ic('box')} Workloads</button>
      </div>
    </div>
    <div class="node-resource" style="grid-template-columns:repeat(3,1fr)">
      <div class="node-res-item">
        <label>CPU</label>
        <div class="val">${node.cpu_cores} cores</div>
        <div class="sub">${dd?.cpu?.model||node.os_info||''}</div>
        ${dd?.cpu?.utilization!=null?`<div class="res-bar"><div class="res-bar-fill ${barClass(dd.cpu.utilization)}" style="width:${dd.cpu.utilization}%"></div></div><div class="sub">${dd.cpu.utilization}% utilization</div>`:''}
      </div>
      <div class="node-res-item">
        <label>RAM</label>
        <div class="val">${dd?fmtSize(dd.ram?.totalBytes||0):fmtMB(node.ram_total)}</div>
        <div class="sub">${dd?`${fmtSize(dd.ram?.freeBytes||0)} free`:''}</div>
        ${dd?`<div class="res-bar"><div class="res-bar-fill ${barClass(pct((dd.ram?.usedBytes||0),(dd.ram?.totalBytes||1)))}" style="width:${pct(dd.ram?.usedBytes||0,dd.ram?.totalBytes||1)}%"></div></div>`:'' }
      </div>
      <div class="node-res-item">
        <label>Disk</label>
        <div class="val">${dd?.disk?.primary?fmtSize(dd.disk.primary.totalBytes):node.disk_total+'GB'}</div>
        <div class="sub">${dd?.disk?.primary?fmtSize(dd.disk.primary.freeBytes)+' free':''}</div>
        ${dd?.disk?.primary?`<div class="res-bar"><div class="res-bar-fill ${barClass(pct(dd.disk.primary.usedBytes,dd.disk.primary.totalBytes))}" style="width:${pct(dd.disk.primary.usedBytes,dd.disk.primary.totalBytes)}%"></div></div>`:'' }
      </div>
    </div>
    <div class="provider-grid">
      <div class="provider-item"><label>Docker</label><div class="pstatus" style="color:${statusColor(dockerStatus)}">${ic('container')} ${esc(dockerStatus)}${dd?.docker?.version?` v${esc(dd.docker.version)}`:''}</div></div>
      <div class="provider-item"><label>KVM / libvirt</label><div class="pstatus" style="color:${statusColor(kvmStatus)}">${ic('server')} ${esc(kvmStatus)}</div></div>
      <div class="provider-item"><label>Proxmox</label><div class="pstatus" style="color:${statusColor(proxmoxStatus)}">${ic('layers')} ${esc(proxmoxStatus)}${dd?.proxmox?.version?` v${esc(dd.proxmox.version)}`:''}</div></div>
    </div>
    ${warnings.length?`<div class="warning-list">${warnings.map(w=>`<div class="warning-item">${ic('alert')} ${esc(w)}</div>`).join('')}</div>`:''}
    <div style="font-size:11px;color:var(--muted);margin-top:12px">Last detection: ${fmtAge(node.last_heartbeat)}</div>
  </div>`;
}

function nodeCard(n){
  const cp=pct(n.cpu_allocated,n.cpu_cores||1);
  const rp=pct(n.ram_allocated,n.ram_total||1);
  const dp=pct(n.disk_allocated,n.disk_total||1);
  return`<div class="node-card">
    <div class="node-card-header">
      <div>
        <div class="node-card-title">${esc(n.name)}</div>
        <div class="node-card-sub">${esc(n.hostname)} · ${esc(n.ip_address)}</div>
      </div>
      <div class="node-card-badges">
        ${statusBadge(n.status)}
        ${badge(n.provider_type,n.provider_type)}
      </div>
    </div>
    ${n.last_error?`<div class="notice error" style="margin:0 0 10px;font-size:11px">${ic('alert')} ${esc(n.last_error)}</div>`:''}
    <div class="node-resource">
      <div class="node-res-item"><label>CPU</label><div class="val">${n.cpu_allocated}/${n.cpu_cores}v</div><div class="sub">${cp}% alloc</div><div class="res-bar"><div class="res-bar-fill ${barClass(cp)}" style="width:${cp}%"></div></div></div>
      <div class="node-res-item"><label>RAM</label><div class="val">${fmtMB(n.ram_allocated)}/${fmtMB(n.ram_total)}</div><div class="sub">${rp}%</div><div class="res-bar"><div class="res-bar-fill ${barClass(rp)}" style="width:${rp}%"></div></div></div>
      <div class="node-res-item"><label>Disk</label><div class="val">${n.disk_allocated}/${n.disk_total}GB</div><div class="sub">${dp}%</div><div class="res-bar"><div class="res-bar-fill ${barClass(dp)}" style="width:${dp}%"></div></div></div>
    </div>
    <div style="display:flex;gap:6px;margin-top:12px;justify-content:flex-end">
      <button class="btn sm secondary" data-action="test-node" data-id="${esc(n.id)}">${ic('heartbeat')} Test</button>
      <button class="btn sm secondary" data-action="edit-node" data-id="${esc(n.id)}">${ic('edit')}</button>
      <button class="btn sm secondary" data-action="view-node-workloads" data-id="${esc(n.id)}">${ic('box')}</button>
      <button class="btn sm danger" data-action="delete-node" data-id="${esc(n.id)}">${ic('trash')}</button>
    </div>
  </div>`;
}

// ===== ADMIN USERS =====
async function renderAdminUsers(mc){
  mc.innerHTML=`<div class="skeleton skeleton-card"></div>`;
  try{
    const data=await api('/api/admin/users');
    S.adminUsers=data.users||[];
    mc.innerHTML=`
      <div class="page-header">
        <div class="page-header-left"><h1>User Management</h1><p>${S.adminUsers.length} user${S.adminUsers.length!==1?'s':''}</p></div>
        <div class="page-header-actions">
          <div class="search-wrap">${ic('search')}<input class="search-input" id="user-search" placeholder="Search users…"></div>
          <button class="btn sm" data-action="create-user">${ic('plus')} New User</button>
        </div>
      </div>
      <div class="panel">
        <div class="table-wrap"><table id="users-table"><thead><tr>
          <th>User</th><th>Role</th><th>Status</th><th>Storage</th><th>Machines</th><th>Joined</th><th>Last Login</th><th style="width:100px"></th>
        </tr></thead><tbody>${renderUserRows(S.adminUsers)}</tbody></table></div>
      </div>
    `;
    $('#user-search')?.addEventListener('input',e=>{
      const q=e.target.value.toLowerCase();
      const filtered=S.adminUsers.filter(u=>u.username.toLowerCase().includes(q)||u.email.toLowerCase().includes(q)||(u.displayName||'').toLowerCase().includes(q));
      $('#users-table tbody').innerHTML=renderUserRows(filtered);
    });
  }catch(e){mc.innerHTML=`<div class="notice error">${ic('alert')} ${esc(e.message)}</div>`;}
}

function renderUserRows(users){
  return users.map(u=>{
    const sp=pct(u.used,u.quota);
    return`<tr>
      <td><div class="flex flex-gap-sm"><div class="avatar ${u.role}">${(u.displayName||u.username||'?').slice(0,2).toUpperCase()}</div>
        <div><div class="cell-primary">${esc(u.displayName||u.username)}</div><div class="cell-secondary">${esc(u.email)}</div></div></div></td>
      <td>${roleBadge(u.role)}</td>
      <td>${badge(u.active?'Active':'Suspended',u.active?'running':'stopped')}</td>
      <td style="min-width:120px"><div style="font-size:11px">${fmtSize(u.used)}/${fmtSize(u.quota)}</div>
        <div class="progress mt-sm"><i style="width:${sp}%;background:${sp>85?'var(--danger)':sp>65?'var(--warning)':'var(--accent)'}"></i></div></td>
      <td class="text-muted">${u.machineLimit||5}</td>
      <td class="text-muted nowrap">${fmtDate(u.createdAt)}</td>
      <td class="text-muted nowrap">${fmtAge(u.lastLogin)}</td>
      <td><div class="cell-actions">
        ${ibtn('edit-user','edit','Edit user','edit-user-btn')}
        ${u.role!=='owner'?ibtn('delete-user','trash','Delete user','danger'):''}
      </div></td>
    </tr>`;
  }).join('')||'<tr><td colspan="8" class="text-muted" style="text-align:center;padding:30px">No users found.</td></tr>';
}

// ===== ADMIN WORKLOADS =====
async function renderAdminWorkloads(mc){
  mc.innerHTML=`<div class="skeleton skeleton-card"></div>`;
  try{
    const data=await api('/api/admin/workloads');
    const items=data.workloads||[];
    mc.innerHTML=`
      <div class="page-header"><div class="page-header-left"><h1>All Workloads</h1><p>${items.length} total</p></div></div>
      <div class="panel">${items.length?`<div class="table-wrap"><table><thead><tr>
        <th>Name</th><th>Type</th><th>Owner</th><th>Status</th><th>Resources</th><th>Created</th>
      </tr></thead><tbody>${items.map(w=>`<tr>
        <td><div class="cell-primary">${esc(w.name)}</div><div class="cell-secondary">${esc(w.image||w.osTemplate||'')}</div></td>
        <td>${badge(w.workloadType,w.workloadType)}</td>
        <td class="text-muted">@${esc(w.ownerUsername||'')}</td>
        <td>${statusBadge(w.status)}</td>
        <td style="font-size:11px;color:var(--muted)">${w.cpuAllocated}v · ${fmtMB(w.ramAllocated)} · ${w.diskAllocated}GB</td>
        <td class="text-muted nowrap">${fmtDate(w.createdAt)}</td>
      </tr>`).join('')}</tbody></table></div>`:`<div class="empty-state"><h3>No workloads</h3></div>`}</div>
    `;
  }catch(e){mc.innerHTML=`<div class="notice error">${ic('alert')} ${esc(e.message)}</div>`;}
}

// ===== ADMIN JOBS =====
async function renderAdminJobs(mc){
  mc.innerHTML=`<div class="skeleton skeleton-card"></div>`;
  try{
    const data=await api('/api/admin/jobs');
    const jobs=data.jobs||[];
    mc.innerHTML=`
      <div class="page-header"><div class="page-header-left"><h1>All Jobs</h1></div>
        <div class="page-header-actions"><button class="btn secondary sm" data-action="refresh-view">${ic('refresh')} Refresh</button></div></div>
      <div class="panel">${jobs.length?`<div class="table-wrap"><table><thead><tr>
        <th>Job ID</th><th>Type</th><th>User</th><th>Status</th><th>Attempts</th><th>Created</th>
      </tr></thead><tbody>${jobs.map(j=>`<tr>
        <td class="cell-mono">${j.id.slice(0,8)}</td>
        <td>${esc(j.job_type)}</td>
        <td class="text-muted">@${esc(j.username||'')}</td>
        <td>${statusBadge(j.status)}</td>
        <td class="text-muted">${j.attempts}</td>
        <td class="text-muted nowrap">${fmtDateTime(j.created_at)}</td>
      </tr>`).join('')}</tbody></table></div>`:`<div class="empty-state"><h3>No jobs</h3></div>`}</div>
    `;
  }catch(e){mc.innerHTML=`<div class="notice error">${ic('alert')} ${esc(e.message)}</div>`;}
}

// ===== ADMIN NAS =====
async function renderAdminNAS(mc){
  mc.innerHTML=`<div class="skeleton skeleton-card"></div>`;
  try{
    const data=await api('/api/admin/nas');S.nasList=data.servers||[];
    mc.innerHTML=`
      <div class="page-header">
        <div class="page-header-left"><h1>NAS Servers</h1><p>${S.nasList.length} registered</p></div>
        <div class="page-header-actions"><button class="btn sm" data-action="add-nas">${ic('plus')} Add NAS Server</button></div>
      </div>
      ${S.nasList.length?`<div class="nas-grid">${S.nasList.map(n=>`<div class="nas-card">
        <div class="nas-card-header">
          <div class="nas-card-icon">${ic('nas')}</div>
          <div style="flex:1;min-width:0"><div style="font-size:14px;font-weight:600">${esc(n.name)}</div>
            <div style="font-size:11px;color:var(--muted);font-family:monospace">${esc(n.endpoint)}</div></div>
          ${statusBadge(n.status)}
        </div>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:8px">
          ${badge(n.nas_type,'info')}${n.location?badge(n.location,'member'):''}
        </div>
        ${n.last_error?`<div class="notice error" style="margin-top:10px;font-size:11px">${ic('alert')} ${esc(n.last_error)}</div>`:''}
        <div style="display:flex;gap:6px;margin-top:12px;justify-content:flex-end">
          <button class="btn sm secondary" data-action="refresh-nas" data-id="${esc(n.id)}">${ic('refresh')} Test</button>
          <button class="btn sm danger" data-action="delete-nas" data-id="${esc(n.id)}">${ic('trash')}</button>
        </div>
      </div>`).join('')}</div>`:`
        <div class="panel"><div class="empty-state">
          <div style="width:56px;height:56px;border-radius:14px;display:flex;align-items:center;justify-content:center;margin-bottom:16px;background:var(--accent-soft);color:var(--accent-text)">${ic('nas')}</div>
          <h3 style="font-size:15px;margin-bottom:5px">No NAS servers</h3>
          <p style="font-size:12px;color:var(--muted);max-width:340px;line-height:1.7">Connect a TrueNAS, Synology, Unraid, OpenMediaVault, or generic NAS server.</p>
          <button class="btn mt" data-action="add-nas">${ic('plus')} Add NAS Server</button>
        </div></div>`}
    `;
  }catch(e){mc.innerHTML=`<div class="notice error">${ic('alert')} ${esc(e.message)}</div>`;}
}

// ===== ADMIN SETTINGS =====
async function renderAdminSettings(mc){
  mc.innerHTML=`<div class="skeleton skeleton-card"></div>`;
  try{
    const data=await api('/api/admin/overview');const s=data.settings;
    mc.innerHTML=`
      <div class="page-header"><div class="page-header-left"><h1>System Settings</h1><p>Configure ArabiCloud</p></div></div>
      <div class="settings-grid">
        <div class="settings-card">
          <h2>Branding</h2><p>Customize the panel name and appearance.</p>
          <div class="field"><label>Site Name</label><input id="s-siteName" value="${esc(s.siteName||'ArabiCloud')}"></div>
          <div class="field"><label>Tagline</label><input id="s-tagline" value="${esc(s.tagline||'')}"></div>
          <div class="field"><label>Accent Color</label><div class="flex flex-gap-sm"><input type="color" id="s-accent" value="${esc(s.accent||'#6366f1')}" style="width:60px;height:38px"><input id="s-accent-text" value="${esc(s.accent||'#6366f1')}" style="font-family:monospace"></div></div>
          <div class="toggle-wrap"><div class="toggle-label"><strong>Open Registration</strong><small>Allow anyone to create an account</small></div><input type="checkbox" class="toggle" id="s-reg" ${s.registrationEnabled?'checked':''}></div>
          <button class="btn full mt" data-action="save-branding">${ic('check')} Save Branding</button>
        </div>
        <div class="settings-card">
          <h2>Infrastructure Limits</h2><p>Resource limits for workload creation.</p>
          <div class="field-row">
            <div class="field"><label>Max Machines/User</label><input type="number" id="s-maxMachines" value="${s.maxMachinesPerUser||5}" min="0"></div>
            <div class="field"><label>Max vCPU/Instance</label><input type="number" id="s-maxCpu" value="${s.maxCpuPerInstance||16}" min="1"></div>
          </div>
          <div class="field-row">
            <div class="field"><label>Max RAM/Instance (MB)</label><input type="number" id="s-maxRam" value="${s.maxRamPerInstance||32768}" min="128"></div>
            <div class="field"><label>Max Disk/Instance (GB)</label><input type="number" id="s-maxDisk" value="${s.maxDiskPerInstance||500}" min="1"></div>
          </div>
          <div class="toggle-wrap"><div class="toggle-label"><strong>Require Approval</strong><small>New workloads need admin approval</small></div><input type="checkbox" class="toggle" id="s-approval" ${s.requireProvisioningApproval?'checked':''}></div>
          <button class="btn full mt" data-action="save-infra-settings">${ic('check')} Save Infrastructure</button>
        </div>
        <div class="settings-card">
          <h2>Storage</h2><p>Default quotas and upload limits.</p>
          <div class="field"><label>Default Quota (GB)</label><input type="number" id="s-quota" value="${Math.round((s.defaultQuota||0)/(1024**3))}" min="0"></div>
          <div class="field"><label>Max Upload Size (MB, 0=unlimited)</label><input type="number" id="s-maxUpload" value="${Math.round((s.maxUpload||0)/(1024**2))}" min="0"></div>
          <button class="btn full mt" data-action="save-storage-settings">${ic('check')} Save Storage</button>
        </div>
        <div class="settings-card">
          <h2>System Overview</h2>
          <div style="display:grid;gap:10px;font-size:13px">
            <div class="flex" style="justify-content:space-between"><span class="text-muted">Version</span><strong>${esc(data.version||'')}</strong></div>
            <div class="flex" style="justify-content:space-between"><span class="text-muted">Port</span><strong>${esc(String(data.port||''))}</strong></div>
            <div class="flex" style="justify-content:space-between"><span class="text-muted">Total Users</span><strong>${data.users}</strong></div>
            <div class="flex" style="justify-content:space-between"><span class="text-muted">Online Nodes</span><strong>${data.onlineNodes}/${data.nodes}</strong></div>
            <div class="flex" style="justify-content:space-between"><span class="text-muted">Containers</span><strong>${data.containers}</strong></div>
            <div class="flex" style="justify-content:space-between"><span class="text-muted">VPS Instances</span><strong>${data.vpsInstances}</strong></div>
            <div class="flex" style="justify-content:space-between"><span class="text-muted">Disk Free</span><strong>${fmtSize(data.diskFree)}</strong></div>
          </div>
        </div>
      </div>
    `;
    $('#s-accent')?.addEventListener('input',e=>{if($('#s-accent-text'))$('#s-accent-text').value=e.target.value;});
    $('#s-accent-text')?.addEventListener('input',e=>{if($('#s-accent')&&/^#[0-9a-f]{6}$/i.test(e.target.value))$('#s-accent').value=e.target.value;});
  }catch(e){mc.innerHTML=`<div class="notice error">${ic('alert')} ${esc(e.message)}</div>`;}
}

// ===== AUTH =====
function renderAuth(register=false){
  S.generation++;
  const c=S.config;
  $('#app').innerHTML=`
    <div class="auth-page">
      <aside class="auth-side">
        <div class="auth-side-brand brand">
          <img data-brand-logo src="${esc(c.logo||'/mark.svg')}" alt=""><span data-brand-name>${esc(c.siteName||'ArabiCloud')}</span>
        </div>
        <div class="auth-side-content">
          <h1>Manage your <em>infrastructure</em> with confidence.</h1>
          <p>ArabiCloud gives you a professional multi-node panel for Docker containers, KVM virtual machines, NAS storage, and everything in between.</p>
          <div class="auth-side-features">
            <div class="auth-feature"><div class="auth-feature-icon">${ic('radar')}</div>Automatic local node detection</div>
            <div class="auth-feature"><div class="auth-feature-icon">${ic('container')}</div>Real Docker container management</div>
            <div class="auth-feature"><div class="auth-feature-icon">${ic('server')}</div>KVM and Proxmox VPS provisioning</div>
            <div class="auth-feature"><div class="auth-feature-icon">${ic('nas')}</div>NAS & storage server integration</div>
          </div>
        </div>
        <div class="auth-side-foot">${ic('shield')} Created by Adrian Zain Arabi</div>
      </aside>
      <main class="auth-main">
        <div class="auth-form-wrap">
          <div class="auth-eyebrow">ARABICLOUD</div>
          <h2>${register?'Create your account.':'Welcome back.'}</h2>
          <p>${register?'Create an account to start managing infrastructure.':c.tagline||'Sign in to continue.'}</p>
          ${c.setupRequired?`<div class="setup-notice">Run <code>npm run setup</code> to create the owner account first.</div>`:''}
          <div id="auth-error" class="modal-error" hidden></div>
          ${register?`
            <div class="field"><label>Display Name</label><input id="displayName" autocomplete="name" maxlength="60" placeholder="Alex Morgan" required></div>
            <div class="field"><label>Username</label><input id="username" autocomplete="username" minlength="3" maxlength="32" placeholder="alex.morgan" required></div>
            <div class="field"><label>Email</label><input id="email" type="email" autocomplete="email" placeholder="you@company.com" required></div>
          `:`
            <div class="field"><label>Email or Username</label><input id="identifier" type="text" autocomplete="username" placeholder="you@company.com" required></div>
          `}
          <div class="field"><label>Password</label><div class="password-wrap"><input id="password" type="password" autocomplete="${register?'new-password':'current-password'}" ${register?'minlength="8"':''} placeholder="${register?'At least 8 characters':'Your password'}" required>${ibtn('toggle-password','eye','Show')}</div></div>
          ${!register?`<div class="auth-options"><label><input type="checkbox" id="remember"> Keep me signed in</label></div>`:''}
          <button class="btn full" id="auth-submit">${register?'Create Account':'Sign In'} ${ic('chevron')}</button>
          <div class="auth-switch">
            ${register?`Already have an account? <button data-action="auth-login">Sign in</button>`
              :c.registrationEnabled&&!c.setupRequired?`New here? <button data-action="auth-register">Create an account</button>`:'Registration is closed.'}
          </div>
        </div>
      </main>
    </div>
  `;
  applyBrand();
  $('#auth-submit')?.addEventListener('click',async()=>{
    const errEl=$('#auth-error');errEl.hidden=true;
    const b=$('#auth-submit');b.disabled=true;b.classList.add('loading');
    try{
      const body=register
        ?{displayName:$('#displayName').value,username:$('#username').value,identifier:$('#email').value,password:$('#password').value}
        :{identifier:$('#identifier').value,password:$('#password').value,remember:$('#remember')?.checked};
      const data=await api(register?'/api/auth/register':'/api/auth/login',{method:'POST',body});
      S.user=data.user;S.csrf=data.csrf;
      renderApp();
    }catch(e){errEl.textContent=e.message;errEl.hidden=false;}
    finally{b.disabled=false;b.classList.remove('loading');}
  });
  document.addEventListener('keydown',function s(e){if(e.key==='Enter')$('#auth-submit')?.click();},{once:true});
}

// ===== MODALS =====
function showAddNodeModal(){
  modal('Add Remote Node',`
    <div class="notice info">${ic('info')} This adds a remote node. For the local machine, use "Run Detection".</div>
    <div class="field"><label>Node Name</label><input id="nm-name" placeholder="prod-docker-01" required></div>
    <div class="field-row">
      <div class="field"><label>Hostname</label><input id="nm-host" placeholder="node.example.com"></div>
      <div class="field"><label>IP Address</label><input id="nm-ip" placeholder="192.168.1.10"></div>
    </div>
    <div class="field"><label>API Endpoint</label><input id="nm-endpoint" placeholder="http://192.168.1.10:2375"></div>
    <div class="field"><label>Provider Type</label>
      <select id="nm-type"><option value="docker">Docker</option><option value="kvm">KVM / libvirt</option><option value="proxmox">Proxmox</option></select></div>
    <div class="field-row">
      <div class="field"><label>CPU Cores</label><input type="number" id="nm-cpu" value="4" min="0"></div>
      <div class="field"><label>RAM Total (MB)</label><input type="number" id="nm-ram" value="8192" min="0"></div>
    </div>
    <div class="field"><label>Disk Total (GB)</label><input type="number" id="nm-disk" value="100" min="0"></div>
    <div class="field-row">
      <div class="field"><label>Location <small>(optional)</small></label><input id="nm-loc" placeholder="Frankfurt, DE"></div>
      <div class="field"><label>Description <small>(optional)</small></label><input id="nm-desc" placeholder="Brief description"></div>
    </div>
  `,`<button class="btn secondary" data-action="close-modal">Cancel</button><button class="btn" id="confirm-add-node">${ic('plus')} Add Node</button>`,'wide');
  $('#confirm-add-node')?.addEventListener('click',async()=>{
    const b=$('#confirm-add-node');b.disabled=true;b.classList.add('loading');
    try{
      await api('/api/admin/nodes',{method:'POST',body:{
        name:$('#nm-name').value,hostname:$('#nm-host').value,ipAddress:$('#nm-ip').value,
        apiEndpoint:$('#nm-endpoint').value,providerType:$('#nm-type').value,
        cpuCores:parseInt($('#nm-cpu').value)||0,ramTotal:parseInt($('#nm-ram').value)||0,
        diskTotal:parseInt($('#nm-disk').value)||0,location:$('#nm-loc').value,description:$('#nm-desc').value,
      }});
      closeModal();toast('Node added','success');navigate('admin-nodes');
    }catch(e){modalError(e.message);b.disabled=false;b.classList.remove('loading');}
  });
}

function showNewContainerModal(){
  modal('Deploy Container',`
    <div class="field"><label>Container Name</label><input id="cw-name" placeholder="my-nginx" required></div>
    <div class="field"><label>Image</label><input id="cw-image" placeholder="nginx:latest" required></div>
    <div class="field-row3">
      <div class="field"><label>vCPU</label><input type="number" id="cw-cpu" value="1" min="1"></div>
      <div class="field"><label>RAM (MB)</label><input type="number" id="cw-ram" value="512" min="64"></div>
      <div class="field"><label>Disk (GB)</label><input type="number" id="cw-disk" value="10" min="1"></div>
    </div>
    <div class="field"><label>Ports (host:container, one per line)</label><textarea id="cw-ports" placeholder="8080:80&#10;443:443" rows="2"></textarea></div>
    <div class="field"><label>Environment Variables (KEY=VALUE, one per line)</label><textarea id="cw-env" placeholder="DB_HOST=localhost&#10;PORT=3000" rows="2"></textarea></div>
    <div class="field"><label>Restart Policy</label>
      <select id="cw-restart"><option value="unless-stopped">Unless stopped</option><option value="always">Always</option><option value="on-failure">On failure</option><option value="no">Never</option></select></div>
    <div class="field"><label>Preferred Node ID <small>(leave blank for auto-placement)</small></label><input id="cw-node" placeholder="Auto"></div>
    <div class="notice info" style="margin-top:8px">${ic('info')} The scheduler selects the best available Docker node with sufficient resources.</div>
  `,`<button class="btn secondary" data-action="close-modal">Cancel</button><button class="btn" id="confirm-new-container">${ic('play')} Deploy</button>`,'wide');
  $('#confirm-new-container')?.addEventListener('click',async()=>{
    const b=$('#confirm-new-container');b.disabled=true;b.classList.add('loading');
    try{
      const ports=$('#cw-ports').value.split('\n').map(s=>s.trim()).filter(Boolean);
      const env=$('#cw-env').value.split('\n').map(s=>s.trim()).filter(Boolean);
      await api('/api/workloads',{method:'POST',body:{
        workloadType:'container',providerType:'docker',
        name:$('#cw-name').value,image:$('#cw-image').value,
        cpuAllocated:parseInt($('#cw-cpu').value)||1,
        ramAllocated:parseInt($('#cw-ram').value)||512,
        diskAllocated:parseInt($('#cw-disk').value)||10,
        ports,env,restartPolicy:$('#cw-restart').value,
        nodeId:$('#cw-node').value||undefined,
      }});
      closeModal();toast('Container deployment queued','success');navigate('containers');
    }catch(e){modalError(e.message);b.disabled=false;b.classList.remove('loading');}
  });
}

function showNewVpsModal(){
  modal('Deploy VPS',`
    <div class="field"><label>VPS Name</label><input id="vw-name" placeholder="web-server-01" required></div>
    <div class="field"><label>OS Template</label>
      <select id="vw-os">
        <option value="ubuntu-22.04">Ubuntu 22.04 LTS</option><option value="ubuntu-20.04">Ubuntu 20.04 LTS</option>
        <option value="debian-12">Debian 12</option><option value="debian-11">Debian 11</option>
        <option value="centos-9">CentOS Stream 9</option><option value="rocky-9">Rocky Linux 9</option>
      </select></div>
    <div class="field"><label>Provider</label>
      <select id="vw-prov"><option value="kvm">KVM / libvirt</option><option value="proxmox">Proxmox</option></select></div>
    <div class="field-row3">
      <div class="field"><label>vCPU</label><input type="number" id="vw-cpu" value="2" min="1"></div>
      <div class="field"><label>RAM (MB)</label><input type="number" id="vw-ram" value="2048" min="256"></div>
      <div class="field"><label>Disk (GB)</label><input type="number" id="vw-disk" value="25" min="5"></div>
    </div>
    <div class="field"><label>Preferred Node ID <small>(leave blank for auto)</small></label><input id="vw-node" placeholder="Auto"></div>
    <div class="notice warning">${ic('alert')} VPS provisioning requires a KVM or Proxmox node with verified readiness. The job will fail if no capable node is available.</div>
  `,`<button class="btn secondary" data-action="close-modal">Cancel</button><button class="btn" id="confirm-new-vps">${ic('server')} Deploy VPS</button>`,'wide');
  $('#confirm-new-vps')?.addEventListener('click',async()=>{
    const b=$('#confirm-new-vps');b.disabled=true;b.classList.add('loading');
    try{
      await api('/api/workloads',{method:'POST',body:{
        workloadType:'vps',providerType:$('#vw-prov').value,
        name:$('#vw-name').value,osTemplate:$('#vw-os').value,
        cpuAllocated:parseInt($('#vw-cpu').value)||2,
        ramAllocated:parseInt($('#vw-ram').value)||2048,
        diskAllocated:parseInt($('#vw-disk').value)||25,
        nodeId:$('#vw-node').value||undefined,
      }});
      closeModal();toast('VPS deployment queued','success');navigate('vps');
    }catch(e){modalError(e.message);b.disabled=false;b.classList.remove('loading');}
  });
}

function showCreateUserModal(){
  modal('Create User',`
    <div class="field-row">
      <div class="field"><label>Display Name</label><input id="cu-name" placeholder="Alex Morgan"></div>
      <div class="field"><label>Username</label><input id="cu-username" placeholder="alex.morgan" minlength="3" maxlength="32"></div>
    </div>
    <div class="field"><label>Email</label><input id="cu-email" type="email" placeholder="alex@company.com"></div>
    <div class="field"><label>Password</label><input id="cu-pw" type="password" minlength="8" placeholder="At least 8 characters"></div>
    <div class="field-row">
      <div class="field"><label>Role</label><select id="cu-role"><option value="member">Member</option><option value="admin">Admin</option></select></div>
      <div class="field"><label>Storage Quota (GB)</label><input type="number" id="cu-quota" value="5" min="0"></div>
    </div>
    <div class="field"><label>Machine Limit (0=unlimited)</label><input type="number" id="cu-machines" value="5" min="0"></div>
  `,`<button class="btn secondary" data-action="close-modal">Cancel</button><button class="btn" id="confirm-create-user">${ic('plus')} Create</button>`);
  $('#confirm-create-user')?.addEventListener('click',async()=>{
    const b=$('#confirm-create-user');b.disabled=true;b.classList.add('loading');
    try{
      await api('/api/admin/users',{method:'POST',body:{
        displayName:$('#cu-name').value,username:$('#cu-username').value,
        email:$('#cu-email').value,password:$('#cu-pw').value,
        role:$('#cu-role').value,quota:parseInt($('#cu-quota').value||5)*GIB,
        machineLimit:parseInt($('#cu-machines').value)||5,
      }});
      closeModal();toast('User created','success');navigate('admin-users');
    }catch(e){modalError(e.message);b.disabled=false;b.classList.remove('loading');}
  });
}

function showEditUserModal(userId){
  const u=S.adminUsers.find(x=>x.id===userId);if(!u)return;
  modal(`Edit: ${u.username}`,`
    <div class="flex flex-gap-sm" style="padding:12px;background:var(--surface-soft);border-radius:9px;margin-bottom:16px">
      <div class="avatar ${u.role}">${(u.displayName||u.username).slice(0,2).toUpperCase()}</div>
      <div><strong>${esc(u.displayName||u.username)}</strong><div class="text-muted" style="font-size:11px">${esc(u.email)}</div></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Role</label><select id="eu-role" ${u.role==='owner'?'disabled':''}><option value="member" ${u.role==='member'?'selected':''}>Member</option><option value="admin" ${u.role==='admin'?'selected':''}>Admin</option></select></div>
      <div class="field"><label>Storage Quota (GB)</label><input type="number" id="eu-quota" value="${Math.round(u.quota/GIB)}" min="0"></div>
    </div>
    <div class="field-row">
      <div class="field"><label>Machine Limit (0=unlimited)</label><input type="number" id="eu-machines" value="${u.machineLimit||5}" min="0"></div>
      <div class="field"><label>Status</label><select id="eu-active"><option value="true" ${u.active?'selected':''}>Active</option><option value="false" ${!u.active?'selected':''}>Suspended</option></select></div>
    </div>
    <div class="toggle-wrap"><div class="toggle-label"><strong>Can Create Machines</strong><small>Allow deploying workloads</small></div>
      <input type="checkbox" class="toggle" id="eu-canCreate" ${u.canCreateMachines?'checked':''}></div>
  `,`<button class="btn secondary" data-action="close-modal">Cancel</button>
     <button class="btn secondary sm" id="eu-reset-pw">${ic('key')} Reset PW</button>
     <button class="btn" id="confirm-edit-user">${ic('check')} Save</button>`);
  $('#confirm-edit-user')?.addEventListener('click',async()=>{
    const b=$('#confirm-edit-user');b.disabled=true;b.classList.add('loading');
    try{
      await api(`/api/admin/users/${userId}`,{method:'PATCH',body:{
        role:$('#eu-role').value,quota:parseInt($('#eu-quota').value||5)*GIB,
        active:$('#eu-active').value==='true',machineLimit:parseInt($('#eu-machines').value)||5,
        canCreateMachines:$('#eu-canCreate').checked,
      }});
      closeModal();toast('User updated','success');navigate('admin-users');
    }catch(e){modalError(e.message);b.disabled=false;b.classList.remove('loading');}
  });
  $('#eu-reset-pw')?.addEventListener('click',()=>{
    const pw=prompt('New password (min 8 chars):');
    if(!pw||pw.length<8)return toast('Password too short','error');
    api(`/api/admin/users/${userId}/password`,{method:'POST',body:{newPassword:pw}}).then(()=>toast('Password reset','success')).catch(e=>toast(e.message,'error'));
  });
}

function showAddNASModal(){
  modal('Add NAS Server',`
    <div class="field"><label>Name</label><input id="nas-name" placeholder="My TrueNAS" required></div>
    <div class="field"><label>API Endpoint</label><input id="nas-endpoint" placeholder="http://192.168.1.100:80" required></div>
    <div class="field"><label>NAS Type</label>
      <select id="nas-type"><option value="truenas">TrueNAS</option><option value="synology">Synology DSM</option><option value="unraid">Unraid</option><option value="openmediavault">OpenMediaVault</option><option value="generic">Generic / Other</option></select></div>
    <div class="field-row">
      <div class="field"><label>Location <small>(optional)</small></label><input id="nas-loc" placeholder="Rack A"></div>
      <div class="field"><label>Description <small>(optional)</small></label><input id="nas-desc" placeholder="Primary NAS"></div>
    </div>
    <div class="notice warning">${ic('alert')} ArabiCloud never formats, partitions, or erases disks. Detection is read-only.</div>
  `,`<button class="btn secondary" data-action="close-modal">Cancel</button><button class="btn" id="confirm-add-nas">${ic('plus')} Add</button>`);
  $('#confirm-add-nas')?.addEventListener('click',async()=>{
    const b=$('#confirm-add-nas');b.disabled=true;b.classList.add('loading');
    try{
      await api('/api/admin/nas',{method:'POST',body:{
        name:$('#nas-name').value,endpoint:$('#nas-endpoint').value,
        nasType:$('#nas-type').value,location:$('#nas-loc').value,description:$('#nas-desc').value,
      }});
      closeModal();toast('NAS server added','success');navigate('admin-nas');
    }catch(e){modalError(e.message);b.disabled=false;b.classList.remove('loading');}
  });
}

function showNewNASMachineModal(){
  const types=[
    ['filebrowser','File Browser','Simple web UI, any file type — recommended for beginners'],
    ['samba','Samba (SMB)','Windows/Linux network share, mount as a drive'],
    ['minio','MinIO','S3-compatible object storage, API access'],
    ['sftp','SFTP','SSH file transfer, works with any SFTP client'],
    ['webdav','WebDAV','Mount as a network drive on Windows/Mac/Linux'],
    ['nextcloud','Nextcloud','Full cloud suite with sync client'],
    ['generic','Custom / Generic','Bring your own Docker image'],
  ];
  modal('Create NAS Machine',`
    <div class="notice info" style="margin-bottom:16px">${ic('info')}
      A NAS machine is a Docker container running a storage service on your node.
      Once created, open it to upload files directly from your browser.
    </div>
    <div class="field"><label>Machine Name</label><input id="nm2-name" placeholder="my-storage" required></div>
    <div class="field">
      <label>Storage Type</label>
      <select id="nm2-type">
        ${types.map(([v,l,d])=>`<option value="${v}">${l}</option>`).join('')}
      </select>
      <small id="nm2-type-desc" style="margin-top:6px;display:block;color:var(--muted)">${types[0][2]}</small>
    </div>
    <div class="field-row">
      <div class="field"><label>Storage Quota (GB)</label><input type="number" id="nm2-quota" value="50" min="1" max="10000"></div>
      <div class="field"><label>Access Port</label><input type="number" id="nm2-port" value="80" min="1" max="65535"><small>Port exposed on the node</small></div>
    </div>
    <div class="field"><label>Description <small>(optional)</small></label><input id="nm2-desc" placeholder="My media storage…"></div>
    <div class="field"><label>Node ID <small>(leave blank for auto-placement)</small></label><input id="nm2-node" placeholder="Auto"></div>
  `,`<button class="btn secondary" data-action="close-modal">Cancel</button><button class="btn" id="confirm-new-nas-machine">${ic('server')} Create Machine</button>`,'wide');

  // Update description when type changes
  const typeDescs=Object.fromEntries(types.map(([v,l,d])=>[v,d]));
  const typeDefaultPorts={filebrowser:80,samba:445,minio:9000,sftp:22,webdav:80,nextcloud:80,generic:80};
  $('#nm2-type')?.addEventListener('change',e=>{
    const v=e.target.value;
    const desc=$('#nm2-type-desc');if(desc)desc.textContent=typeDescs[v]||'';
    const port=$('#nm2-port');if(port)port.value=typeDefaultPorts[v]||80;
  });

  $('#confirm-new-nas-machine')?.addEventListener('click',async()=>{
    const b=$('#confirm-new-nas-machine');b.disabled=true;b.classList.add('loading');
    try{
      const data=await api('/api/nas/machines',{method:'POST',body:{
        name:$('#nm2-name').value,
        machineType:$('#nm2-type').value,
        quotaGb:parseInt($('#nm2-quota').value)||50,
        accessPort:parseInt($('#nm2-port').value)||80,
        description:$('#nm2-desc').value,
        nodeId:$('#nm2-node').value||undefined,
      }});
      closeModal();
      toast(`NAS machine "${data.machine.name}" created`,'success');
      // Open the new machine immediately
      S.nasParent=null;
      S.nasMachines=[data.machine,...(S.nasMachines||[])];
      renderNASMachineBrowser($('#main-content'),data.machine.id);
    }catch(e){modalError(e.message);b.disabled=false;b.classList.remove('loading');}
  });
}

function showLogsModal(workloadId,workloadName){
  modal(`Logs: ${workloadName}`,`
    <div class="notice info" style="margin-bottom:10px">${ic('info')} Last 100 lines. Requires the node to be online and the container running.</div>
    <div id="logs-content" class="job-log">Loading logs…</div>
  `,'',  'wide');
  api(`/api/workloads/${workloadId}/logs`).then(data=>{
    const el=$('#logs-content');if(!el)return;
    el.textContent=(data.logs||[]).join('\n')||'(no output)';
    el.scrollTop=el.scrollHeight;
  }).catch(e=>{
    const el=$('#logs-content');if(el)el.textContent=`Error: ${e.message}`;
  });
}

function confirmDelete(msg,onConfirm){
  modal('Confirm Delete',`<p>${esc(msg)}</p>`,
    `<button class="btn secondary" data-action="close-modal">Cancel</button><button class="btn danger" id="confirm-del">${ic('trash')} Delete</button>`);
  $('#confirm-del')?.addEventListener('click',async()=>{
    const b=$('#confirm-del');b.disabled=true;b.classList.add('loading');
    try{await onConfirm();closeModal();}catch(e){modalError(e.message);b.disabled=false;b.classList.remove('loading');}
  });
}

function showNodeWorkloadsModal(nodeId){
  modal('Node Workloads','<div class="job-log">Loading…</div>','','wide');
  api(`/api/admin/nodes/${nodeId}/workloads`).then(data=>{
    const items=data.workloads||[];
    $('#modal-body').innerHTML=items.length
      ?`<div class="table-wrap"><table><thead><tr><th>Name</th><th>Type</th><th>Owner</th><th>Status</th><th>Resources</th></tr></thead><tbody>
        ${items.map(w=>`<tr><td class="cell-primary">${esc(w.name)}</td><td>${badge(w.workloadType,w.workloadType)}</td>
        <td class="text-muted">@${esc(w.ownerUsername||'')}</td><td>${statusBadge(w.status)}</td>
        <td style="font-size:11px;color:var(--muted)">${w.cpuAllocated}v·${fmtMB(w.ramAllocated)}·${w.diskAllocated}GB</td></tr>`).join('')}
      </tbody></table></div>`
      :`<p>No active workloads on this node.</p>`;
  }).catch(e=>{$('#modal-body').innerHTML=`<p class="text-danger">${esc(e.message)}</p>`;});
}

// ===== DETECTION POLLING =====
async function runLocalDetection(){
  if(S.detectionRunning)return;
  S.detectionRunning=true;
  const btn=$('#detect-btn');
  if(btn){btn.disabled=true;btn.innerHTML=`<div style="width:14px;height:14px;border:2px solid #6366f130;border-top-color:var(--accent);border-radius:50%;animation:spin .7s linear infinite"></div> Detecting…`;}
  toast('Detection started…');
  try{
    await api('/api/admin/detect-local',{method:'POST'});
    // Poll for completion
    let attempts=0;
    const poll=setInterval(async()=>{
      attempts++;
      try{
        const data=await api('/api/admin/detect-local/status');
        if(data.run?.result==='success'||data.run?.result==='failed'||attempts>20){
          clearInterval(poll);
          S.detectionRunning=false;
          if(data.run?.result==='success'){toast('Detection complete','success');}
          else if(data.run?.result==='failed'){toast(`Detection failed: ${JSON.parse(data.run.warnings||'[]')[0]||'unknown'}`, 'error');}
          if(S.view==='admin-nodes')navigate('admin-nodes');
        }
      }catch{clearInterval(poll);S.detectionRunning=false;}
    },1500);
  }catch(e){
    S.detectionRunning=false;
    toast(`Detection error: ${e.message}`,'error');
    if(btn){btn.disabled=false;btn.innerHTML=`${ic('radar')} Run Detection`;}
  }
}

// ===== EVENT DELEGATION =====
document.addEventListener('click',async e=>{
  // Nav buttons (data-view) — check FIRST before anything else
  const navBtn=e.target.closest('.nav [data-view]');
  if(navBtn){
    navigate(navBtn.dataset.view);
    $('#sidebar')?.classList.remove('open');
    $('#screen-shade')?.classList.remove('open');
    return;
  }

  // Theme picker
  const tChoice=e.target.closest('[data-theme-choice]');
  if(tChoice){
    window.JTGTheme?.set(tChoice.dataset.themeChoice);
    $$('[data-theme-choice]').forEach(el=>el.classList.toggle('active',el.dataset.themeChoice===tChoice.dataset.themeChoice));
    return;
  }

  // Action buttons (data-action)
  const el=e.target.closest('[data-action]');
  if(!el)return;
  const action=el.dataset.action;

  try{
    switch(action){
      case 'toggle-sidebar':{
        const sb=$('#sidebar');const ws=$('.workspace');const sh=$('#screen-shade');
        if(window.innerWidth<=680){
          // mobile: slide in/out
          sb?.classList.toggle('open');sh?.classList.toggle('open');
        } else {
          // desktop: collapse/expand
          sb?.classList.toggle('collapsed');ws?.classList.toggle('sidebar-collapsed');
          ls.set('ac-sidebar-collapsed',sb?.classList.contains('collapsed')?'1':'0');
        }
        break;}
      case 'close-sidebar':{$('#sidebar')?.classList.remove('open');$('#screen-shade')?.classList.remove('open');break;}
      case 'close-modal':closeModal();break;
      case 'auth-login':renderAuth(false);break;
      case 'auth-register':renderAuth(true);break;
      case 'toggle-password':{const pw=el.closest('.password-wrap')?.querySelector('input');if(pw){pw.type=pw.type==='password'?'text':'password';el.innerHTML=ic(pw.type==='password'?'eye':'eyeOff');}break;}
      case 'logout':try{await api('/api/auth/logout',{method:'POST'});}catch{}S.user=null;renderAuth();break;
      case 'appearance':modal('Appearance',`<div class="theme-picker">
        ${[['light','Light','Clean'],['dark','Dark','Focused'],['system','System','Adaptive']].map(([v,l,d])=>`
          <div class="theme-option ${window.JTGTheme?.preference===v?'active':''}" data-theme-choice="${v}">
            <div class="theme-swatch ${v}"></div><strong>${l}</strong><small>${d}</small>
          </div>`).join('')}</div>`,
        '<button class="btn secondary" data-action="close-modal">Done</button>');break;
      case 'goto-containers':navigate('containers');break;
      case 'refresh-view':renderView();break;
      case 'add-node':showAddNodeModal();break;
      case 'refresh-nodes':navigate('admin-nodes');break;
      case 'run-local-detection':await runLocalDetection();break;
      case 'new-container':showNewContainerModal();break;
      case 'new-vps':showNewVpsModal();break;
      case 'create-user':showCreateUserModal();break;
      case 'add-nas':showAddNASModal();break;
      case 'test-node':{
        el.disabled=true;
        try{const d=await api(`/api/admin/nodes/${el.dataset.id}/test`,{method:'POST'});toast(d.ok?`Node online`:`Node offline: ${d.result?.error||'unknown'}`,d.ok?'success':'error');navigate('admin-nodes');}
        finally{el.disabled=false;}
        break;}
      case 'view-node-workloads':showNodeWorkloadsModal(el.dataset.id);break;
      case 'edit-node':{
        const n=S.nodes.find(x=>x.id===el.dataset.id);if(!n)break;
        modal(`Edit Node: ${n.name}`,`
          <div class="field"><label>Node Name</label><input id="en-name" value="${esc(n.name)}"></div>
          <div class="field-row">
            <div class="field"><label>Hostname</label><input id="en-host" value="${esc(n.hostname)}"></div>
            <div class="field"><label>IP Address</label><input id="en-ip" value="${esc(n.ip_address)}"></div>
          </div>
          <div class="field"><label>API Endpoint</label><input id="en-endpoint" value="${esc(n.api_endpoint)}"></div>
          <div class="field-row3">
            <div class="field"><label>CPU Cores</label><input type="number" id="en-cpu" value="${n.cpu_cores}"></div>
            <div class="field"><label>RAM (MB)</label><input type="number" id="en-ram" value="${n.ram_total}"></div>
            <div class="field"><label>Disk (GB)</label><input type="number" id="en-disk" value="${n.disk_total}"></div>
          </div>
          <div class="toggle-wrap"><div class="toggle-label"><strong>Scheduling Enabled</strong><small>Allow new workloads on this node</small></div>
            <input type="checkbox" class="toggle" id="en-sched" ${n.scheduling_enabled?'checked':''}></div>
          <div class="toggle-wrap"><div class="toggle-label"><strong>Maintenance Mode</strong><small>Prevent new workloads</small></div>
            <input type="checkbox" class="toggle" id="en-maint" ${n.maintenance_mode?'checked':''}></div>
        `,`<button class="btn secondary" data-action="close-modal">Cancel</button><button class="btn" id="confirm-edit-node">Save</button>`,'wide');
        $('#confirm-edit-node')?.addEventListener('click',async()=>{
          const b=$('#confirm-edit-node');b.disabled=true;b.classList.add('loading');
          try{
            await api(`/api/admin/nodes/${n.id}`,{method:'PATCH',body:{
              name:$('#en-name').value,hostname:$('#en-host').value,ipAddress:$('#en-ip').value,
              apiEndpoint:$('#en-endpoint').value,cpuCores:parseInt($('#en-cpu').value)||0,
              ramTotal:parseInt($('#en-ram').value)||0,diskTotal:parseInt($('#en-disk').value)||0,
              schedulingEnabled:$('#en-sched').checked?1:0,maintenanceMode:$('#en-maint').checked?1:0,
            }});
            closeModal();toast('Node updated','success');navigate('admin-nodes');
          }catch(err){modalError(err.message);b.disabled=false;b.classList.remove('loading');}
        });break;}
      case 'delete-node':
        confirmDelete('Remove this node? Workloads must be migrated first.',async()=>{
          await api(`/api/admin/nodes/${el.dataset.id}`,{method:'DELETE'});
          toast('Node removed','success');navigate('admin-nodes');
        });break;
      case 'start-workload':
        try{await api(`/api/workloads/${el.dataset.id}/start`,{method:'POST'});toast('Start queued','success');renderView();}
        catch(err){toast(err.message,'error');}break;
      case 'stop-workload':
        try{await api(`/api/workloads/${el.dataset.id}/stop`,{method:'POST'});toast('Stop queued','success');renderView();}
        catch(err){toast(err.message,'error');}break;
      case 'view-workload-logs':{
        const w=S.workloads.find(x=>x.id===el.dataset.id);
        if(w)showLogsModal(w.id,w.name);
        break;}
      case 'delete-workload':
        confirmDelete('Delete this workload? Resources will be released.',async()=>{
          await api(`/api/workloads/${el.dataset.id}`,{method:'DELETE'});
          toast('Workload deleted','success');renderView();
        });break;
      case 'refresh-nas':
        el.disabled=true;
        try{await api(`/api/admin/nas/${el.dataset.id}/refresh`,{method:'POST'});toast('NAS status refreshed','success');navigate('admin-nas');}
        catch(err){toast(err.message,'error');}
        finally{el.disabled=false;}
        break;
      case 'delete-nas':
        confirmDelete('Remove this NAS server registration?',async()=>{
          await api(`/api/admin/nas/${el.dataset.id}`,{method:'DELETE'});
          toast('NAS removed','success');navigate('admin-nas');
        });break;
      case 'goto-nas':
        S.nasParent=null;S.currentMachine=null;S.view='nas';
        navigate('nas');break;
      case 'open-nas-machine':
        S.nasParent=null;
        renderNASMachineBrowser($('#main-content'),el.dataset.id);break;
      case 'delete-nas-machine':
        confirmDelete(`Delete NAS machine "${S.nasMachines.find(m=>m.id===el.dataset.id)?.name||''}"? All files stored in ArabiCloud will be lost.`,async()=>{
          await api(`/api/nas/machines/${el.dataset.id}`,{method:'DELETE'});
          toast('NAS machine deleted','success');navigate('nas');
        });break;
      case 'new-nas-machine':showNewNASMachineModal();break;
      case 'nas-go-up':
        S.nasParent=null;
        if(S.currentMachine)renderNASMachineBrowser($('#main-content'),S.currentMachine.id);
        break;
      case 'goto-nas-machine':
        if(S.currentMachine)renderNASMachineBrowser($('#main-content'),S.currentMachine.id);
        break;
      case 'nas-open-folder':
        S.nasParent=el.dataset.id;
        if(S.currentMachine)renderNASMachineBrowser($('#main-content'),S.currentMachine.id);
        break;
      case 'nas-preview-file':break; // future: preview
      case 'delete-nas-file':
        confirmDelete(`Delete "${el.dataset.name}"?`,async()=>{
          await api(`/api/nas/files/${el.dataset.id}`,{method:'DELETE'});
          toast('File deleted','success');
          if(S.currentMachine)renderNASMachineBrowser($('#main-content'),S.currentMachine.id);
        });break;
      case 'new-nas-folder':
        modal('New Folder',`<div class="field"><label>Folder Name</label><input id="nas-folder-name" placeholder="My Folder" required></div>`,
          `<button class="btn secondary" data-action="close-modal">Cancel</button><button class="btn" id="confirm-nas-folder">${ic('folder')} Create</button>`);
        $('#confirm-nas-folder')?.addEventListener('click',async()=>{
          const b=$('#confirm-nas-folder');b.disabled=true;b.classList.add('loading');
          try{
            await api(`/api/nas/machines/${S.currentMachine.id}/folders`,{method:'POST',body:{name:$('#nas-folder-name').value,parentId:S.nasParent}});
            closeModal();toast('Folder created','success');
            renderNASMachineBrowser($('#main-content'),S.currentMachine.id);
          }catch(e){modalError(e.message);b.disabled=false;b.classList.remove('loading');}
        });break;
      case 'edit-user':{
        const row=el.closest('tr');
        const uid=row?.querySelector('[data-action="edit-user"]')?.dataset?.uid||el.dataset.uid||el.dataset.id;
        // find by iterating table rows
        const allRows=$$('#users-table tbody tr');
        let targetId=null;
        for(const r of allRows){
          const editBtn=r.querySelector('[data-action="edit-user"]');
          if(editBtn&&r===row){targetId=S.adminUsers[allRows.indexOf(r)]?.id;break;}
        }
        if(!targetId)break;
        showEditUserModal(targetId);break;}
      case 'delete-user':{
        const row=el.closest('tr');
        const allRows=$$('#users-table tbody tr');
        let uid=null;for(const r of allRows){if(r===row){uid=S.adminUsers[allRows.indexOf(r)]?.id;break;}}
        if(!uid)break;
        confirmDelete('Permanently delete this user and all their data?',async()=>{
          await api(`/api/admin/users/${uid}`,{method:'DELETE'});
          toast('User deleted','success');navigate('admin-users');
        });break;}
      case 'change-password':{
        const errEl=$('#pw-error');errEl.hidden=true;
        const curPw=$('#cur-pw').value,newPw=$('#new-pw').value,confPw=$('#confirm-pw').value;
        if(newPw!==confPw){errEl.textContent='Passwords do not match.';errEl.hidden=false;return;}
        if(newPw.length<8){errEl.textContent='Password must be at least 8 characters.';errEl.hidden=false;return;}
        el.disabled=true;el.classList.add('loading');
        try{
          await api('/api/account',{method:'PATCH',body:{currentPassword:curPw,newPassword:newPw}});
          toast('Password changed. Signing out…','success');
          S.user=null;setTimeout(renderAuth,1200);
        }catch(err){errEl.textContent=err.message;errEl.hidden=false;}
        finally{el.disabled=false;el.classList.remove('loading');}
        break;}
      case 'revoke-all-sessions':
        if(!confirm('Revoke all other sessions?'))break;
        try{await api('/api/sessions/revoke-all',{method:'POST'});toast('All other sessions revoked','success');}
        catch(err){toast(err.message,'error');}break;
      case 'save-branding':{
        el.disabled=true;el.classList.add('loading');
        try{
          await api('/api/admin/settings',{method:'PATCH',body:{
            siteName:$('#s-siteName').value,tagline:$('#s-tagline').value,
            accent:$('#s-accent-text').value||$('#s-accent').value,
            registrationEnabled:$('#s-reg').checked,
          }});
          toast('Branding saved','success');
          S.config.siteName=$('#s-siteName').value;
          S.config.accent=$('#s-accent-text').value;
          applyBrand();
        }catch(err){toast(err.message,'error');}
        finally{el.disabled=false;el.classList.remove('loading');}
        break;}
      case 'save-storage-settings':{
        el.disabled=true;el.classList.add('loading');
        try{
          await api('/api/admin/settings',{method:'PATCH',body:{
            defaultQuota:parseInt($('#s-quota').value||5)*GIB,
            maxUpload:parseInt($('#s-maxUpload').value||0)*MIB,
          }});
          toast('Storage settings saved','success');
        }catch(err){toast(err.message,'error');}
        finally{el.disabled=false;el.classList.remove('loading');}
        break;}
      case 'save-infra-settings':{
        el.disabled=true;el.classList.add('loading');
        try{
          await api('/api/admin/settings',{method:'PATCH',body:{
            maxMachinesPerUser:parseInt($('#s-maxMachines').value)||5,
            maxCpuPerInstance:parseInt($('#s-maxCpu').value)||16,
            maxRamPerInstance:parseInt($('#s-maxRam').value)||32768,
            maxDiskPerInstance:parseInt($('#s-maxDisk').value)||500,
            requireProvisioningApproval:$('#s-approval').checked,
          }});
          toast('Infrastructure settings saved','success');
        }catch(err){toast(err.message,'error');}
        finally{el.disabled=false;el.classList.remove('loading');}
        break;}
      case 'open-entry':
        if(el.dataset.kind==='folder'){S.parent=el.dataset.id;loadFiles();}
        break;
      case 'delete-entry':{
        const id=el.closest('tr')?.querySelector('.file-name-cell')?.dataset?.id||el.dataset.id;
        if(!id||!confirm('Move to trash?'))break;
        try{await api(`/api/entries/${id}`,{method:'DELETE'});loadFiles();}
        catch(err){toast(err.message,'error');}
        break;}
    }
  }catch(err){
    console.error('Action error:',action,err);
    toast(err.message||'An error occurred','error');
  }
});

// ===== INIT =====
async function init(){
  try{S.config=await api('/api/config');applyBrand();}catch{}
  try{
    const data=await api('/api/me');
    S.user=data.user;S.csrf=data.csrf;S.maxUpload=data.maxUpload;S.chunkSize=data.settings?.uploadChunkSize||20*MIB;
    const [wData]=await Promise.all([api('/api/workloads'),api('/api/jobs').then(d=>{S.jobs=d.jobs;}).catch(()=>{})]);
    S.workloads=wData.workloads||[];
    renderApp();
  }catch{renderAuth();}
}
init();

import { DatabaseSync } from 'node:sqlite';
import { mkdirSync, readFileSync, writeFileSync, chmodSync } from 'node:fs';
import path from 'node:path';
import { randomBytes } from 'node:crypto';
import { GiB, MiB } from './config.mjs';

export function openStore(dataDir) {
  mkdirSync(dataDir, { recursive: true, mode: 0o700 });
  for (const dir of ['blobs', 'tmp']) mkdirSync(path.join(dataDir, dir), { recursive: true, mode: 0o700 });
  const keyPath = path.join(dataDir, 'encryption.key');
  let key;
  try { key = readFileSync(keyPath); }
  catch (error) {
    if (error.code !== 'ENOENT') throw error;
    try { readFileSync(path.join(dataDir, 'cloud.sqlite')); throw new Error('Missing encryption.key: restore it from your backup before starting.'); }
    catch (dbError) { if (dbError.code !== 'ENOENT') throw dbError; }
    key = randomBytes(32);
    writeFileSync(keyPath, key, { flag: 'wx', mode: 0o600 });
  }
  if (key.length !== 32) throw new Error('Invalid encryption key');
  const db = new DatabaseSync(path.join(dataDir, 'cloud.sqlite'));
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;
    PRAGMA busy_timeout = 5000;

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL COLLATE NOCASE,
      email TEXT UNIQUE NOT NULL COLLATE NOCASE, display_name TEXT NOT NULL,
      password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('owner','admin','member')),
      quota INTEGER NOT NULL CHECK(quota >= 0), active INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL
    );
    CREATE UNIQUE INDEX IF NOT EXISTS one_owner ON users(role) WHERE role='owner';

    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      csrf TEXT NOT NULL, expires_at INTEGER NOT NULL, created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS sessions_expiry ON sessions(expires_at);

    CREATE TABLE IF NOT EXISTS entries (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      parent_id TEXT REFERENCES entries(id) ON DELETE CASCADE,
      name TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('file','folder')),
      size INTEGER NOT NULL DEFAULT 0, mime TEXT NOT NULL DEFAULT 'application/octet-stream',
      blob TEXT, iv TEXT, tag TEXT, starred INTEGER NOT NULL DEFAULT 0,
      deleted_at INTEGER, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
      storage_format TEXT NOT NULL DEFAULT 'legacy'
    );
    CREATE UNIQUE INDEX IF NOT EXISTS live_entry_names ON entries(user_id, COALESCE(parent_id,''),name) WHERE deleted_at IS NULL;
    CREATE INDEX IF NOT EXISTS entries_user ON entries(user_id, parent_id, deleted_at);

    CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);

    CREATE TABLE IF NOT EXISTS audit (
      id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT, action TEXT NOT NULL,
      target TEXT, detail TEXT, created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS upload_sessions (
      id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      parent_id TEXT, name TEXT NOT NULL, size INTEGER NOT NULL CHECK(size >= 0),
      chunk_size INTEGER NOT NULL, mime TEXT NOT NULL DEFAULT 'application/octet-stream',
      state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','complete')),
      entry_id TEXT REFERENCES entries(id) ON DELETE SET NULL,
      created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS upload_sessions_user ON upload_sessions(user_id,state);
    CREATE INDEX IF NOT EXISTS upload_sessions_expiry ON upload_sessions(expires_at);
    CREATE UNIQUE INDEX IF NOT EXISTS pending_upload_names ON upload_sessions(user_id,COALESCE(parent_id,''),name) WHERE state='pending';

    CREATE TABLE IF NOT EXISTS upload_parts (
      upload_id TEXT NOT NULL REFERENCES upload_sessions(id) ON DELETE CASCADE,
      part_index INTEGER NOT NULL, size INTEGER NOT NULL, blob TEXT UNIQUE NOT NULL,
      iv TEXT NOT NULL, tag TEXT NOT NULL, sha256 TEXT NOT NULL,
      PRIMARY KEY(upload_id,part_index)
    );

    CREATE TABLE IF NOT EXISTS file_parts (
      entry_id TEXT NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
      part_index INTEGER NOT NULL, size INTEGER NOT NULL, blob TEXT UNIQUE NOT NULL,
      iv TEXT NOT NULL, tag TEXT NOT NULL, sha256 TEXT NOT NULL,
      PRIMARY KEY(entry_id,part_index)
    );

    /* ============ ARABICLOUD INFRASTRUCTURE TABLES ============ */

    CREATE TABLE IF NOT EXISTS nodes (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      hostname TEXT NOT NULL,
      ip_address TEXT NOT NULL,
      api_endpoint TEXT NOT NULL,
      provider_type TEXT NOT NULL CHECK(provider_type IN ('docker','kvm','proxmox')),
      location TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '',
      os_info TEXT NOT NULL DEFAULT '',
      architecture TEXT NOT NULL DEFAULT 'x86_64',
      cpu_cores INTEGER NOT NULL DEFAULT 0,
      cpu_allocated INTEGER NOT NULL DEFAULT 0,
      ram_total INTEGER NOT NULL DEFAULT 0,
      ram_allocated INTEGER NOT NULL DEFAULT 0,
      disk_total INTEGER NOT NULL DEFAULT 0,
      disk_allocated INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'offline' CHECK(status IN ('online','offline','maintenance','error','detected','connected','ready','degraded')),
      scheduling_enabled INTEGER NOT NULL DEFAULT 1,
      maintenance_mode INTEGER NOT NULL DEFAULT 0,
      last_heartbeat INTEGER,
      last_error TEXT,
      credentials_encrypted TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS node_health_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      node_id TEXT NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
      status TEXT NOT NULL,
      latency_ms INTEGER,
      error TEXT,
      checked_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS node_health_node ON node_health_history(node_id, checked_at);

    CREATE TABLE IF NOT EXISTS storage_pools (
      id TEXT PRIMARY KEY,
      node_id TEXT NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      path TEXT NOT NULL,
      total_bytes INTEGER NOT NULL DEFAULT 0,
      used_bytes INTEGER NOT NULL DEFAULT 0,
      pool_type TEXT NOT NULL DEFAULT 'dir',
      active INTEGER NOT NULL DEFAULT 1,
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS storage_pools_node ON storage_pools(node_id);

    CREATE TABLE IF NOT EXISTS workloads (
      id TEXT PRIMARY KEY,
      owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      workload_type TEXT NOT NULL CHECK(workload_type IN ('container','vps')),
      provider_type TEXT NOT NULL CHECK(provider_type IN ('docker','kvm','proxmox')),
      node_id TEXT REFERENCES nodes(id) ON DELETE SET NULL,
      provider_resource_id TEXT,
      name TEXT NOT NULL,
      image TEXT NOT NULL DEFAULT '',
      os_template TEXT NOT NULL DEFAULT '',
      cpu_allocated INTEGER NOT NULL DEFAULT 1,
      ram_allocated INTEGER NOT NULL DEFAULT 512,
      disk_allocated INTEGER NOT NULL DEFAULT 10,
      network_config TEXT NOT NULL DEFAULT '{}',
      env_vars TEXT NOT NULL DEFAULT '{}',
      ports TEXT NOT NULL DEFAULT '[]',
      status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','running','stopped','error','deleted')),
      provider_status TEXT,
      ip_address TEXT,
      restart_policy TEXT NOT NULL DEFAULT 'unless-stopped',
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS workloads_owner ON workloads(owner_user_id);
    CREATE INDEX IF NOT EXISTS workloads_node ON workloads(node_id);

    CREATE TABLE IF NOT EXISTS provisioning_jobs (
      id TEXT PRIMARY KEY,
      workload_id TEXT REFERENCES workloads(id) ON DELETE SET NULL,
      node_id TEXT REFERENCES nodes(id) ON DELETE SET NULL,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      job_type TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'queued' CHECK(status IN ('queued','running','success','failed','cancelled')),
      log TEXT NOT NULL DEFAULT '',
      error TEXT,
      attempts INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS jobs_workload ON provisioning_jobs(workload_id);
    CREATE INDEX IF NOT EXISTS jobs_status ON provisioning_jobs(status);

    CREATE TABLE IF NOT EXISTS ip_allocations (
      id TEXT PRIMARY KEY,
      node_id TEXT NOT NULL REFERENCES nodes(id) ON DELETE CASCADE,
      workload_id TEXT REFERENCES workloads(id) ON DELETE SET NULL,
      ip_address TEXT NOT NULL,
      allocated INTEGER NOT NULL DEFAULT 0,
      reserved INTEGER NOT NULL DEFAULT 0,
      created_at INTEGER NOT NULL
    );
    CREATE UNIQUE INDEX IF NOT EXISTS ip_alloc_unique ON ip_allocations(node_id, ip_address);

    CREATE TABLE IF NOT EXISTS resource_quotas (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      max_containers INTEGER NOT NULL DEFAULT 5,
      max_vps INTEGER NOT NULL DEFAULT 3,
      max_cpu INTEGER NOT NULL DEFAULT 8,
      max_ram INTEGER NOT NULL DEFAULT 8192,
      max_disk INTEGER NOT NULL DEFAULT 100,
      allowed_providers TEXT NOT NULL DEFAULT '["docker","kvm"]',
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS nas_servers (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      endpoint TEXT NOT NULL,
      nas_type TEXT NOT NULL DEFAULT 'generic',
      description TEXT NOT NULL DEFAULT '',
      location TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'disconnected' CHECK(status IN ('connected','disconnected','offline','error')),
      credentials_encrypted TEXT,
      last_health INTEGER,
      last_error TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS nas_volumes (
      id TEXT PRIMARY KEY,
      nas_id TEXT NOT NULL REFERENCES nas_servers(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      path TEXT NOT NULL,
      size_bytes INTEGER NOT NULL DEFAULT 0,
      used_bytes INTEGER NOT NULL DEFAULT 0,
      volume_type TEXT NOT NULL DEFAULT 'generic',
      status TEXT NOT NULL DEFAULT 'unknown',
      created_at INTEGER NOT NULL
    );

    /* NAS Machines — Docker containers running NAS services */
    CREATE TABLE IF NOT EXISTS nas_machines (
      id TEXT PRIMARY KEY,
      owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      machine_type TEXT NOT NULL DEFAULT 'samba'
        CHECK(machine_type IN ('samba','minio','sftp','webdav','nextcloud','filebrowser','generic')),
      node_id TEXT REFERENCES nodes(id) ON DELETE SET NULL,
      workload_id TEXT REFERENCES workloads(id) ON DELETE SET NULL,
      provider_resource_id TEXT,
      status TEXT NOT NULL DEFAULT 'creating'
        CHECK(status IN ('creating','running','stopped','error','deleted')),
      ip_address TEXT,
      access_port INTEGER,
      access_protocol TEXT NOT NULL DEFAULT 'smb',
      access_path TEXT NOT NULL DEFAULT '/',
      username TEXT,
      password_hash TEXT,
      quota_gb INTEGER NOT NULL DEFAULT 50,
      used_bytes INTEGER NOT NULL DEFAULT 0,
      description TEXT NOT NULL DEFAULT '',
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    /* Files stored inside a NAS machine (tracked by ArabiCloud) */
    CREATE TABLE IF NOT EXISTS nas_files (
      id TEXT PRIMARY KEY,
      machine_id TEXT NOT NULL REFERENCES nas_machines(id) ON DELETE CASCADE,
      owner_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      parent_id TEXT REFERENCES nas_files(id) ON DELETE CASCADE,
      name TEXT NOT NULL,
      kind TEXT NOT NULL DEFAULT 'file' CHECK(kind IN ('file','folder')),
      size INTEGER NOT NULL DEFAULT 0,
      mime TEXT NOT NULL DEFAULT 'application/octet-stream',
      blob TEXT,
      iv TEXT,
      tag TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS nas_files_machine ON nas_files(machine_id, parent_id);
    CREATE UNIQUE INDEX IF NOT EXISTS nas_files_unique_name ON nas_files(machine_id, COALESCE(parent_id,''), name)
      WHERE kind='file';

    CREATE TABLE IF NOT EXISTS detection_runs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      node_id TEXT REFERENCES nodes(id) ON DELETE SET NULL,
      triggered_by TEXT,
      result TEXT NOT NULL DEFAULT 'pending' CHECK(result IN ('pending','success','partial','failed')),
      detection_data TEXT,
      warnings TEXT,
      created_at INTEGER NOT NULL,
      completed_at INTEGER
    );
  `);

  // User metadata extension (separate table for backward compatibility)
  db.exec(`
    CREATE TABLE IF NOT EXISTS user_meta (
      user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
      last_login INTEGER,
      machine_limit INTEGER NOT NULL DEFAULT 5,
      can_create_machines INTEGER NOT NULL DEFAULT 1,
      updated_at INTEGER NOT NULL DEFAULT 0
    );
  `);

  // Migrate nodes table: add new columns if missing (safe, idempotent)
  const nodeCols = db.prepare('PRAGMA table_info(nodes)').all().map(c => c.name);
  if (!nodeCols.includes('is_local'))
    db.exec('ALTER TABLE nodes ADD COLUMN is_local INTEGER NOT NULL DEFAULT 0');
  if (!nodeCols.includes('provider_statuses'))
    db.exec("ALTER TABLE nodes ADD COLUMN provider_statuses TEXT NOT NULL DEFAULT '{}'");
  if (!nodeCols.includes('detection_data'))
    db.exec('ALTER TABLE nodes ADD COLUMN detection_data TEXT');
  // Migrate status values to extended set (no data loss)
  db.exec("UPDATE nodes SET status='connected' WHERE status='online'");

  const defaults = {
    siteName: 'ArabiCloud', tagline: 'Cloud Infrastructure Management', registrationEnabled: true,
    defaultQuota: 5 * GiB, maxUpload: 0, uploadChunkSize: 20 * MiB, accent: '#6366f1', logo: '', favicon: '',
    globalStorageCapacity: 0, systemReserve: 50 * GiB, storageMode: 'logical',
    maxMachinesPerUser: 5, maxCpuPerInstance: 16, maxRamPerInstance: 32768, maxDiskPerInstance: 500,
    allowedProviders: JSON.stringify(['docker','kvm']),
    requireProvisioningApproval: false,
  };
  for (const [name, value] of Object.entries(defaults))
    db.prepare('INSERT OR IGNORE INTO settings VALUES (?,?)').run(name, JSON.stringify(value));

  if (db.prepare('PRAGMA user_version').get().user_version < 3) {
    transaction(db, () => {
      db.prepare("UPDATE settings SET value='0' WHERE key='maxUpload'").run();
      db.exec('PRAGMA user_version = 3');
    });
  }

  try { chmodSync(path.join(dataDir, 'cloud.sqlite'), 0o600); chmodSync(keyPath, 0o600); } catch {}
  return { db, key, dataDir };
}

export function settings(db) {
  return Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map(row => [row.key, JSON.parse(row.value)]));
}
export function usage(db, userId) { return db.prepare("SELECT COALESCE(SUM(size),0) AS bytes FROM entries WHERE user_id=? AND kind='file'").get(userId).bytes; }
export function publicUser(db, user) {
  const meta = db.prepare('SELECT * FROM user_meta WHERE user_id=?').get(user.id);
  const quota_row = db.prepare('SELECT * FROM resource_quotas WHERE user_id=?').get(user.id);
  return {
    id: user.id, username: user.username, email: user.email, displayName: user.display_name,
    role: user.role, quota: user.quota, active: !!user.active, used: usage(db, user.id),
    createdAt: user.created_at, lastLogin: meta?.last_login || null,
    machineLimit: meta?.machine_limit ?? 5, canCreateMachines: meta ? !!meta.can_create_machines : true,
    resourceQuota: quota_row ? {
      maxContainers: quota_row.max_containers, maxVps: quota_row.max_vps,
      maxCpu: quota_row.max_cpu, maxRam: quota_row.max_ram, maxDisk: quota_row.max_disk,
      allowedProviders: JSON.parse(quota_row.allowed_providers),
    } : null,
  };
}
export function audit(db, actor, action, target = '', detail = '') {
  db.prepare('INSERT INTO audit(actor,action,target,detail,created_at) VALUES (?,?,?,?,?)').run(actor || null, action, target, detail.slice(0,300), Date.now());
  db.prepare('DELETE FROM audit WHERE id <= (SELECT MAX(id)-10000 FROM audit)').run();
}
export function transaction(db, action) {
  db.exec('BEGIN IMMEDIATE');
  try { const result = action(); db.exec('COMMIT'); return result; }
  catch (error) { db.exec('ROLLBACK'); throw error; }
}

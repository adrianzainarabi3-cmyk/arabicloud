import http from 'node:http';
import { isIP } from 'node:net';
import path from 'node:path';
import { createWriteStream } from 'node:fs';
import { readFile, rename, unlink, statfs } from 'node:fs/promises';
import { randomUUID, randomBytes, createCipheriv } from 'node:crypto';
import { pipeline } from 'node:stream/promises';
import { Transform, Readable } from 'node:stream';
import { fileURLToPath } from 'node:url';
import { config, serviceUrls, ROOT, GiB, MiB } from './config.mjs';
import { openStore, settings, usage, publicUser, audit, transaction } from './database.mjs';
import { fail, HttpError, token, digest, hashPassword, verifyPassword, identity, entryName, integer, cookies, rateLimiter } from './security.mjs';
import { acquireLock } from './lock.mjs';
import { createTransfers, reservedUploads, reservedName, entryBlobs, deleteBlobs, downloadRange, downloadBytes } from './transfers.mjs';
import { BRAND } from './branding.mjs';
import { publicNode, createNode, updateNode, testNodeConnection, heartbeatNode } from './nodes.mjs';
import { publicWorkload, createWorkload, deleteWorkload, updateWorkloadStatus } from './workloads.mjs';
import { detectLocalNode, registerOrUpdateLocalNode } from './detection.mjs';
import { listContainers, inspectContainer, containerStats, createContainer, startContainer, stopContainer, restartContainer, deleteContainer, getContainerLogs, pullImage } from './docker-provider.mjs';
import { agentHealth, listVMs, inspectVM, createVM, startVM, stopVM, restartVM, deleteVM, listOSTemplates } from './kvm-provider.mjs';
import { publicNAS, createNASServer, refreshNASStatus } from './nas.mjs';
import { NAS_IMAGES, publicMachine, listNASMachines, createNASMachine, updateMachineStatus, listNASFiles, getNASMachine, createNASFolder, recordNASUpload, deleteNASFile, deleteNASMachine } from './nas-machines.mjs';
import { schedulerFindNode, reserveResources, releaseResources, checkUserQuota } from './scheduler.mjs';

const SESSION = BRAND.sessionCookie;
const STATIC = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
  '/theme.js': ['theme.js', 'text/javascript; charset=utf-8'],
  '/fingerprint.js': ['fingerprint.js', 'text/javascript; charset=utf-8'],
  '/styles.css': ['styles.css', 'text/css; charset=utf-8'],
  '/mark.svg': ['mark.svg', 'image/svg+xml'],
};

const imageType = bytes => {
  if (bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) return 'image/png';
  if (bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255) return 'image/jpeg';
  if (['GIF87a','GIF89a'].includes(bytes.subarray(0,6).toString())) return 'image/gif';
  if (bytes.subarray(0,4).toString() === 'RIFF' && bytes.subarray(8,12).toString() === 'WEBP') return 'image/webp';
  return null;
};

function brandingImage(value) {
  if (value === '') return '';
  if (typeof value !== 'string' || value.length > 1400000) fail(400, 'Brand image must be smaller than 1 MB.');
  const match = /^data:(image\/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$/.exec(value);
  if (!match || imageType(Buffer.from(match[2], 'base64')) !== match[1]) fail(400, 'Use a PNG, JPEG or WebP image. SVG and HTML are not accepted.');
  return value;
}

async function body(req, max = 32768) {
  if (!String(req.headers['content-type'] || '').startsWith('application/json')) fail(415, 'Expected application/json.');
  let total = 0; const chunks = [];
  for await (const chunk of req) { total += chunk.length; if (total > max) fail(413, 'Request is too large.'); chunks.push(chunk); }
  try { const value = JSON.parse(Buffer.concat(chunks).toString('utf8')); if (!value || Array.isArray(value) || typeof value !== 'object') throw new Error(); return value; }
  catch { fail(400, 'Invalid JSON request.'); }
}

function json(res, status, value) { res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' }); res.end(JSON.stringify(value)); }
function sqlError(error) {
  if (String(error.message).includes('UNIQUE constraint failed')) return new HttpError(409, 'That name, username or email already exists.');
  return error;
}

export async function createApp(overrides = {}) {
  const cfg = config(overrides);
  const releaseLock = acquireLock(cfg.dataDir);
  let store;
  try { store = openStore(cfg.dataDir); }
  catch (error) { releaseLock(); throw error; }
  const { db, key, dataDir } = store;
  const limiter = rateLimiter();
  const uploads = new Map();
  let reservedDisk = 0;
  const dummyPassword = await hashPassword(randomBytes(24).toString('hex'));

  function current(req) {
    const raw = cookies(req.headers.cookie)[SESSION];
    if (!raw || raw.length > 100) fail(401, 'Please sign in to continue.');
    const session = db.prepare('SELECT * FROM sessions WHERE token_hash=? AND expires_at>?').get(digest(raw), Date.now());
    const user = session && db.prepare('SELECT * FROM users WHERE id=? AND active=1').get(session.user_id);
    if (!user) fail(401, 'Your session has expired. Please sign in.');
    return { user, session };
  }
  function csrf(req, session) { if (req.headers['x-csrf-token'] !== session.csrf) fail(403, 'Security token is missing or expired. Refresh the page.'); }
  function owner(user) { if (user.role !== 'owner') fail(403, 'Only the owner can change these settings.'); }
  function staff(user) { if (!['admin','owner'].includes(user.role)) fail(403, 'Administrator access required.'); }
  function manageable(user, target) {
    staff(user);
    if (!target) fail(404, 'Account not found.');
    if (target.role === 'owner' || (user.role === 'admin' && target.role !== 'member')) fail(403, 'You cannot manage this account.');
    if (uploads.has(target.id)) fail(409, 'This account has an upload in progress. Try again shortly.');
  }
  function entry(userId, id, deleted = false) {
    const result = db.prepare('SELECT * FROM entries WHERE id=? AND user_id=?').get(id, userId);
    if (!result || (!!result.deleted_at !== deleted)) fail(404, 'File or folder not found.');
    return result;
  }
  function parent(userId, id) {
    if (id === null || id === undefined || id === '') return null;
    if (typeof id !== 'string') fail(400, 'Invalid folder.');
    const folder = entry(userId, id);
    if (folder.kind !== 'folder') fail(400, 'Choose a folder.');
    return folder.id;
  }
  function subtree(userId, id) {
    return db.prepare(`WITH RECURSIVE tree AS (SELECT * FROM entries WHERE id=? AND user_id=? UNION ALL SELECT e.* FROM entries e JOIN tree t ON e.parent_id=t.id WHERE e.user_id=?) SELECT * FROM tree`).all(id, userId, userId);
  }
  function breadcrumbs(userId, id) {
    const result = []; let cursor = id;
    while (cursor) { if (result.length >= 64) fail(400, 'Folder nesting limit reached.'); const folder = entry(userId, cursor); result.unshift({ id: folder.id, name: folder.name }); cursor = folder.parent_id; }
    return result;
  }
  function cookie(res, value, seconds) {
    res.setHeader('Set-Cookie', `${SESSION}=${value}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${seconds}${cfg.secureCookie ? '; Secure' : ''}`);
  }
  function signIn(res, user, remember = false) {
    const raw = token(), csrfToken = token(); const seconds = remember ? 7 * 86400 : 12 * 3600;
    db.prepare('INSERT INTO sessions VALUES (?,?,?,?,?)').run(digest(raw), user.id, csrfToken, Date.now() + seconds * 1000, Date.now());
    db.prepare('DELETE FROM sessions WHERE user_id=? AND token_hash NOT IN (SELECT token_hash FROM sessions WHERE user_id=? ORDER BY created_at DESC LIMIT 10)').run(user.id, user.id);
    db.prepare('INSERT INTO user_meta(user_id,last_login,updated_at) VALUES(?,?,?) ON CONFLICT(user_id) DO UPDATE SET last_login=excluded.last_login,updated_at=excluded.updated_at').run(user.id,Date.now(),Date.now());
    cookie(res, raw, seconds);
    return { user: publicUser(db, user), csrf: csrfToken };
  }
  async function removeRows(rows) {
    const ids = new Set(rows.map(e => e.id));
    transfers.protectsFolders(rows[0]?.user_id, rows.filter(row => row.kind === 'folder').map(row => row.id));
    const blobs = entryBlobs(db,rows);
    transaction(db, () => { for (const row of rows) if (!row.parent_id || !ids.has(row.parent_id)) db.prepare('DELETE FROM entries WHERE id=?').run(row.id); });
    await deleteBlobs(dataDir,blobs);
  }
  function entryView(e) { return { id: e.id, parentId: e.parent_id, name: e.name, kind: e.kind, size: e.size, mime: e.mime, starred: !!e.starred, deletedAt: e.deleted_at, createdAt: e.created_at, updatedAt: e.updated_at }; }
  const transfers = createTransfers({ db,key,dataDir,activeUploads:uploads,parent,imageType,legacyReservation:() => reservedDisk });
  try { await transfers.initialize(); }
  catch (error) { limiter.close(); db.close(); releaseLock(); throw error; }

  // ===== NODE HEARTBEAT INTERVAL =====
  const nodeHealthCheck = setInterval(async () => {
    const nodes = db.prepare("SELECT * FROM nodes WHERE status != 'maintenance'").all();
    for (const node of nodes) {
      try { await heartbeatNode(db, node); } catch {}
    }
  }, 60000);
  nodeHealthCheck.unref();

  // ===== LOCAL NODE AUTO-DETECTION ON STARTUP =====
  setImmediate(async () => {
    try {
      const detection = await detectLocalNode();
      registerOrUpdateLocalNode(db, detection, null, 'Local Node');
    } catch (err) {
      console.error('Local node detection failed:', err.message);
    }
  });

  // Re-detect local node every 5 minutes
  const localDetectionInterval = setInterval(async () => {
    try {
      const detection = await detectLocalNode();
      registerOrUpdateLocalNode(db, detection, null);
    } catch {}
  }, 5 * 60000);
  localDetectionInterval.unref();

  async function handle(req, res) {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'same-origin');
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");
    res.setHeader('Cache-Control', 'no-store');
    if (cfg.appUrl.startsWith('https:') && cfg.secureCookie) res.setHeader('Strict-Transport-Security', 'max-age=31536000');
    let allowedOrigin = cfg.appUrl;
    if (!cfg.explicitAppUrl) {
      let target;
      try { target = new URL(`http://${req.headers.host}`); } catch { fail(400, 'Invalid service address.'); }
      const hostname = target.hostname.replace(/^\[|\]$/g, '');
      const port = server.address()?.port ?? cfg.port;
      if ((hostname !== 'localhost' && !isIP(hostname)) || Number(target.port || 80) !== port || target.username || target.password || target.pathname !== '/' || target.search || target.hash) fail(400, 'Use localhost or the server IP address with the service port.');
      allowedOrigin = target.origin;
    }
    const url = new URL(req.url, cfg.appUrl), route = url.pathname, method = req.method;
    const ip = cfg.trustProxy ? String(req.headers['x-forwarded-for'] || req.socket.remoteAddress).split(',')[0].trim() : req.socket.remoteAddress;
    if (route.startsWith('/api/')) limiter.check(`api:${ip}`, 1200, 60000);
    if (!['GET','HEAD','OPTIONS'].includes(method)) {
      if (req.headers.origin && req.headers.origin !== allowedOrigin) fail(403, 'Cross-origin requests are not allowed.');
      if (req.headers['sec-fetch-site'] === 'cross-site') fail(403, 'Cross-site requests are not allowed.');
    }

    // ── Public API ──────────────────────────────────────────────────────────
    if (route === '/api/health' && method === 'GET') return json(res, 200, { status: 'ok', version: BRAND.version, product: BRAND.name });
    if (route === '/api/config' && method === 'GET') {
      const s = settings(db);
      return json(res, 200, { siteName: s.siteName, tagline: s.tagline, logo: s.logo, favicon: s.favicon, accent: s.accent, registrationEnabled: s.registrationEnabled, defaultQuota: s.defaultQuota, googleEnabled: false, setupRequired: !db.prepare("SELECT id FROM users WHERE role='owner'").get() });
    }
    if ((route === '/api/auth/login' || route === '/api/auth/register') && method === 'POST') {
      limiter.check(`auth:${ip}`, 20);
      const input = await body(req);
      if (route.endsWith('login')) {
        const identifier = String(input.identifier || '').trim().toLowerCase();
        limiter.check(`login:${digest(identifier)}`, 30);
        const user = identifier.length <= 254 && db.prepare('SELECT * FROM users WHERE email=? OR username=?').get(identifier, identifier);
        const valid = await verifyPassword(input.password, user ? user.password_hash : dummyPassword);
        if (!valid || !user || !user.active) fail(401, 'Email / username or password is incorrect.');
        audit(db, user.id, 'auth.login', user.id);
        return json(res, 200, signIn(res, user, input.remember === true));
      }
      limiter.check(`register:${ip}`, 5, 3600000);
      if (!db.prepare("SELECT id FROM users WHERE role='owner'").get()) fail(503, 'The owner must finish server setup first.');
      if (!settings(db).registrationEnabled) fail(403, 'Registration is closed. Contact the cloud owner.');
      const data = identity(input);
      if (cfg.registrationDomain && data.email.split('@')[1] !== cfg.registrationDomain) fail(400, `Registration is restricted to @${cfg.registrationDomain}.`);
      const passwordHash = await hashPassword(input.password);
      const user = transaction(db, () => {
        const s = settings(db); if (!s.registrationEnabled) fail(403, 'Registration is closed.');
        const id = randomUUID();
        db.prepare('INSERT INTO users(id,username,email,display_name,password_hash,role,quota,active,created_at) VALUES (?,?,?,?,?,?,?,?,?)').run(id, data.username, data.email, data.displayName, passwordHash, 'member', s.defaultQuota, 1, Date.now());
        return db.prepare('SELECT * FROM users WHERE id=?').get(id);
      });
      audit(db, user.id, 'user.register', user.id);
      return json(res, 201, signIn(res, user));
    }

    // ── Authenticated API ────────────────────────────────────────────────────
    if (route.startsWith('/api/')) {
      const { user, session } = current(req);
      if (!['GET','HEAD'].includes(method)) csrf(req, session);

      // ── Me / Account ──
      if (route === '/api/me' && method === 'GET') {
        const s = settings(db);
        return json(res,200,{ user:publicUser(db,user),csrf:session.csrf,maxUpload:s.maxUpload,uploadChunkSize:s.uploadChunkSize,settings:{uploadChunkSize:s.uploadChunkSize},reservedUploadBytes:reservedUploads(db,user.id) });
      }
      if (route === '/api/auth/logout' && method === 'POST') {
        db.prepare('DELETE FROM sessions WHERE token_hash=?').run(session.token_hash); cookie(res, '', 0); return json(res, 200, { ok: true });
      }
      if (route === '/api/account' && method === 'PATCH') {
        const input = await body(req);
        if (!await verifyPassword(input.currentPassword, user.password_hash)) fail(403, 'Current password is incorrect.');
        const passwordHash = await hashPassword(input.newPassword);
        db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(passwordHash, user.id);
        db.prepare('DELETE FROM sessions WHERE user_id=?').run(user.id);
        audit(db, user.id, 'auth.password_changed', user.id);
        cookie(res, '', 0); return json(res, 200, { ok: true });
      }

      // ── Sessions ──
      if (route === '/api/sessions' && method === 'GET') {
        const rows = db.prepare('SELECT token_hash,created_at,expires_at FROM sessions WHERE user_id=? ORDER BY created_at DESC').all(user.id);
        return json(res, 200, { sessions: rows.map(s => ({ id: s.token_hash.slice(0,8), createdAt: s.created_at, expiresAt: s.expires_at, current: s.token_hash === session.token_hash })) });
      }
      if (route === '/api/sessions/revoke-all' && method === 'POST') {
        db.prepare('DELETE FROM sessions WHERE user_id=? AND token_hash!=?').run(user.id, session.token_hash);
        audit(db, user.id, 'auth.revoke_sessions', user.id);
        return json(res, 200, { ok: true });
      }

      // ── Workloads (user) ──
      if (route === '/api/workloads' && method === 'GET') {
        const type = url.searchParams.get('type');
        let q = "SELECT * FROM workloads WHERE owner_user_id=? AND status != 'deleted'";
        const params = [user.id];
        if (type) { q += ' AND workload_type=?'; params.push(type); }
        q += ' ORDER BY created_at DESC LIMIT 200';
        return json(res, 200, { workloads: db.prepare(q).all(...params).map(publicWorkload) });
      }
      if (route === '/api/workloads' && method === 'POST') {
        const userMeta = db.prepare('SELECT * FROM user_meta WHERE user_id=?').get(user.id);
        if (userMeta && !userMeta.can_create_machines) fail(403, 'Machine creation is disabled for your account.');
        const input = await body(req);
        const s = settings(db);
        // Check user machine limit
        const existingCount = db.prepare("SELECT COUNT(*) AS c FROM workloads WHERE owner_user_id=? AND status != 'deleted'").get(user.id).c;
        const limit = userMeta?.machine_limit ?? s.maxMachinesPerUser;
        if (limit > 0 && existingCount >= limit) fail(409, `Machine limit reached (${limit}). Contact an administrator.`);
        const result = createWorkload(db, user.id, input);
        return json(res, 201, { workload: publicWorkload(result.workload), jobId: result.jobId });
      }
      const workloadMatch = /^\/api\/workloads\/([a-f0-9-]{36})(?:\/(start|stop|restart|logs))?$/.exec(route);
      if (workloadMatch) {
        const [, wId, action] = workloadMatch;
        const w = db.prepare("SELECT * FROM workloads WHERE id=? AND owner_user_id=? AND status != 'deleted'").get(wId, user.id)
          || (staff(user), db.prepare("SELECT * FROM workloads WHERE id=? AND status != 'deleted'").get(wId));
        if (!w) fail(404, 'Workload not found.');
        if (!action && method === 'GET') return json(res, 200, { workload: publicWorkload(w) });
        if (!action && method === 'DELETE') {
          deleteWorkload(db, user.id, wId);
          return json(res, 200, { ok: true });
        }
        if (action && method === 'POST') {
          const node = w.node_id ? db.prepare('SELECT * FROM nodes WHERE id=?').get(w.node_id) : null;
          if (!node || node.status !== 'online') fail(503, 'Target node is offline or unavailable.');
          // Record lifecycle job
          const jobId = randomUUID(), now = Date.now();
          db.prepare('INSERT INTO provisioning_jobs(id,workload_id,node_id,user_id,job_type,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)').run(jobId, wId, w.node_id, user.id, `${w.workload_type}.${action}`, 'queued', now, now);
          audit(db, user.id, `workload.${action}`, wId, w.name);
          return json(res, 202, { ok: true, jobId, message: `${action} job queued. Check job status for progress.` });
        }
      }

      // ── Provisioning Jobs ──
      if (route === '/api/jobs' && method === 'GET') {
        const rows = db.prepare('SELECT * FROM provisioning_jobs WHERE user_id=? ORDER BY created_at DESC LIMIT 100').all(user.id);
        return json(res, 200, { jobs: rows });
      }
      const jobMatch = /^\/api\/jobs\/([a-f0-9-]{36})$/.exec(route);
      if (jobMatch) {
        const job = db.prepare('SELECT * FROM provisioning_jobs WHERE id=? AND user_id=?').get(jobMatch[1], user.id);
        if (!job) fail(404, 'Job not found.');
        return json(res, 200, { job });
      }

      // ── File entries (preserved) ──
      if (route === '/api/entries' && method === 'GET') {
        const view = url.searchParams.get('view') || 'files', search = (url.searchParams.get('q') || '').trim().slice(0,180);
        const parentId = view === 'files' && !search ? parent(user.id, url.searchParams.get('parent')) : null;
        let filter = 'user_id=?', params = [user.id];
        if (view === 'trash') filter += ' AND deleted_at IS NOT NULL AND (parent_id IS NULL OR parent_id NOT IN (SELECT id FROM entries WHERE user_id=? AND deleted_at IS NOT NULL))', params.push(user.id);
        else { filter += ' AND deleted_at IS NULL'; if (view === 'starred') filter += ' AND starred=1'; if (view === 'photos') filter += " AND mime LIKE 'image/%' AND kind='file'"; }
        if (view === 'files' && !search) { filter += ' AND parent_id IS ?'; params.push(parentId); }
        if (search) { filter += ' AND instr(lower(name),lower(?))>0'; params.push(search); }
        const rows = db.prepare(`SELECT * FROM entries WHERE ${filter} ORDER BY kind DESC,updated_at DESC LIMIT 2000`).all(...params);
        return json(res, 200, { entries: rows.map(entryView), breadcrumbs: breadcrumbs(user.id, parentId), user: publicUser(db, user), total: db.prepare(`SELECT COUNT(*) AS count FROM entries WHERE ${filter}`).get(...params).count });
      }
      if (route === '/api/folders' && method === 'POST') {
        const input = await body(req), name = entryName(input.name), parentId = parent(user.id, input.parentId);
        if (reservedName(db,user.id,parentId,name)) fail(409,'An upload with that name is waiting to complete.');
        if (breadcrumbs(user.id, parentId).length >= 64) fail(400, 'Folder nesting limit reached.');
        const id = randomUUID(), now = Date.now();
        db.prepare("INSERT INTO entries(id,user_id,parent_id,name,kind,created_at,updated_at) VALUES (?,?,?,?,'folder',?,?)").run(id, user.id, parentId, name, now, now);
        audit(db, user.id, 'folder.create', id, name);
        return json(res, 201, { entry: entryView(entry(user.id, id)) });
      }
      if (route === '/api/uploads' && method === 'POST') {
        const result = await transfers.create(user.id,await body(req));
        return json(res,result.replay ? 200 : 201,{upload:result.upload});
      }
      const transferMatch = /^\/api\/uploads\/([a-f0-9-]{36})(?:\/(complete)|\/chunks\/(\d+))?$/.exec(route);
      if (transferMatch) {
        const [,id,action,index] = transferMatch;
        if (!action && index === undefined && method === 'GET') return json(res,200,{upload:transfers.get(user.id,id)});
        if (index !== undefined && method === 'PUT') return json(res,200,{upload:await transfers.put(user.id,id,Number(index),req)});
        if (action === 'complete' && method === 'POST') {
          const result = transfers.complete(user.id,id);
          if (!result.replay) audit(db,user.id,'file.upload',result.entry.id,result.entry.name);
          return json(res,result.replay ? 200 : 201,{entry:entryView(result.entry),user:publicUser(db,db.prepare('SELECT * FROM users WHERE id=?').get(user.id))});
        }
        if (!action && index === undefined && method === 'DELETE') { await transfers.cancel(user.id,id); return json(res,200,{ok:true}); }
      }
      if (route === '/api/upload' && method === 'POST') {
        if (uploads.has(user.id)) fail(409, 'Another upload is in progress for your account.');
        const parentId = parent(user.id, url.searchParams.get('parent'));
        let name; try { name = entryName(decodeURIComponent(String(req.headers['x-file-name'] || ''))); } catch (error) { if (error instanceof HttpError) throw error; fail(400, 'Invalid filename.'); }
        if (db.prepare('SELECT id FROM entries WHERE user_id=? AND parent_id IS ? AND name=? AND deleted_at IS NULL').get(user.id, parentId, name)) fail(409, 'A file with that name already exists.');
        if (reservedName(db,user.id,parentId,name)) fail(409,'An upload with that name is waiting to complete.');
        const freshUser = db.prepare('SELECT * FROM users WHERE id=?').get(user.id);
        const available = freshUser.quota - usage(db, user.id) - reservedUploads(db,user.id);
        const fileLimit = settings(db).maxUpload;
        const max = fileLimit > 0 ? Math.min(fileLimit, available) : available;
        const length = Number(req.headers['content-length']);
        if (!Number.isSafeInteger(length) || length < 0) fail(411, 'A valid Content-Length is required for uploads.');
        if (length > max) fail(413, available < length ? 'Not enough storage. Empty trash or ask an administrator for more space.' : 'This file exceeds the upload limit.');
        await transfers.reserveDisk(length,() => {
          if (uploads.has(user.id)) fail(409, 'Another upload is in progress for your account.');
          parent(user.id,parentId);
          const currentUser = db.prepare('SELECT * FROM users WHERE id=? AND active=1').get(user.id);
          if (!currentUser) fail(401,'This account is no longer active.');
          if (length + usage(db,user.id) + reservedUploads(db,user.id) > currentUser.quota) fail(413,'Not enough storage.');
          const limit = settings(db).maxUpload;
          if (limit > 0 && length > limit) fail(413,'This file exceeds the upload limit.');
          if (reservedName(db,user.id,parentId,name)) fail(409,'An upload with that name is waiting to complete.');
          uploads.set(user.id,true); reservedDisk += length; transfers.diskChanged();
        });
        const id = randomUUID(), temp = path.join(dataDir, 'tmp', id), destination = path.join(dataDir, 'blobs', id);
        let size = 0, header = Buffer.alloc(0), committed = false;
        const iv = randomBytes(12), cipher = createCipheriv('aes-256-gcm', key, iv);
        const counter = new Transform({ transform(chunk, encoding, callback) {
          size += chunk.length;
          if (header.length < 16) header = Buffer.concat([header, chunk.subarray(0, 16-header.length)]);
          callback(size > max || size > length ? new HttpError(413, 'Upload exceeded its allowed size.') : null, chunk);
        } });
        try {
          await pipeline(req, counter, cipher, createWriteStream(temp, { flags: 'wx', mode: 0o600 }));
          if (size !== length) fail(400, 'Upload was interrupted.');
          await rename(temp, destination);
          transaction(db, () => {
            parent(user.id, parentId);
            const updated = db.prepare('SELECT * FROM users WHERE id=? AND active=1').get(user.id);
            if (!updated || size + usage(db, user.id) + reservedUploads(db,user.id) > updated.quota) fail(413, 'Storage quota changed. Please retry.');
            if (reservedName(db,user.id,parentId,name)) fail(409,'An upload with that name is waiting to complete.');
            const now = Date.now();
            db.prepare("INSERT INTO entries(id,user_id,parent_id,name,kind,size,mime,blob,iv,tag,created_at,updated_at) VALUES (?,?,?,?,'file',?,?,?,?,?,?,?)").run(id, user.id, parentId, name, size, imageType(header) || 'application/octet-stream', id, iv.toString('hex'), cipher.getAuthTag().toString('hex'), now, now);
          });
          committed = true; audit(db, user.id, 'file.upload', id, name);
          return json(res, 201, { entry: entryView(entry(user.id, id)), user: publicUser(db, db.prepare('SELECT * FROM users WHERE id=?').get(user.id)) });
        } finally {
          uploads.delete(user.id); reservedDisk -= length; transfers.diskChanged();
          await unlink(temp).catch(() => {});
          if (!committed) await unlink(destination).catch(() => {});
        }
      }
      const match = /^\/api\/entries\/([a-f0-9-]{36})(?:\/(download|restore|purge))?$/.exec(route);
      if (match) {
        const [, id, action] = match;
        const e = entry(user.id, id, ['restore','purge'].includes(action));
        if (action === 'download' && ['GET','HEAD'].includes(method)) {
          if (e.kind !== 'file') fail(400, 'Open the folder to download its files.');
          const etag = `"${e.id}-${e.size}"`;
          let range;
          try { range = downloadRange(req.headers['if-range'] && req.headers['if-range'] !== etag ? undefined : req.headers.range,e.size); }
          catch (error) { if (error.status === 416) res.setHeader('Content-Range',`bytes */${e.size}`); throw error; }
          const inline = url.searchParams.get('preview') === '1' && e.mime.startsWith('image/');
          res.setHeader('Content-Type', inline ? e.mime : 'application/octet-stream');
          res.setHeader('Content-Length', range.length);
          res.setHeader('Accept-Ranges','bytes'); res.setHeader('ETag',etag);
          if (range.status === 206) res.setHeader('Content-Range',`bytes ${range.start}-${range.end}/${e.size}`);
          res.setHeader('Content-Disposition', `${inline ? 'inline' : 'attachment'}; filename="download"; filename*=UTF-8''${encodeURIComponent(e.name).replace(/'/g,'%27')}`);
          res.statusCode = range.status;
          if (method === 'HEAD') { res.end(); return; }
          const abort = new AbortController(),closed = () => abort.abort();
          res.once('close',closed);
          const source = Readable.from(downloadBytes(db,dataDir,key,e,range,abort.signal));
          try {
            for await (const chunk of source) {
              if (res.destroyed) throw new Error('Download connection closed.');
              if (!res.write(chunk)) await new Promise((resolve,reject) => {
                const drain = () => { cleanup(); resolve(); }, disconnected = () => { cleanup(); reject(new Error('Download connection closed.')); };
                const cleanup = () => { res.off('drain',drain); res.off('close',disconnected); };
                res.once('drain',drain); res.once('close',disconnected);
              });
            }
            res.end();
          } finally { res.off('close',closed); abort.abort(); source.destroy(); }
          return;
        }
        if (!action && method === 'PATCH') {
          const input = await body(req); let name = e.name, parentId = e.parent_id, starred = e.starred;
          if ('name' in input) name = entryName(input.name);
          if ('starred' in input) { if (typeof input.starred !== 'boolean') fail(400, 'Invalid starred value.'); starred = input.starred ? 1 : 0; }
          if ('parentId' in input) {
            parentId = parent(user.id, input.parentId);
            const parents = breadcrumbs(user.id, parentId);
            if (parents.some(p => p.id === e.id)) fail(400, 'A folder cannot be moved inside itself.');
            if (e.kind === 'folder') {
              const descendants = subtree(user.id, id);
              const depths = new Map([[id,1]]);
              for (const row of descendants) if (row.id !== id) depths.set(row.id, (depths.get(row.parent_id) || 1)+1);
              if (parents.length + Math.max(...depths.values()) > 64) fail(400, 'Folder nesting limit reached.');
            }
          }
          if (reservedName(db,user.id,parentId,name)) fail(409,'An upload with that name is waiting to complete.');
          db.prepare('UPDATE entries SET name=?,parent_id=?,starred=?,updated_at=? WHERE id=?').run(name, parentId, starred, Date.now(), id);
          audit(db, user.id, 'entry.update', id, name);
          return json(res, 200, { entry: entryView(entry(user.id, id)) });
        }
        if (!action && method === 'DELETE') {
          const rows = subtree(user.id,id);
          transfers.protectsFolders(user.id,rows.filter(row => row.kind === 'folder').map(row => row.id));
          const now = Math.max(Date.now(), db.prepare('SELECT COALESCE(MAX(deleted_at),0)+1 AS next FROM entries WHERE user_id=?').get(user.id).next);
          transaction(db, () => { for (const row of rows) if (!row.deleted_at) db.prepare('UPDATE entries SET deleted_at=?,updated_at=? WHERE id=?').run(now, now, row.id); });
          audit(db, user.id, 'entry.trash', id, e.name);
          return json(res, 200, { ok: true });
        }
        if (action === 'restore' && method === 'POST') {
          const p = e.parent_id && db.prepare('SELECT id FROM entries WHERE id=? AND user_id=? AND deleted_at IS NULL').get(e.parent_id, user.id);
          if (reservedName(db,user.id,p?.id || null,e.name)) fail(409,'An upload with that name is waiting to complete.');
          transaction(db, () => {
            db.prepare('UPDATE entries SET parent_id=? WHERE id=?').run(p?.id || null, id);
            for (const row of subtree(user.id, id)) if (row.deleted_at === e.deleted_at) db.prepare('UPDATE entries SET deleted_at=NULL,updated_at=? WHERE id=?').run(Date.now(), row.id);
          });
          audit(db, user.id, 'entry.restore', id, e.name); return json(res, 200, { ok: true });
        }
        if (action === 'purge' && method === 'DELETE') {
          await removeRows(subtree(user.id, id)); audit(db, user.id, 'entry.purge', id, e.name); return json(res, 200, { ok: true });
        }
      }
      if (route === '/api/trash' && method === 'DELETE') {
        const rows = db.prepare('SELECT * FROM entries WHERE user_id=? AND deleted_at IS NOT NULL').all(user.id);
        await removeRows(rows); audit(db, user.id, 'trash.empty', user.id); return json(res, 200, { ok: true });
      }

      // ── ADMIN: Nodes ──────────────────────────────────────────────────────
      if (route === '/api/admin/nodes' && method === 'GET') {
        staff(user);
        const nodes = db.prepare('SELECT * FROM nodes ORDER BY created_at DESC').all().map(publicNode);
        return json(res, 200, { nodes });
      }
      if (route === '/api/admin/nodes' && method === 'POST') {
        owner(user);
        const input = await body(req);
        const node = createNode(db, user.id, input);
        return json(res, 201, { node: publicNode(node) });
      }
      const nodeMatch = /^\/api\/admin\/nodes\/([a-f0-9-]{36})(?:\/(test|heartbeat|pools))?$/.exec(route);
      if (nodeMatch) {
        const [, nId, action] = nodeMatch;
        staff(user);
        const node = db.prepare('SELECT * FROM nodes WHERE id=?').get(nId);
        if (!node) fail(404, 'Node not found.');
        if (!action && method === 'GET') return json(res, 200, { node: publicNode(node) });
        if (!action && method === 'PATCH') {
          owner(user);
          const input = await body(req);
          return json(res, 200, { node: updateNode(db, user.id, nId, input) });
        }
        if (!action && method === 'DELETE') {
          owner(user);
          const workloadCount = db.prepare("SELECT COUNT(*) AS c FROM workloads WHERE node_id=? AND status NOT IN ('deleted')").get(nId).c;
          if (workloadCount > 0) fail(409, `Cannot remove node: ${workloadCount} active workload(s) still assigned. Migrate or delete them first.`);
          db.prepare('DELETE FROM nodes WHERE id=?').run(nId);
          audit(db, user.id, 'node.delete', nId, node.name);
          return json(res, 200, { ok: true });
        }
        if (action === 'test' && method === 'POST') {
          const result = await testNodeConnection(node.provider_type, node.api_endpoint, node.credentials_encrypted);
          return json(res, 200, { ok: result.ok, result });
        }
        if (action === 'heartbeat' && method === 'POST') {
          const result = await heartbeatNode(db, node);
          return json(res, 200, { ok: result.ok, result, node: publicNode(db.prepare('SELECT * FROM nodes WHERE id=?').get(nId)) });
        }
        if (action === 'pools' && method === 'GET') {
          const pools = db.prepare('SELECT * FROM storage_pools WHERE node_id=?').all(nId);
          return json(res, 200, { pools });
        }
        if (action === 'pools' && method === 'POST') {
          owner(user);
          const input = await body(req);
          const id = randomUUID(), now = Date.now();
          db.prepare('INSERT INTO storage_pools(id,node_id,name,path,total_bytes,pool_type,created_at) VALUES (?,?,?,?,?,?,?)').run(id, nId, input.name||'default', input.path||'/', integer(input.totalBytes||0,0,Number.MAX_SAFE_INTEGER,'Pool size'), input.poolType||'dir', now);
          audit(db, user.id, 'storage_pool.create', id, `${input.name} on ${node.name}`);
          return json(res, 201, { pool: db.prepare('SELECT * FROM storage_pools WHERE id=?').get(id) });
        }
      }

      // ── ADMIN: Workloads ──────────────────────────────────────────────────
      if (route === '/api/admin/workloads' && method === 'GET') {
        staff(user);
        const type = url.searchParams.get('type');
        let q = "SELECT w.*,u.username AS owner_username FROM workloads w JOIN users u ON w.owner_user_id=u.id WHERE w.status != 'deleted'";
        const params = [];
        if (type) { q += ' AND w.workload_type=?'; params.push(type); }
        q += ' ORDER BY w.created_at DESC LIMIT 500';
        return json(res, 200, { workloads: db.prepare(q).all(...params).map(w => ({ ...publicWorkload(w), ownerUsername: w.owner_username })) });
      }

      // ── ADMIN: Provisioning Jobs ──────────────────────────────────────────
      if (route === '/api/admin/jobs' && method === 'GET') {
        staff(user);
        const rows = db.prepare('SELECT j.*,u.username FROM provisioning_jobs j JOIN users u ON j.user_id=u.id ORDER BY j.created_at DESC LIMIT 200').all();
        return json(res, 200, { jobs: rows });
      }

      // ── ADMIN: Admin Overview ─────────────────────────────────────────────
      if (route === '/api/admin/overview' && method === 'GET') {
        staff(user);
        const disk = await statfs(dataDir);
        const nodes = db.prepare('SELECT * FROM nodes').all();
        const onlineNodes = nodes.filter(n => n.status === 'online').length;
        const containers = db.prepare("SELECT COUNT(*) AS c FROM workloads WHERE workload_type='container' AND status != 'deleted'").get().c;
        const vpsInstances = db.prepare("SELECT COUNT(*) AS c FROM workloads WHERE workload_type='vps' AND status != 'deleted'").get().c;
        const totalCpuAllocated = nodes.reduce((s,n) => s+n.cpu_allocated, 0);
        const totalRamAllocated = nodes.reduce((s,n) => s+n.ram_allocated, 0);
        const pendingJobs = db.prepare("SELECT COUNT(*) AS c FROM provisioning_jobs WHERE status IN ('queued','running')").get().c;
        return json(res, 200, {
          users: db.prepare('SELECT COUNT(*) AS count FROM users').get().count,
          activeUsers: db.prepare('SELECT COUNT(*) AS count FROM users WHERE active=1').get().count,
          files: db.prepare("SELECT COUNT(*) AS count FROM entries WHERE kind='file'").get().count,
          used: db.prepare('SELECT COALESCE(SUM(size),0) AS bytes FROM entries').get().bytes,
          diskFree: disk.bavail * disk.bsize, diskTotal: disk.blocks * disk.bsize,
          settings: settings(db), version: BRAND.version, port: cfg.port,
          nodes: nodes.length, onlineNodes, offlineNodes: nodes.length - onlineNodes,
          containers, vpsInstances, totalCpuAllocated, totalRamAllocated,
          pendingJobs,
          recentAudit: db.prepare('SELECT a.*,u.username FROM audit a LEFT JOIN users u ON a.actor=u.id ORDER BY a.id DESC LIMIT 20').all(),
        });
      }

      // ── ADMIN: Users ──────────────────────────────────────────────────────
      if (route === '/api/admin/users' && method === 'GET') {
        staff(user);
        return json(res, 200, { users: db.prepare('SELECT * FROM users ORDER BY created_at DESC LIMIT 2000').all().map(u => publicUser(db, u)) });
      }
      if (route === '/api/admin/users' && method === 'POST') {
        staff(user); const input = await body(req), data = identity(input);
        const role = input.role || 'member';
        if (!['admin','member'].includes(role) || (user.role === 'admin' && role !== 'member')) fail(403, 'Only the owner can create administrators.');
        const quota = integer(input.quota ?? settings(db).defaultQuota, 0, 100000 * GiB, 'Storage quota');
        const passwordHash = await hashPassword(input.password);
        const activeUser = db.prepare('SELECT * FROM users WHERE id=? AND active=1').get(user.id);
        staff(activeUser || {}); if (role === 'admin') owner(activeUser);
        const id = randomUUID();
        db.prepare('INSERT INTO users(id,username,email,display_name,password_hash,role,quota,active,created_at) VALUES (?,?,?,?,?,?,?,?,?)').run(id, data.username, data.email, data.displayName, passwordHash, role, quota, 1, Date.now());
        db.prepare('INSERT OR IGNORE INTO user_meta(user_id,machine_limit,can_create_machines,updated_at) VALUES(?,?,?,?)').run(id, input.machineLimit ?? 5, 1, Date.now());
        audit(db, user.id, 'user.create', id, `${data.username} (${role})`);
        return json(res, 201, { user: publicUser(db, db.prepare('SELECT * FROM users WHERE id=?').get(id)) });
      }
      const userMatch = /^\/api\/admin\/users\/([a-f0-9-]{36})(?:\/(sessions|password|quota))?$/.exec(route);
      if (userMatch) {
        const [, uId, action] = userMatch;
        const target = db.prepare('SELECT * FROM users WHERE id=?').get(uId);
        if (target?.role === 'owner' && user.role === 'owner' && method === 'PATCH' && !action) {
          const input = await body(req);
          if (Object.keys(input).some(k => k !== 'quota') || !('quota' in input)) fail(403, 'The owner role and account status are protected.');
          const quota = integer(input.quota, 0, 100000 * GiB, 'Quota');
          if (quota < usage(db,target.id) + reservedUploads(db,target.id)) fail(400, 'Quota cannot be lower than stored files and pending uploads.');
          db.prepare('UPDATE users SET quota=? WHERE id=?').run(quota,target.id);
          audit(db,user.id,'user.quota',target.id,'Owner storage allowance updated');
          return json(res,200,{user:publicUser(db,db.prepare('SELECT * FROM users WHERE id=?').get(target.id))});
        }
        manageable(user, target);
        if (action === 'sessions' && method === 'DELETE') {
          db.prepare('DELETE FROM sessions WHERE user_id=?').run(uId);
          audit(db,user.id,'user.revoke_sessions',uId,target.username);
          return json(res,200,{ok:true});
        }
        if (action === 'password' && method === 'POST') {
          owner(user);
          const input = await body(req);
          if (!input.newPassword || String(input.newPassword).length < 8) fail(400,'Password must be at least 8 characters.');
          const hash = await hashPassword(String(input.newPassword));
          db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(hash,uId);
          db.prepare('DELETE FROM sessions WHERE user_id=?').run(uId);
          audit(db,user.id,'user.password_reset',uId,target.username);
          return json(res,200,{ok:true});
        }
        if (!action && method === 'PATCH') {
          const input = await body(req);
          manageable(db.prepare('SELECT * FROM users WHERE id=? AND active=1').get(user.id) || {}, db.prepare('SELECT * FROM users WHERE id=?').get(target.id));
          const fresh = db.prepare('SELECT * FROM users WHERE id=?').get(target.id);
          const freshMeta = db.prepare('SELECT * FROM user_meta WHERE user_id=?').get(target.id);
          let role = fresh.role, quota = fresh.quota, active = fresh.active, machineLimit = freshMeta?.machine_limit ?? 5, canCreate = freshMeta ? (freshMeta.can_create_machines ? 1 : 0) : 1;
          if ('role' in input) { owner(user); if (!['admin','member'].includes(input.role)) fail(400, 'Role must be admin or member.'); role = input.role; }
          if ('quota' in input) { quota = integer(input.quota, 0, 100000 * GiB, 'Quota'); if (quota < usage(db, target.id) + reservedUploads(db,target.id)) fail(400, 'Quota cannot be lower than current usage.'); }
          if ('active' in input) { if (typeof input.active !== 'boolean') fail(400, 'Invalid account status.'); active = input.active ? 1 : 0; }
          if ('machineLimit' in input) { machineLimit = integer(input.machineLimit, 0, 9999, 'Machine limit'); }
          if ('canCreateMachines' in input) { canCreate = input.canCreateMachines ? 1 : 0; }
          const updateAccount = () => {
            manageable(db.prepare('SELECT * FROM users WHERE id=? AND active=1').get(user.id) || {},db.prepare('SELECT * FROM users WHERE id=?').get(target.id));
            db.prepare('UPDATE users SET role=?,quota=?,active=? WHERE id=?').run(role, quota, active, target.id);
            db.prepare('INSERT INTO user_meta(user_id,machine_limit,can_create_machines,updated_at) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET machine_limit=excluded.machine_limit,can_create_machines=excluded.can_create_machines,updated_at=excluded.updated_at').run(target.id, machineLimit, canCreate, Date.now());
            if (role !== fresh.role || !active) db.prepare('DELETE FROM sessions WHERE user_id=?').run(target.id);
          };
          if (!active) await transfers.cancelUser(target.id,updateAccount);
          else updateAccount();
          audit(db, user.id, 'user.update', target.id, `${fresh.username}: ${role}, active=${active}`);
          return json(res, 200, { user: publicUser(db, db.prepare('SELECT * FROM users WHERE id=?').get(target.id)) });
        }
        if (!action && method === 'DELETE') {
          const rows = db.prepare('SELECT * FROM entries WHERE user_id=?').all(target.id);
          const blobs = entryBlobs(db,rows);
          await transfers.cancelUser(target.id,() => {
            manageable(db.prepare('SELECT * FROM users WHERE id=? AND active=1').get(user.id) || {},db.prepare('SELECT * FROM users WHERE id=?').get(target.id));
            db.prepare('DELETE FROM users WHERE id=?').run(target.id);
          });
          await deleteBlobs(dataDir,blobs);
          audit(db, user.id, 'user.delete', target.id, target.username); return json(res, 200, { ok: true });
        }
      }

      // ── ADMIN: Settings ───────────────────────────────────────────────────
      if (route === '/api/admin/settings' && method === 'PATCH') {
        owner(user); const input = await body(req, 2900000), update = {};
        owner(db.prepare('SELECT * FROM users WHERE id=? AND active=1').get(user.id) || {});
        if ('siteName' in input) { if (typeof input.siteName !== 'string' || !input.siteName.trim() || input.siteName.length > 40) fail(400, 'Site name must be 1–40 characters.'); update.siteName = input.siteName.trim(); }
        if ('tagline' in input) { if (typeof input.tagline !== 'string' || input.tagline.length > 100) fail(400, 'Tagline is too long.'); update.tagline = input.tagline.trim(); }
        if ('registrationEnabled' in input) { if (typeof input.registrationEnabled !== 'boolean') fail(400, 'Invalid registration setting.'); update.registrationEnabled = input.registrationEnabled; }
        if ('defaultQuota' in input) update.defaultQuota = integer(input.defaultQuota, 0, 100000 * GiB, 'Default quota');
        if ('maxUpload' in input) update.maxUpload = integer(input.maxUpload, 0, Number.MAX_SAFE_INTEGER, 'Upload limit');
        if ('uploadChunkSize' in input) update.uploadChunkSize = integer(input.uploadChunkSize, MiB, 80 * MiB, 'Upload chunk size');
        if ('accent' in input) { if (!/^#[0-9a-f]{6}$/i.test(input.accent)) fail(400, 'Invalid accent color.'); update.accent = input.accent; }
        if ('logo' in input) update.logo = brandingImage(input.logo);
        if ('favicon' in input) update.favicon = brandingImage(input.favicon);
        if ('maxMachinesPerUser' in input) update.maxMachinesPerUser = integer(input.maxMachinesPerUser, 0, 9999, 'Machine limit');
        if ('maxCpuPerInstance' in input) update.maxCpuPerInstance = integer(input.maxCpuPerInstance, 1, 512, 'Max CPU');
        if ('maxRamPerInstance' in input) update.maxRamPerInstance = integer(input.maxRamPerInstance, 128, 1048576, 'Max RAM');
        if ('maxDiskPerInstance' in input) update.maxDiskPerInstance = integer(input.maxDiskPerInstance, 1, 100000, 'Max disk');
        if ('requireProvisioningApproval' in input) { if (typeof input.requireProvisioningApproval !== 'boolean') fail(400,'Invalid.'); update.requireProvisioningApproval = input.requireProvisioningApproval; }
        transaction(db, () => { for (const [name,value] of Object.entries(update)) db.prepare('UPDATE settings SET value=? WHERE key=?').run(JSON.stringify(value), name); });
        audit(db, user.id, 'settings.update', 'site', Object.keys(update).join(', '));
        return json(res, 200, { settings: settings(db) });
      }

      // ── ADMIN: Audit Log ─────────────────────────────────────────────────
      if (route === '/api/admin/audit' && method === 'GET') {
        owner(user); return json(res, 200, { events: db.prepare('SELECT a.*,u.username FROM audit a LEFT JOIN users u ON a.actor=u.id ORDER BY a.id DESC LIMIT 200').all() });
      }

      // ── LOCAL NODE DETECTION ─────────────────────────────────────────────
      if (route === '/api/admin/detect-local' && method === 'POST') {
        staff(user);
        // Record pending detection run
        const runId = randomUUID();
        db.prepare('INSERT INTO detection_runs(node_id,triggered_by,result,created_at) VALUES (?,?,?,?)').run(null, user.id, 'pending', Date.now());
        // Run detection asynchronously so we can respond quickly
        (async () => {
          try {
            const detection = await detectLocalNode();
            const node = registerOrUpdateLocalNode(db, detection, user.id);
            db.prepare('UPDATE detection_runs SET result=?,detection_data=?,warnings=?,completed_at=?,node_id=? WHERE id=?').run(
              'success', JSON.stringify(detection), JSON.stringify(detection.warnings), Date.now(), node.id, runId
            );
          } catch (err) {
            db.prepare('UPDATE detection_runs SET result=?,warnings=?,completed_at=? WHERE id=?').run('failed', JSON.stringify([err.message]), Date.now(), runId);
          }
        })();
        return json(res, 202, { ok: true, runId, message: 'Detection started. Poll /api/admin/detect-local/status for results.' });
      }
      if (route === '/api/admin/detect-local/status' && method === 'GET') {
        staff(user);
        const run = db.prepare('SELECT * FROM detection_runs ORDER BY created_at DESC LIMIT 1').get();
        const localNode = db.prepare('SELECT * FROM nodes WHERE is_local=1').get();
        return json(res, 200, {
          run: run || null,
          localNode: localNode ? publicNode(localNode) : null,
          detectionData: run?.detection_data ? JSON.parse(run.detection_data) : null,
          warnings: run?.warnings ? JSON.parse(run.warnings) : [],
        });
      }
      if (route === '/api/admin/local-node' && method === 'GET') {
        staff(user);
        const localNode = db.prepare('SELECT * FROM nodes WHERE is_local=1').get();
        if (!localNode) return json(res, 200, { localNode: null });
        const workloads = db.prepare("SELECT COUNT(*) AS c FROM workloads WHERE node_id=? AND status NOT IN ('deleted')").get(localNode.id);
        return json(res, 200, {
          localNode: publicNode(localNode),
          detectionData: localNode.detection_data ? JSON.parse(localNode.detection_data) : null,
          providerStatuses: localNode.provider_statuses ? JSON.parse(localNode.provider_statuses) : {},
          activeWorkloads: workloads.c,
        });
      }

      // ── DOCKER CONTAINER LIVE OPS ─────────────────────────────────────────
      const dockerMatch = /^\/api\/workloads\/([a-f0-9-]{36})\/(logs|live-status)$/.exec(route);
      if (dockerMatch) {
        const [, wId, action] = dockerMatch;
        const w = db.prepare("SELECT w.*,n.api_endpoint,n.credentials_encrypted,n.status AS node_status FROM workloads w LEFT JOIN nodes n ON w.node_id=n.id WHERE w.id=?").get(wId);
        if (!w) fail(404, 'Workload not found.');
        if (w.owner_user_id !== user.id) staff(user);
        if (!w.api_endpoint) fail(503, 'Node endpoint not available.');
        if (action === 'logs' && method === 'GET') {
          const lines = parseInt(url.searchParams.get('lines') || '100');
          const logs = await getContainerLogs(w.api_endpoint, {}, w.provider_resource_id || w.name, Math.min(lines, 500));
          return json(res, 200, { logs });
        }
        if (action === 'live-status' && method === 'GET') {
          if (!w.provider_resource_id) return json(res, 200, { status: 'unknown', message: 'No provider resource ID assigned yet.' });
          try {
            const stats = await containerStats(w.api_endpoint, {}, w.provider_resource_id);
            return json(res, 200, { stats });
          } catch (err) { return json(res, 200, { stats: null, error: err.message }); }
        }
      }

      // ── NAS SERVERS ────────────────────────────────────────────────────────
      if (route === '/api/admin/nas' && method === 'GET') {
        staff(user);
        const servers = db.prepare('SELECT * FROM nas_servers ORDER BY created_at DESC').all().map(publicNAS);
        return json(res, 200, { servers });
      }
      if (route === '/api/admin/nas' && method === 'POST') {
        owner(user);
        const input = await body(req);
        const nas = createNASServer(db, user.id, input);
        return json(res, 201, { nas: publicNAS(nas) });
      }
      const nasMatch = /^\/api\/admin\/nas\/([a-f0-9-]{36})(?:\/(refresh|volumes|shares))?$/.exec(route);
      if (nasMatch) {
        const [, nasId, action] = nasMatch;
        staff(user);
        const nas = db.prepare('SELECT * FROM nas_servers WHERE id=?').get(nasId);
        if (!nas) fail(404, 'NAS server not found.');
        if (!action && method === 'GET') return json(res, 200, { nas: publicNAS(nas) });
        if (!action && method === 'DELETE') {
          owner(user);
          db.prepare('DELETE FROM nas_servers WHERE id=?').run(nasId);
          audit(db, user.id, 'nas.delete', nasId, nas.name);
          return json(res, 200, { ok: true });
        }
        if (action === 'refresh' && method === 'POST') {
          const updated = await refreshNASStatus(db, nas);
          return json(res, 200, { nas: publicNAS(updated) });
        }
        if (action === 'volumes' && method === 'GET') {
          const vols = db.prepare('SELECT * FROM nas_volumes WHERE nas_id=?').all(nasId);
          return json(res, 200, { volumes: vols });
        }
      }

      // ── ADMIN: Node workloads view ────────────────────────────────────────
      const nodeWorkloadMatch = /^\/api\/admin\/nodes\/([a-f0-9-]{36})\/workloads$/.exec(route);
      if (nodeWorkloadMatch && method === 'GET') {
        staff(user);
        const nId = nodeWorkloadMatch[1];
        const wloads = db.prepare("SELECT w.*,u.username FROM workloads w JOIN users u ON w.owner_user_id=u.id WHERE w.node_id=? AND w.status NOT IN ('deleted') ORDER BY w.created_at DESC").all(nId);
        return json(res, 200, { workloads: wloads.map(w => ({ ...publicWorkload(w), ownerUsername: w.username })) });
      }

      // ── NAS MACHINES (user + admin) ───────────────────────────────────────
      if (route === '/api/nas/machines' && method === 'GET') {
        const isAdmin = ['admin','owner'].includes(user.role);
        const machines = listNASMachines(db, user.id, isAdmin);
        return json(res, 200, { machines: machines.map(publicMachine) });
      }
      if (route === '/api/nas/machines' && method === 'POST') {
        const input = await body(req);
        const machine = createNASMachine(db, user.id, input);
        // Queue a Docker workload to back this machine if a node is available
        const info = NAS_IMAGES[machine.machine_type];
        if (info?.image) {
          try {
            const s = settings(db);
            const { schedulerFindNode, reserveResources } = await import('./scheduler.mjs');
            const nodeId = input.nodeId || null;
            const node = schedulerFindNode(db, 'docker', 1, 512, machine.quota_gb, nodeId);
            if (node) {
              reserveResources(db, node.id, 1, 512, machine.quota_gb);
              const wId = randomUUID(), now = Date.now();
              db.prepare(`INSERT INTO workloads (id,owner_user_id,workload_type,provider_type,node_id,name,image,os_template,cpu_allocated,ram_allocated,disk_allocated,network_config,env_vars,ports,restart_policy,status,created_at,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
                wId, user.id, 'container', 'docker', node.id,
                `nas-${machine.name}`, info.image, '',
                1, 512, machine.quota_gb, '{}', '{}',
                JSON.stringify([`${machine.access_port}:${machine.access_port}`]),
                'unless-stopped', 'pending', now, now
              );
              const jobId = randomUUID();
              db.prepare('INSERT INTO provisioning_jobs(id,workload_id,node_id,user_id,job_type,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)').run(
                jobId, wId, node.id, user.id, 'nas_machine.provision', 'queued', now, now
              );
              db.prepare('UPDATE nas_machines SET workload_id=?,node_id=?,status=?,updated_at=? WHERE id=?').run(wId, node.id, 'creating', now, machine.id);
              audit(db, user.id, 'nas_machine.provision_queued', machine.id, `${machine.name} → ${node.name}`);
            } else {
              // No Docker node available — machine created but not provisioned
              db.prepare("UPDATE nas_machines SET status='stopped',updated_at=? WHERE id=?").run(Date.now(), machine.id);
            }
          } catch (err) {
            db.prepare("UPDATE nas_machines SET status='error',updated_at=? WHERE id=?").run(Date.now(), machine.id);
          }
        } else {
          db.prepare("UPDATE nas_machines SET status='running',updated_at=? WHERE id=?").run(Date.now(), machine.id);
        }
        return json(res, 201, { machine: publicMachine(db.prepare('SELECT * FROM nas_machines WHERE id=?').get(machine.id)) });
      }

      const nasMachineMatch = /^\/api\/nas\/machines\/([a-f0-9-]{36})(?:\/(files|folders|upload))?$/.exec(route);
      if (nasMachineMatch) {
        const [, machId, action] = nasMachineMatch;
        const isAdmin = ['admin','owner'].includes(user.role);
        const machine = getNASMachine(db, machId, user.id, isAdmin);
        if (!machine) fail(404, 'NAS machine not found.');

        if (!action && method === 'GET') {
          const fileCount = db.prepare("SELECT COUNT(*) AS c FROM nas_files WHERE machine_id=? AND kind='file'").get(machId).c;
          return json(res, 200, { machine: publicMachine(machine), fileCount });
        }
        if (!action && method === 'DELETE') {
          if (machine.owner_user_id !== user.id) staff(user);
          const m = deleteNASMachine(db, user.id, machId);
          return json(res, 200, { ok: true });
        }

        // List files
        if (action === 'files' && method === 'GET') {
          const parentId = url.searchParams.get('parent') || null;
          const files = listNASFiles(db, machId, user.id, parentId);
          return json(res, 200, { files });
        }

        // Create folder
        if (action === 'folders' && method === 'POST') {
          const input = await body(req);
          const parentId = input.parentId || null;
          const folder = createNASFolder(db, machId, user.id, input.name, parentId);
          return json(res, 201, { file: folder });
        }

        // Upload file into NAS machine
        if (action === 'upload' && method === 'POST') {
          if (machine.status !== 'running' && machine.status !== 'creating' && machine.status !== 'stopped') {
            fail(409, `NAS machine is ${machine.status}. Cannot upload.`);
          }
          let name;
          try { name = decodeURIComponent(String(req.headers['x-file-name'] || '')).trim(); } catch { fail(400, 'Invalid filename.'); }
          if (!name) fail(400, 'X-File-Name header required.');
          const parentId = req.headers['x-parent-id'] ? String(req.headers['x-parent-id']) : null;
          const length = Number(req.headers['content-length']);
          if (!Number.isSafeInteger(length) || length < 0) fail(411, 'Content-Length required.');
          if (length > 10 * 1024 * 1024 * 1024) fail(413, 'Maximum single file size is 10 GB.');

          // Encrypt and store in blobs dir (same mechanism as regular files)
          const id = randomUUID();
          const { createWriteStream } = await import('node:fs');
          const { rename, unlink } = await import('node:fs/promises');
          const { pipeline } = await import('node:stream/promises');
          const { Transform } = await import('node:stream');
          const tempPath = path.join(dataDir, 'tmp', id);
          const blobPath = path.join(dataDir, 'blobs', id);
          const iv = randomBytes(12);
          const cipher = createCipheriv('aes-256-gcm', key, iv);
          let size = 0;
          let headerBuf = Buffer.alloc(0);
          const counter = new Transform({ transform(chunk, _enc, cb) {
            size += chunk.length;
            if (headerBuf.length < 16) headerBuf = Buffer.concat([headerBuf, chunk.subarray(0, 16 - headerBuf.length)]);
            cb(size > length + 1 ? new HttpError(413, 'Upload exceeded size.') : null, chunk);
          }});
          let committed = false;
          try {
            await pipeline(req, counter, cipher, createWriteStream(tempPath, { flags: 'wx', mode: 0o600 }));
            if (size !== length) fail(400, 'Upload was interrupted.');
            await rename(tempPath, blobPath);
            const imageType = b => {
              if (b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) return 'image/png';
              if (b[0]===255&&b[1]===216&&b[2]===255) return 'image/jpeg';
              return null;
            };
            const mime = imageType(headerBuf) || 'application/octet-stream';
            const file = recordNASUpload(db, machId, user.id, name, size, mime, parentId, id, iv.toString('hex'), cipher.getAuthTag().toString('hex'));
            committed = true;
            audit(db, user.id, 'nas_file.upload', file.id, `${name} → ${machine.name}`);
            return json(res, 201, { file });
          } finally {
            await unlink(tempPath).catch(() => {});
            if (!committed) await unlink(blobPath).catch(() => {});
          }
        }
      }

      // Download a NAS file
      const nasFileMatch = /^\/api\/nas\/files\/([a-f0-9-]{36})\/download$/.exec(route);
      if (nasFileMatch && ['GET','HEAD'].includes(method)) {
        const fileId = nasFileMatch[1];
        const isAdmin = ['admin','owner'].includes(user.role);
        const file = isAdmin
          ? db.prepare('SELECT * FROM nas_files WHERE id=?').get(fileId)
          : db.prepare('SELECT * FROM nas_files WHERE id=? AND owner_user_id=?').get(fileId, user.id);
        if (!file || file.kind !== 'file') fail(404, 'File not found.');
        const { downloadRange: dlRange, downloadBytes: dlBytes } = await import('./transfers.mjs');
        const etag = `"nas-${file.id}-${file.size}"`;
        let range;
        try { range = dlRange(req.headers['if-range'] && req.headers['if-range'] !== etag ? undefined : req.headers.range, file.size); }
        catch (err) { if (err.status === 416) res.setHeader('Content-Range', `bytes */${file.size}`); throw err; }
        res.setHeader('Content-Type', file.mime || 'application/octet-stream');
        res.setHeader('Content-Length', range.length);
        res.setHeader('Accept-Ranges', 'bytes');
        res.setHeader('ETag', etag);
        if (range.status === 206) res.setHeader('Content-Range', `bytes ${range.start}-${range.end}/${file.size}`);
        res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${encodeURIComponent(file.name).replace(/'/g,'%27')}`);
        res.statusCode = range.status;
        if (method === 'HEAD') { res.end(); return; }
        // Use same download infrastructure as regular files
        const fakeEntry = { id: file.blob, size: file.size, iv: file.iv, tag: file.tag, storage_format: 'legacy', blob: file.blob };
        const abort = new AbortController(), closed = () => abort.abort();
        res.once('close', closed);
        const { Readable } = await import('node:stream');
        const source = Readable.from(dlBytes(db, dataDir, key, fakeEntry, range, abort.signal));
        try {
          for await (const chunk of source) {
            if (res.destroyed) break;
            if (!res.write(chunk)) await new Promise((resolve, reject) => {
              const drain = () => { cleanup(); resolve(); }, disc = () => { cleanup(); reject(new Error('Closed')); };
              const cleanup = () => { res.off('drain', drain); res.off('close', disc); };
              res.once('drain', drain); res.once('close', disc);
            });
          }
          res.end();
        } finally { res.off('close', closed); abort.abort(); source.destroy(); }
        return;
      }

      // Delete a NAS file
      const nasFileDelMatch = /^\/api\/nas\/files\/([a-f0-9-]{36})$/.exec(route);
      if (nasFileDelMatch && method === 'DELETE') {
        const fileId = nasFileDelMatch[1];
        const isAdmin = ['admin','owner'].includes(user.role);
        const file = deleteNASFile(db, fileId, user.id, isAdmin);
        // Remove blob
        const { unlink } = await import('node:fs/promises');
        if (file.blob) await unlink(path.join(dataDir, 'blobs', file.blob)).catch(() => {});
        return json(res, 200, { ok: true });
      }

      fail(404, 'Endpoint not found.');
    }

    if (['GET','HEAD'].includes(method) && STATIC[route]) {
      const [filename,type] = STATIC[route]; res.setHeader('Content-Type', type);
      const bytes = await readFile(path.join(ROOT,'public',filename)); res.setHeader('Content-Length', bytes.length); res.end(method === 'HEAD' ? undefined : bytes); return;
    }
    fail(404, 'Not found.');
  }

  const server = http.createServer((req,res) => {
    handle(req,res).catch(original => {
      const error = sqlError(original);
      if (!res.headersSent && !res.destroyed) {
        res.removeHeader('Content-Length'); res.removeHeader('Content-Disposition');
        if (error.status !== 416) res.removeHeader('Content-Range');
        res.removeHeader('Accept-Ranges'); res.removeHeader('ETag');
        json(res, error.status || 500, { error: error.status ? error.message : 'An unexpected server error occurred.' });
      }
      else if (!res.destroyed) res.destroy();
      const disconnected = (req.aborted || res.destroyed) && ['ABORT_ERR','ECONNRESET','ERR_STREAM_PREMATURE_CLOSE'].includes(error.code);
      if (!error.status && !disconnected) console.error('Request failed:', error.message);
      if (!req.destroyed) req.resume();
    });
  });
  server.requestTimeout = 30 * 60000; server.headersTimeout = 30000; server.keepAliveTimeout = 5000;
  let cleaning;
  const cleanup = setInterval(() => {
    db.prepare('DELETE FROM sessions WHERE expires_at<?').run(Date.now());
    if (!cleaning) cleaning = transfers.cleanup().catch(error => console.error('Upload cleanup failed:',error.message)).finally(() => { cleaning = null; });
  },60000); cleanup.unref();
  return {
    server, db, cfg,
    async close() {
      clearInterval(cleanup); clearInterval(nodeHealthCheck);
      limiter.close();
      await new Promise(resolve => { server.close(resolve); server.closeIdleConnections(); });
      if (cleaning) await cleaning; db.close(); releaseLock();
    }
  };
}

const entryFile = fileURLToPath(import.meta.url);
if ([process.argv[1], process.env.pm_exec_path].filter(Boolean).some(filename => path.resolve(filename) === entryFile)) {
  const app = await createApp();
  app.server.listen(app.cfg.port, app.cfg.host, () => console.log(`${BRAND.name} v${BRAND.version} running on ${app.cfg.host}:${app.cfg.port}\n${serviceUrls(app.cfg.port,app.cfg.host).join('\n')}`));
  app.server.on('error', error => { console.error(error.message); process.exitCode = 1; });
  let stopping = false;
  for (const signal of ['SIGINT','SIGTERM']) process.on(signal, async () => {
    if (stopping) return; stopping = true;
    const forced = setTimeout(() => process.exit(1), 10000); forced.unref();
    await app.close(); process.exit(0);
  });
}

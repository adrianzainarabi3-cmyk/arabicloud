/**
 * ArabiCloud — PM2 Ecosystem Config
 * Created by Adrian Zain Arabi
 * Reads .env values and embeds them so PM2 uses the file's settings,
 * not stale environment values from a previous session.
 */
'use strict';
const fs = require('node:fs');
const path = require('node:path');

function loadDotEnv(dir) {
  const envPath = path.join(dir, '.env');
  const vars = {};
  let raw;
  try { raw = fs.readFileSync(envPath, 'utf8'); } catch { return vars; }
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq < 1) continue;
    const key = trimmed.slice(0, eq).trim();
    let val = trimmed.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    vars[key] = val;
  }
  return vars;
}

const ROOT = __dirname;
const dotenv = loadDotEnv(ROOT);
const KEYS = ['PORT', 'HOST', 'APP_URL', 'TRUST_PROXY', 'COOKIE_SECURE', 'DATA_DIR', 'BACKUP_DIR', 'REGISTRATION_DOMAIN'];
const env = { NODE_ENV: 'production' };
for (const key of KEYS) {
  if (Object.prototype.hasOwnProperty.call(dotenv, key)) env[key] = dotenv[key];
}

module.exports = {
  apps: [{
    name: 'arabicloud',
    script: 'src/server.mjs',
    interpreter: 'node',
    instances: 1,
    exec_mode: 'fork',
    watch: false,
    max_memory_restart: '512M',
    env,
    error_file: 'logs/error.log',
    out_file: 'logs/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss',
    restart_delay: 3000,
    max_restarts: 10,
  }],
};

/**
 * ArabiCloud — Local Node Detection Tests
 * Tests detection logic, duplicate prevention, schema migration safety.
 * Uses real system probes where available; stubs unavailable hardware.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { openStore } from '../src/database.mjs';
import { registerOrUpdateLocalNode } from '../src/detection.mjs';

// ── Minimal detection fixture (no real hardware required) ──────────────────
function mockDetection(overrides = {}) {
  return {
    hostname: 'test-host',
    os: 'linux 6.1.0',
    environment: { type: 'linux', inDocker: false, inVM: false, restricted: false },
    cpu: { model: 'Test CPU', cores: 2, utilization: 15 },
    ram: { totalBytes: 4 * 1024 ** 3, freeBytes: 2 * 1024 ** 3, usedBytes: 2 * 1024 ** 3, totalMB: 4096, freeMB: 2048 },
    disk: { primary: { device: '/dev/vda', mountpoint: '/', totalBytes: 50 * 1024 ** 3, freeBytes: 20 * 1024 ** 3, usedBytes: 30 * 1024 ** 3 }, all: [] },
    network: [{ name: 'eth0', address: '10.0.0.5', family: 'IPv4' }],
    docker: { installed: false, daemonRunning: false, socketAccessible: false, status: 'not_installed', error: 'Docker not installed' },
    kvm: { kvmDevicePresent: false, hwVirtEnabled: false, libvirtInstalled: false, libvirtRunning: false, status: 'not_available', error: '/dev/kvm not present' },
    proxmox: { installed: false, apiReachable: false, status: 'not_installed' },
    nas: { services: [], protocols: [] },
    providerStatuses: { docker: 'not_installed', kvm: 'not_available', proxmox: 'not_installed' },
    overallStatus: 'offline',
    warnings: ['Docker not installed', '/dev/kvm not present — hardware virtualization may be disabled'],
    detectedAt: Date.now(),
    ...overrides,
  };
}

async function withTempDB(fn) {
  const dir = await mkdtemp(join(tmpdir(), 'ac-detect-test-'));
  let store;
  try {
    store = openStore(dir);
    await fn(store.db, dir);
  } finally {
    store?.db.close();
    await rm(dir, { recursive: true, force: true });
  }
}

// ── Test 1: Detection with no providers creates a local node ──────────────
test('detection creates a local node record with is_local=1', async () => {
  await withTempDB(async (db) => {
    const detection = mockDetection();
    const node = registerOrUpdateLocalNode(db, detection, null, 'Local Node');
    assert.ok(node, 'Node should be created');
    assert.equal(node.is_local, 1, 'Node should be marked local');
    assert.equal(node.hostname, 'test-host');
    assert.equal(node.status, 'offline');
    assert.equal(node.name, 'Local Node');
  });
});

// ── Test 2: Reports missing capabilities accurately ────────────────────────
test('detection accurately reports missing Docker, KVM, and Proxmox', async () => {
  await withTempDB(async (db) => {
    const detection = mockDetection();
    const node = registerOrUpdateLocalNode(db, detection, null);
    const ps = JSON.parse(node.provider_statuses || '{}');
    assert.equal(ps.docker, 'not_installed', 'Docker status should be not_installed');
    assert.equal(ps.kvm, 'not_available', 'KVM status should be not_available');
    assert.equal(ps.proxmox, 'not_installed', 'Proxmox status should be not_installed');
    const dd = JSON.parse(node.detection_data || '{}');
    assert.ok(dd.docker?.error, 'Docker error message should be recorded');
    assert.ok(dd.kvm?.error, 'KVM error message should be recorded');
  });
});

// ── Test 3: Repeated detection does NOT create duplicate nodes ─────────────
test('repeated detection updates existing local node, does not create duplicates', async () => {
  await withTempDB(async (db) => {
    const d1 = mockDetection();
    const node1 = registerOrUpdateLocalNode(db, d1, null, 'Local Node');
    // Run detection again with updated data
    const d2 = mockDetection({ cpu: { model: 'Updated CPU', cores: 4, utilization: 30 } });
    const node2 = registerOrUpdateLocalNode(db, d2, null, 'Local Node');
    // Should be the SAME node, not a new one
    assert.equal(node1.id, node2.id, 'Node ID should be preserved across detections');
    const count = db.prepare('SELECT COUNT(*) AS c FROM nodes WHERE is_local=1').get().c;
    assert.equal(count, 1, 'Only one local node should exist');
    // Data should be updated
    const refreshed = db.prepare('SELECT * FROM nodes WHERE id=?').get(node1.id);
    assert.equal(refreshed.cpu_cores, 4, 'CPU cores should be updated');
  });
});

// ── Test 4: Node ID is preserved across application restarts ──────────────
test('node ID is stable across restarts (same DB, new detection run)', async () => {
  await withTempDB(async (db) => {
    const node1 = registerOrUpdateLocalNode(db, mockDetection(), null);
    const originalId = node1.id;
    // Simulate restart: run detection again on same DB
    registerOrUpdateLocalNode(db, mockDetection(), null);
    registerOrUpdateLocalNode(db, mockDetection(), null);
    const node = db.prepare("SELECT * FROM nodes WHERE is_local=1").get();
    assert.equal(node.id, originalId, 'Node ID must not change across restarts');
  });
});

// ── Test 5: Docker ready only after operational checks ─────────────────────
test('Docker is marked ready only when daemon responds, not just installed', async () => {
  const notReady = mockDetection({
    docker: { installed: true, daemonRunning: false, socketAccessible: false, status: 'detected', error: 'Socket not accessible' },
    providerStatuses: { docker: 'detected', kvm: 'not_available', proxmox: 'not_installed' },
  });
  await withTempDB(async (db) => {
    const node = registerOrUpdateLocalNode(db, notReady, null);
    const ps = JSON.parse(node.provider_statuses || '{}');
    assert.equal(ps.docker, 'detected', 'Docker should be detected, not ready');
    assert.notEqual(ps.docker, 'ready', 'Docker must not be marked ready without daemon');
  });
  // Simulate ready state
  const ready = mockDetection({
    docker: { installed: true, daemonRunning: true, socketAccessible: true, status: 'ready', version: '24.0.5' },
    providerStatuses: { docker: 'ready', kvm: 'not_available', proxmox: 'not_installed' },
    overallStatus: 'connected',
  });
  await withTempDB(async (db) => {
    const node = registerOrUpdateLocalNode(db, ready, null);
    const ps = JSON.parse(node.provider_statuses || '{}');
    assert.equal(ps.docker, 'ready', 'Docker should be ready when daemon responds');
    assert.equal(node.status, 'connected');
  });
});

// ── Test 6: KVM ready only after libvirt + /dev/kvm checks ────────────────
test('KVM is marked ready only after /dev/kvm present and libvirt responds', async () => {
  const kvmDetected = mockDetection({
    kvm: { kvmDevicePresent: true, hwVirtEnabled: true, libvirtInstalled: false, libvirtRunning: false, status: 'detected', error: 'libvirt not installed' },
    providerStatuses: { docker: 'not_installed', kvm: 'detected', proxmox: 'not_installed' },
  });
  await withTempDB(async (db) => {
    const node = registerOrUpdateLocalNode(db, kvmDetected, null);
    const ps = JSON.parse(node.provider_statuses || '{}');
    assert.equal(ps.kvm, 'detected', 'KVM detected but not ready without libvirt');
    assert.notEqual(ps.kvm, 'ready');
  });
  const kvmReady = mockDetection({
    kvm: { kvmDevicePresent: true, hwVirtEnabled: true, libvirtInstalled: true, libvirtRunning: true, status: 'ready' },
    providerStatuses: { docker: 'not_installed', kvm: 'ready', proxmox: 'not_installed' },
    overallStatus: 'connected',
  });
  await withTempDB(async (db) => {
    const node = registerOrUpdateLocalNode(db, kvmReady, null);
    const ps = JSON.parse(node.provider_statuses || '{}');
    assert.equal(ps.kvm, 'ready', 'KVM should be ready when /dev/kvm + libvirt OK');
  });
});

// ── Test 7: Docker container environment detected correctly ────────────────
test('Docker container environment is detected and flagged in warnings', async () => {
  const dockerEnv = mockDetection({
    environment: { type: 'docker-container', inDocker: true, inVM: false, restricted: false },
    warnings: ['ArabiCloud is running inside a Docker container. Host resource access may be limited.'],
  });
  await withTempDB(async (db) => {
    const node = registerOrUpdateLocalNode(db, dockerEnv, null);
    const dd = JSON.parse(node.detection_data || '{}');
    assert.equal(dd.environment?.inDocker, true, 'inDocker should be true');
    assert.equal(dd.environment?.type, 'docker-container');
  });
});

// ── Test 8: Remote nodes remain distinct from local nodes ─────────────────
test('remote nodes are never marked as local', async () => {
  await withTempDB(async (db) => {
    // Register a local node via detection
    registerOrUpdateLocalNode(db, mockDetection(), null);
    // Manually add a remote node (simulating /api/admin/nodes POST)
    const { randomUUID } = await import('node:crypto');
    const now = Date.now();
    db.prepare(`INSERT INTO nodes (id,name,hostname,ip_address,api_endpoint,provider_type,os_info,architecture,cpu_cores,ram_total,disk_total,status,scheduling_enabled,maintenance_mode,is_local,provider_statuses,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      randomUUID(), 'Remote Docker', 'remote.example.com', '10.0.0.50',
      'http://10.0.0.50:2375', 'docker', '', 'x86_64', 4, 8192, 100,
      'offline', 1, 0, 0, '{}', now, now
    );
    const localCount = db.prepare('SELECT COUNT(*) AS c FROM nodes WHERE is_local=1').get().c;
    const remoteCount = db.prepare('SELECT COUNT(*) AS c FROM nodes WHERE is_local=0').get().c;
    assert.equal(localCount, 1, 'Exactly one local node');
    assert.equal(remoteCount, 1, 'Exactly one remote node');
    // Running detection again must NOT affect the remote node
    registerOrUpdateLocalNode(db, mockDetection(), null);
    const remoteAfter = db.prepare('SELECT COUNT(*) AS c FROM nodes WHERE is_local=0').get().c;
    assert.equal(remoteAfter, 1, 'Remote node count must not change after re-detection');
  });
});

// ── Test 9: NAS detection never formats or erases storage ─────────────────
test('NAS detection data contains no destructive operations', async () => {
  await withTempDB(async (db) => {
    const detection = mockDetection({
      nas: { services: ['samba'], protocols: ['SMB'] },
    });
    const node = registerOrUpdateLocalNode(db, detection, null);
    const dd = JSON.parse(node.detection_data || '{}');
    // NAS detection only reports services/protocols, never formats/erases
    assert.ok(Array.isArray(dd.nas?.services), 'NAS services should be an array');
    assert.ok(Array.isArray(dd.nas?.protocols), 'NAS protocols should be an array');
    // Verify no destructive commands were run (detection data must not contain format/mkfs/dd)
    const raw = JSON.stringify(dd);
    assert.ok(!raw.includes('mkfs'), 'Detection must not run mkfs');
    assert.ok(!raw.includes('fdisk'), 'Detection must not run fdisk');
    assert.ok(!raw.includes('wipefs'), 'Detection must not run wipefs');
  });
});

// ── Test 10: Existing users, files, encryption keys survive schema migration ─
test('existing users and data are preserved after schema migration', async () => {
  await withTempDB(async (db, dir) => {
    // Pre-populate with a user (simulating upgrade from v2.0)
    const { randomUUID } = await import('node:crypto');
    const id = randomUUID();
    db.prepare('INSERT INTO users(id,username,email,display_name,password_hash,role,quota,active,created_at) VALUES (?,?,?,?,?,?,?,?,?)').run(
      id, 'existinguser', 'existing@test.com', 'Existing User', 'hash', 'member', 5*1024**3, 1, Date.now()
    );
    // Run detection (which touches nodes table but must not affect users)
    registerOrUpdateLocalNode(db, mockDetection(), null);
    // User must still exist and be intact
    const user = db.prepare('SELECT * FROM users WHERE id=?').get(id);
    assert.ok(user, 'Existing user must survive detection run');
    assert.equal(user.username, 'existinguser', 'Username must be preserved');
    assert.equal(user.email, 'existing@test.com', 'Email must be preserved');
    assert.equal(user.role, 'member', 'Role must be preserved');
  });
});

// ── Test 11: Proxmox enabled only after connectivity check ─────────────────
test('Proxmox is not marked ready without API connectivity', async () => {
  const proxDetected = mockDetection({
    proxmox: { installed: true, apiReachable: false, status: 'detected', error: 'Proxmox API not responding' },
    providerStatuses: { docker: 'not_installed', kvm: 'not_available', proxmox: 'detected' },
  });
  await withTempDB(async (db) => {
    const node = registerOrUpdateLocalNode(db, proxDetected, null);
    const ps = JSON.parse(node.provider_statuses || '{}');
    assert.equal(ps.proxmox, 'detected', 'Proxmox detected but not ready without API');
    assert.notEqual(ps.proxmox, 'ready');
  });
});

// ── Test 12: Resource quota enforced at DB level (concurrent safe) ─────────
test('resource reservations use transactions to prevent over-allocation', async () => {
  await withTempDB(async (db) => {
    const { randomUUID } = await import('node:crypto');
    const { reserveResources, releaseResources } = await import('../src/scheduler.mjs');
    const now = Date.now();
    const nodeId = randomUUID();
    db.prepare(`INSERT INTO nodes (id,name,hostname,ip_address,api_endpoint,provider_type,os_info,architecture,cpu_cores,cpu_allocated,ram_total,ram_allocated,disk_total,disk_allocated,status,scheduling_enabled,maintenance_mode,is_local,provider_statuses,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      nodeId,'TestNode','localhost','127.0.0.1','http://127.0.0.1:2375','docker','','x86_64',4,0,8192,0,100,0,'online',1,0,0,'{}',now,now
    );
    // Reserve some resources
    reserveResources(db, nodeId, 2, 2048, 20);
    const node = db.prepare('SELECT * FROM nodes WHERE id=?').get(nodeId);
    assert.equal(node.cpu_allocated, 2);
    assert.equal(node.ram_allocated, 2048);
    assert.equal(node.disk_allocated, 20);
    // Try to over-allocate — must throw
    assert.throws(
      () => reserveResources(db, nodeId, 3, 7000, 90),
      /Insufficient CPU|Insufficient RAM|Insufficient disk/,
      'Over-allocation must be rejected'
    );
    // Release and verify
    releaseResources(db, nodeId, 2, 2048, 20);
    const after = db.prepare('SELECT * FROM nodes WHERE id=?').get(nodeId);
    assert.equal(after.cpu_allocated, 0);
    assert.equal(after.ram_allocated, 0);
  });
});

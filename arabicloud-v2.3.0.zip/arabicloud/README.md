# ArabiCloud

**Multi-Node VPS and Container Management Panel**  
*Created by Adrian Zain Arabi*

---

## Overview

ArabiCloud is a self-hosted infrastructure management panel supporting:

- **Multi-Node Management** — Docker, KVM/libvirt, and Proxmox nodes
- **Docker Container Hosting** — Real container lifecycle management via the Docker API
- **KVM VPS Provisioning** — Virtual machine creation and management through a node agent or Proxmox
- **Encrypted File Storage** — AES-256-GCM encrypted personal file storage per user
- **User Management** — Full RBAC with owner, admin, and member roles
- **Scheduler** — Automatic best-fit placement across nodes
- **Audit Logging** — Full audit trail for all administrative actions
- **Professional UI** — Dark-first responsive design, no emojis, icon-based

---

## Requirements

- Node.js 24+
- Linux (recommended: Ubuntu 22.04+)
- For Docker nodes: Docker Engine with TCP API or TLS endpoint
- For KVM nodes: ArabiCloud node agent running on the target server
- For Proxmox nodes: Proxmox VE 7+ with API token

---

## Quick Start

```bash
# 1. Clone / extract the project
cd arabicloud

# 2. Run the installer
bash install.sh

# 3. Edit your environment
cp .env.example .env
nano .env

# 4. Create the owner account
npm run setup

# 5. Start the panel
npm start
# or with PM2:
pm2 start ecosystem.config.cjs
```

Open: `http://localhost:6969` (or your configured port/domain)

---

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `PORT` | `6969` | HTTP port |
| `HOST` | `0.0.0.0` | Bind address |
| `APP_URL` | auto | Public URL (required for HTTPS) |
| `DATA_DIR` | `./data` | Data storage directory |
| `BACKUP_DIR` | `./backups` | Backup directory |
| `TRUST_PROXY` | `false` | Enable when behind nginx/Caddy |
| `COOKIE_SECURE` | `false` | Set `true` for HTTPS |
| `REGISTRATION_DOMAIN` | — | Restrict registration to one email domain |
| `NODE_ENV` | — | Set to `production` for production |

---

## Connecting Nodes

### Docker Node

1. Expose the Docker API over TCP on the target server:
   ```bash
   # /etc/docker/daemon.json
   { "hosts": ["unix:///var/run/docker.sock", "tcp://0.0.0.0:2375"] }
   ```
   > **Security:** Always use TLS authentication in production. Never expose the raw Docker socket to the internet.

2. In ArabiCloud → Nodes → Add Node:
   - Provider Type: **Docker**
   - API Endpoint: `http://<node-ip>:2375`

### KVM Node

The KVM node requires the ArabiCloud node agent running on the target server. The agent exposes a minimal authenticated HTTP API for VM lifecycle operations.

1. Deploy the node agent (see `docs/node-agent.md`)
2. In ArabiCloud → Nodes → Add Node:
   - Provider Type: **KVM**
   - API Endpoint: `http://<node-ip>:<agent-port>`

### Proxmox Node

1. Create an API token in Proxmox: Datacenter → Permissions → API Tokens
2. In ArabiCloud → Nodes → Add Node:
   - Provider Type: **Proxmox**
   - API Endpoint: `https://<proxmox-ip>:8006`
   - Credentials: Token ID and secret

---

## Architecture

```
arabicloud/
├── src/
│   ├── server.mjs       # HTTP server, all API routes
│   ├── database.mjs     # SQLite schema, migrations, helpers
│   ├── nodes.mjs        # Node management, provider adapters, scheduler
│   ├── workloads.mjs    # Container and VPS lifecycle
│   ├── transfers.mjs    # Encrypted file upload/download
│   ├── security.mjs     # Auth, sessions, rate limiting, CSRF
│   ├── config.mjs       # Runtime configuration
│   ├── branding.mjs     # Centralized product identity
│   ├── lock.mjs         # Process lock
│   └── cli.mjs          # Setup CLI
├── public/
│   ├── index.html       # Single-page app shell
│   ├── app.js           # Full frontend (vanilla JS, no frameworks)
│   ├── styles.css       # Complete design system
│   ├── theme.js         # Theme persistence
│   ├── mark.svg         # ArabiCloud logo
│   └── fingerprint.js   # Browser fingerprint helper
├── tests/               # Test suite
├── scripts/             # Build scripts
├── .env.example         # Environment template
├── ecosystem.config.cjs # PM2 config
└── install.sh           # Installer script
```

---

## API Reference (summary)

### Public
- `GET /api/health` — Health check
- `GET /api/config` — Public branding config
- `POST /api/auth/login` — Sign in
- `POST /api/auth/register` — Register (if enabled)

### Authenticated (all require session cookie + CSRF token)
- `GET /api/me` — Current user + settings
- `POST /api/auth/logout`
- `PATCH /api/account` — Change password
- `GET/POST /api/workloads` — List/create workloads
- `GET/DELETE /api/workloads/:id` — Workload detail/delete
- `POST /api/workloads/:id/start|stop|restart` — Lifecycle
- `GET /api/jobs` — Provisioning jobs
- `GET/POST /api/entries` — File entries
- `GET/POST /api/uploads` — Chunked upload sessions
- `GET /api/sessions` — Active sessions
- `POST /api/sessions/revoke-all`

### Admin (owner + admin)
- `GET /api/admin/overview`
- `GET/POST /api/admin/nodes`
- `GET/PATCH/DELETE /api/admin/nodes/:id`
- `POST /api/admin/nodes/:id/test|heartbeat`
- `GET /api/admin/nodes/:id/pools`
- `GET/POST /api/admin/users`
- `GET/PATCH/DELETE /api/admin/users/:id`
- `POST /api/admin/users/:id/password|sessions`
- `GET /api/admin/workloads`
- `GET /api/admin/jobs`
- `PATCH /api/admin/settings` (owner only)
- `GET /api/admin/audit` (owner only)

---

## Security

- Sessions: HTTP-only cookies, CSRF token per session
- Passwords: bcrypt (via built-in Node.js `crypto.hash`)
- Files: AES-256-GCM encrypted blobs, keys stored server-side
- Node credentials: never exposed in API responses
- Rate limiting: per-IP on all API routes, stricter on auth
- RBAC: enforced server-side, never frontend-only
- Tenant isolation: users can only access their own workloads and files

---

## License

MIT — Created by Adrian Zain Arabi

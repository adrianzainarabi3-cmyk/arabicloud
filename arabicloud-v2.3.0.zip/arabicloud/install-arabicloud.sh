#!/usr/bin/env bash
# ArabiCloud Installation Script
# Created by Adrian Zain Arabi
set -euo pipefail

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; BOLD='\033[1m'; NC='\033[0m'
log()  { echo -e "${CYAN}[ArabiCloud]${NC} $*"; }
ok()   { echo -e "${GREEN}[  OK  ]${NC} $*"; }
warn() { echo -e "${YELLOW}[ WARN ]${NC} $*"; }
die()  { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }

echo -e "${BOLD}${CYAN}"
echo "  ╔════════════════════════════════════════╗"
echo "  ║          ArabiCloud v2.0.0             ║"
echo "  ║   Multi-Node VPS & Container Panel     ║"
echo "  ║   Created by Adrian Zain Arabi         ║"
echo "  ╚════════════════════════════════════════╝"
echo -e "${NC}"

# Node.js check
command -v node &>/dev/null || die "Node.js not found. Install Node.js 24+ from https://nodejs.org"
NODE_MAJ=$(node -e "console.log(parseInt(process.versions.node))")
[[ "$NODE_MAJ" -ge 24 ]] || die "Node.js 24+ required. Found: $(node -v). Upgrade at https://nodejs.org"
ok "Node.js $(node -v)"

# npm check
command -v npm &>/dev/null || die "npm not found."
ok "npm $(npm -v)"

# .env setup
if [[ ! -f .env ]]; then
  [[ -f .env.example ]] && cp .env.example .env && ok "Created .env from .env.example — edit before starting."
else
  ok ".env already exists."
fi

# Directories
mkdir -p data/blobs data/tmp backups logs
ok "Data directories ready."

# PM2
if command -v pm2 &>/dev/null; then
  ok "PM2 $(pm2 -v) detected."
else
  warn "PM2 not found. Install: npm install -g pm2"
fi

echo ""
log "Setup complete!"
echo -e "
${CYAN}Next steps:${NC}
  1. ${BOLD}Edit .env${NC} with your settings (PORT, APP_URL, etc.)
  2. ${BOLD}Create the owner account:${NC}
       npm run setup
  3. ${BOLD}Start the panel:${NC}
       npm start
       ${NC}or with PM2:
       pm2 start ecosystem.config.cjs

${CYAN}Add your first nodes:${NC}
  Docker:  Expose Docker TCP API on target server
  KVM:     Run ArabiCloud node agent on target server
  Proxmox: Provide API token in node configuration

Default port: ${BOLD}6969${NC}
"

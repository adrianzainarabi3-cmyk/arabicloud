/**
 * ArabiCloud — Node & Provider Management
 * Modular adapter architecture for Docker, KVM, Proxmox
 */
import { randomUUID } from 'node:crypto';
import { audit, transaction } from './database.mjs';

// ---- Provider Adapter: Docker ----
export async function testDockerConnection(endpoint, credentialsJson = '{}') {
  try {
    const url = `${endpoint.replace(/\/$/, '')}/version`;
    const creds = JSON.parse(credentialsJson || '{}');
    const headers = {};
    if (creds.token) headers['Authorization'] = `Bearer ${creds.token}`;
    const ctrl = new AbortController();
    const timeout = setTimeout(() => ctrl.abort(), 8000);
    const res = await fetch(url, { headers, signal: ctrl.signal });
    clearTimeout(timeout);
    if (!res.ok) return { ok: false, error: `HTTP ${res.status}` };
    const data = await res.json();
    return { ok: true, version: data.Version, os: data.Os, arch: data.Arch };
  } catch (err) {
    return { ok: false, error: err.name === 'AbortError' ? 'Connection timed out' : err.message };
  }
}

// ---- Provider Adapter: KVM/libvirt ----
export async function testKvmConnection(endpoint, credentialsJson = '{}') {
  try {
    const url = `${endpoint.replace(/\/$/, '')}/api/health`;
    const creds = JSON.parse(credentialsJson || '{}');
    const headers = {};
    if (creds.token) headers['Authorization'] = `Bearer ${creds.token}`;
    const ctrl = new AbortController();
    const timeout = setTimeout(() => ctrl.abort(), 8000);
    const res = await fetch(url, { headers, signal: ctrl.signal });
    clearTimeout(timeout);
    if (!res.ok) return { ok: false, error: `HTTP ${res.status} — Is the ArabiCloud node agent running?` };
    const data = await res.json();
    return { ok: true, ...data };
  } catch (err) {
    return { ok: false, error: err.name === 'AbortError' ? 'Connection timed out' : err.message };
  }
}

// ---- Provider Adapter: Proxmox ----
export async function testProxmoxConnection(endpoint, credentialsJson = '{}') {
  try {
    const url = `${endpoint.replace(/\/$/, '')}/api2/json/version`;
    const creds = JSON.parse(credentialsJson || '{}');
    const headers = {};
    if (creds.token) headers['Authorization'] = `PVEAPIToken=${creds.tokenId}=${creds.secret}`;
    const ctrl = new AbortController();
    const timeout = setTimeout(() => ctrl.abort(), 8000);
    const res = await fetch(url, { headers, signal: ctrl.signal });
    clearTimeout(timeout);
    if (!res.ok) return { ok: false, error: `HTTP ${res.status}` };
    const data = await res.json();
    return { ok: true, version: data.data?.version, release: data.data?.release };
  } catch (err) {
    return { ok: false, error: err.name === 'AbortError' ? 'Connection timed out' : err.message };
  }
}

export async function testNodeConnection(providerType, endpoint, credentialsJson) {
  switch (providerType) {
    case 'docker': return testDockerConnection(endpoint, credentialsJson);
    case 'kvm': return testKvmConnection(endpoint, credentialsJson);
    case 'proxmox': return testProxmoxConnection(endpoint, credentialsJson);
    default: return { ok: false, error: `Unknown provider type: ${providerType}` };
  }
}

// ---- Node CRUD helpers ----
export function publicNode(node) {
  const n = { ...node };
  delete n.credentials_encrypted; // NEVER expose credentials to frontend
  return n;
}

export function createNode(db, actorId, input) {
  const {
    name, hostname, ipAddress, apiEndpoint, providerType,
    location = '', description = '', osInfo = '', architecture = 'x86_64',
    cpuCores = 0, ramTotal = 0, diskTotal = 0,
  } = input;
  if (!name?.trim()) throw Object.assign(new Error('Node name is required.'), { status: 400 });
  if (!hostname?.trim()) throw Object.assign(new Error('Hostname is required.'), { status: 400 });
  if (!ipAddress?.trim()) throw Object.assign(new Error('IP address is required.'), { status: 400 });
  if (!apiEndpoint?.trim()) throw Object.assign(new Error('API endpoint is required.'), { status: 400 });
  if (!['docker','kvm','proxmox'].includes(providerType)) throw Object.assign(new Error('Invalid provider type.'), { status: 400 });
  const id = randomUUID(), now = Date.now();
  db.prepare(`INSERT INTO nodes (id,name,hostname,ip_address,api_endpoint,provider_type,location,description,os_info,architecture,cpu_cores,ram_total,disk_total,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(id, name.trim(), hostname.trim(), ipAddress.trim(), apiEndpoint.trim(), providerType, location, description, osInfo, architecture, cpuCores, ramTotal, diskTotal, now, now);
  audit(db, actorId, 'node.create', id, `${name} (${providerType})`);
  return db.prepare('SELECT * FROM nodes WHERE id=?').get(id);
}

export function updateNode(db, actorId, nodeId, input) {
  const node = db.prepare('SELECT * FROM nodes WHERE id=?').get(nodeId);
  if (!node) throw Object.assign(new Error('Node not found.'), { status: 404 });
  const fields = ['name','hostname','ip_address','api_endpoint','location','description','os_info','architecture','cpu_cores','ram_total','disk_total','scheduling_enabled','maintenance_mode'];
  const map = { name:'name', hostname:'hostname', ipAddress:'ip_address', apiEndpoint:'api_endpoint', location:'location', description:'description', osInfo:'os_info', architecture:'architecture', cpuCores:'cpu_cores', ramTotal:'ram_total', diskTotal:'disk_total', schedulingEnabled:'scheduling_enabled', maintenanceMode:'maintenance_mode' };
  const updates = [];
  const params = [];
  for (const [jsKey, dbCol] of Object.entries(map)) {
    if (jsKey in input) { updates.push(`${dbCol}=?`); params.push(input[jsKey]); }
  }
  if (updates.length === 0) return publicNode(node);
  updates.push('updated_at=?'); params.push(Date.now()); params.push(nodeId);
  db.prepare(`UPDATE nodes SET ${updates.join(',')} WHERE id=?`).run(...params);
  audit(db, actorId, 'node.update', nodeId, node.name);
  return publicNode(db.prepare('SELECT * FROM nodes WHERE id=?').get(nodeId));
}

export async function heartbeatNode(db, node) {
  const result = await testNodeConnection(node.provider_type, node.api_endpoint, node.credentials_encrypted);
  const now = Date.now();
  const status = result.ok ? 'online' : 'error';
  db.prepare('UPDATE nodes SET status=?,last_heartbeat=?,last_error=?,updated_at=? WHERE id=?').run(
    node.maintenance_mode ? 'maintenance' : status, now, result.error || null, now, node.id
  );
  db.prepare('INSERT INTO node_health_history(node_id,status,error,checked_at) VALUES (?,?,?,?)').run(
    node.id, status, result.error || null, now
  );
  // Keep last 100 health history entries per node
  db.prepare('DELETE FROM node_health_history WHERE node_id=? AND id NOT IN (SELECT id FROM node_health_history WHERE node_id=? ORDER BY checked_at DESC LIMIT 100)').run(node.id, node.id);
  return result;
}

// ---- Scheduler ----
export function schedulerFindNode(db, providerType, cpuNeeded, ramNeeded, diskNeeded, preferredNodeId = null) {
  let nodes;
  if (preferredNodeId) {
    nodes = db.prepare('SELECT * FROM nodes WHERE id=? AND status=? AND provider_type=? AND scheduling_enabled=1 AND maintenance_mode=0').all(preferredNodeId, 'online', providerType);
  } else {
    nodes = db.prepare('SELECT * FROM nodes WHERE status=? AND provider_type=? AND scheduling_enabled=1 AND maintenance_mode=0').all('online', providerType);
  }
  // Best-fit: most loaded node that still has capacity (minimize fragmentation)
  const eligible = nodes.filter(n =>
    (n.cpu_cores - n.cpu_allocated) >= cpuNeeded &&
    (n.ram_total - n.ram_allocated) >= ramNeeded &&
    (n.disk_total - n.disk_allocated) >= diskNeeded
  );
  if (eligible.length === 0) return null;
  eligible.sort((a, b) => {
    const aFree = (a.ram_total - a.ram_allocated) / Math.max(a.ram_total, 1);
    const bFree = (b.ram_total - b.ram_allocated) / Math.max(b.ram_total, 1);
    return aFree - bFree; // less free = more loaded = best-fit first
  });
  return eligible[0];
}

export function reserveNodeResources(db, nodeId, cpu, ram, disk) {
  const node = db.prepare('SELECT * FROM nodes WHERE id=?').get(nodeId);
  if (!node) throw Object.assign(new Error('Node not found.'), { status: 404 });
  if ((node.cpu_cores - node.cpu_allocated) < cpu) throw Object.assign(new Error('Insufficient CPU on target node.'), { status: 409 });
  if ((node.ram_total - node.ram_allocated) < ram) throw Object.assign(new Error('Insufficient RAM on target node.'), { status: 409 });
  if ((node.disk_total - node.disk_allocated) < disk) throw Object.assign(new Error('Insufficient disk on target node.'), { status: 409 });
  db.prepare('UPDATE nodes SET cpu_allocated=cpu_allocated+?,ram_allocated=ram_allocated+?,disk_allocated=disk_allocated+?,updated_at=? WHERE id=?').run(cpu, ram, disk, Date.now(), nodeId);
}

export function releaseNodeResources(db, nodeId, cpu, ram, disk) {
  db.prepare('UPDATE nodes SET cpu_allocated=MAX(0,cpu_allocated-?),ram_allocated=MAX(0,ram_allocated-?),disk_allocated=MAX(0,disk_allocated-?),updated_at=? WHERE id=?').run(cpu, ram, disk, Date.now(), nodeId);
}

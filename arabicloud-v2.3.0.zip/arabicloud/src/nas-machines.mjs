/**
 * ArabiCloud — NAS Machine Management
 * Creates Docker containers running NAS services (Samba, MinIO, SFTP, etc.)
 * Files uploaded through ArabiCloud are tracked in nas_files table.
 * Never formats disks. Never runs arbitrary user commands.
 */
import { randomUUID, createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';
import { audit, transaction } from './database.mjs';

// Docker images for each NAS type
export const NAS_IMAGES = {
  samba:       { image: 'dperson/samba:latest',      protocol: 'smb',   defaultPort: 445,  label: 'Samba (SMB/CIFS)' },
  minio:       { image: 'minio/minio:latest',        protocol: 'http',  defaultPort: 9000, label: 'MinIO Object Storage' },
  sftp:        { image: 'atmoz/sftp:latest',          protocol: 'sftp',  defaultPort: 22,   label: 'SFTP Server' },
  webdav:      { image: 'ugeek/webdav:amd64',        protocol: 'http',  defaultPort: 80,   label: 'WebDAV Server' },
  nextcloud:   { image: 'nextcloud:latest',           protocol: 'http',  defaultPort: 80,   label: 'Nextcloud' },
  filebrowser: { image: 'filebrowser/filebrowser:latest', protocol: 'http', defaultPort: 80, label: 'File Browser' },
  generic:     { image: null,                         protocol: 'http',  defaultPort: 80,   label: 'Custom / Generic' },
};

export function publicMachine(m) {
  const out = { ...m };
  delete out.password_hash; // never expose stored password
  return out;
}

export function listNASMachines(db, userId, isAdmin = false) {
  if (isAdmin) {
    return db.prepare(`
      SELECT m.*, u.username AS owner_username
      FROM nas_machines m
      JOIN users u ON m.owner_user_id = u.id
      WHERE m.status != 'deleted'
      ORDER BY m.created_at DESC LIMIT 200
    `).all();
  }
  return db.prepare(`
    SELECT * FROM nas_machines
    WHERE owner_user_id = ? AND status != 'deleted'
    ORDER BY created_at DESC LIMIT 100
  `).all(userId);
}

export function createNASMachine(db, actorId, input) {
  const {
    name, machineType = 'filebrowser', nodeId,
    quotaGb = 50, description = '', accessPort,
    username = 'admin',
  } = input;

  if (!name?.trim()) throw Object.assign(new Error('Machine name is required.'), { status: 400 });
  if (!NAS_IMAGES[machineType]) throw Object.assign(new Error('Invalid machine type.'), { status: 400 });
  if (quotaGb < 1 || quotaGb > 10000) throw Object.assign(new Error('Quota must be between 1 and 10000 GB.'), { status: 400 });

  const info = NAS_IMAGES[machineType];
  const id = randomUUID();
  const now = Date.now();
  const port = accessPort || info.defaultPort;

  db.prepare(`INSERT INTO nas_machines
    (id,owner_user_id,name,machine_type,node_id,status,access_port,access_protocol,
     username,quota_gb,description,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
    id, actorId, name.trim(), machineType, nodeId || null, 'creating',
    port, info.protocol, username, quotaGb, description, now, now
  );
  audit(db, actorId, 'nas_machine.create', id, `${name} (${machineType})`);
  return db.prepare('SELECT * FROM nas_machines WHERE id=?').get(id);
}

export function updateMachineStatus(db, machineId, status, ipAddress = null, providerResourceId = null) {
  const now = Date.now();
  db.prepare(`UPDATE nas_machines SET status=?,ip_address=COALESCE(?,ip_address),
    provider_resource_id=COALESCE(?,provider_resource_id),updated_at=? WHERE id=?`)
    .run(status, ipAddress, providerResourceId, now, machineId);
}

// ── File Management within a NAS Machine ──────────────────────────────────

export function listNASFiles(db, machineId, userId, parentId = null) {
  return db.prepare(`
    SELECT * FROM nas_files
    WHERE machine_id=? AND owner_user_id=? AND parent_id IS ?
    ORDER BY kind DESC, name ASC
  `).all(machineId, userId, parentId);
}

export function getNASMachine(db, machineId, userId, isAdmin = false) {
  if (isAdmin) return db.prepare('SELECT * FROM nas_machines WHERE id=? AND status!=?').get(machineId, 'deleted');
  return db.prepare('SELECT * FROM nas_machines WHERE id=? AND owner_user_id=? AND status!=?').get(machineId, userId, 'deleted');
}

export function createNASFolder(db, machineId, userId, name, parentId = null) {
  if (!name?.trim()) throw Object.assign(new Error('Folder name required.'), { status: 400 });
  const id = randomUUID(), now = Date.now();
  db.prepare(`INSERT INTO nas_files (id,machine_id,owner_user_id,parent_id,name,kind,created_at,updated_at)
    VALUES (?,?,?,?,?,'folder',?,?)`).run(id, machineId, userId, parentId, name.trim(), now, now);
  return db.prepare('SELECT * FROM nas_files WHERE id=?').get(id);
}

export function recordNASUpload(db, machineId, userId, fileName, size, mime, parentId, blob, iv, tag) {
  const id = randomUUID(), now = Date.now();
  // Check quota
  const machine = db.prepare('SELECT * FROM nas_machines WHERE id=?').get(machineId);
  if (!machine) throw Object.assign(new Error('NAS machine not found.'), { status: 404 });
  const used = db.prepare('SELECT COALESCE(SUM(size),0) AS b FROM nas_files WHERE machine_id=? AND kind=?').get(machineId, 'file').b;
  const quotaBytes = (machine.quota_gb || 50) * 1024 * 1024 * 1024;
  if (used + size > quotaBytes) throw Object.assign(new Error(`NAS machine quota exceeded (${machine.quota_gb}GB limit).`), { status: 413 });

  transaction(db, () => {
    db.prepare(`INSERT INTO nas_files (id,machine_id,owner_user_id,parent_id,name,kind,size,mime,blob,iv,tag,created_at,updated_at)
      VALUES (?,?,?,?,?,'file',?,?,?,?,?,?,?)`).run(id, machineId, userId, parentId, fileName, size, mime, blob, iv, tag, now, now);
    db.prepare('UPDATE nas_machines SET used_bytes=used_bytes+?,updated_at=? WHERE id=?').run(size, now, machineId);
  });
  return db.prepare('SELECT * FROM nas_files WHERE id=?').get(id);
}

export function deleteNASFile(db, fileId, userId, isAdmin = false) {
  const file = isAdmin
    ? db.prepare('SELECT * FROM nas_files WHERE id=?').get(fileId)
    : db.prepare('SELECT * FROM nas_files WHERE id=? AND owner_user_id=?').get(fileId, userId);
  if (!file) throw Object.assign(new Error('File not found.'), { status: 404 });
  transaction(db, () => {
    db.prepare('DELETE FROM nas_files WHERE id=?').run(fileId);
    if (file.kind === 'file') {
      db.prepare('UPDATE nas_machines SET used_bytes=MAX(0,used_bytes-?),updated_at=? WHERE id=?').run(file.size, Date.now(), file.machine_id);
    }
  });
  return file;
}

export function deleteNASMachine(db, actorId, machineId) {
  const machine = db.prepare('SELECT * FROM nas_machines WHERE id=?').get(machineId);
  if (!machine) throw Object.assign(new Error('NAS machine not found.'), { status: 404 });
  transaction(db, () => {
    db.prepare("UPDATE nas_machines SET status='deleted',updated_at=? WHERE id=?").run(Date.now(), machineId);
    // Files are cascade-deleted by FK
  });
  audit(db, actorId, 'nas_machine.delete', machineId, machine.name);
  return machine;
}

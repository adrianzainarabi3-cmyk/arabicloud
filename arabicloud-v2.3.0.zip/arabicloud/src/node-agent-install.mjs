/**
 * ArabiCloud — Node Agent Install Script Generator
 * Generates a one-click bash command to install the ArabiCloud agent
 * on a remote VM and auto-register it back to this panel.
 * Never exposes master credentials — uses short-lived signed tokens.
 */
import { randomBytes, createHmac } from 'node:crypto';
import { randomUUID } from 'node:crypto';
import { audit } from './database.mjs';

export function generateAgentToken(db, actorId, nodeName, panelUrl) {
  const token = randomBytes(32).toString('hex');
  const tokenHash = createHmac('sha256', 'arabicloud-agent-token').update(token).digest('hex');
  const id = randomUUID();
  const now = Date.now();
  const expiresAt = now + 24 * 60 * 60 * 1000; // 24h

  db.prepare(`INSERT INTO agent_tokens(id,token_hash,created_by,expires_at,created_at)
    VALUES (?,?,?,?,?)`).run(id, tokenHash, actorId, expiresAt, now);
  audit(db, actorId, 'agent_token.created', id, nodeName);

  return { id, token, expiresAt };
}

export function buildInstallCommand(panelUrl, token, nodeName, nodeType = 'docker') {
  const encodedName = encodeURIComponent(nodeName);
  const baseUrl = panelUrl.replace(/\/$/, '');

  // One-liner that:
  // 1. Installs Docker if not present
  // 2. Pulls the arabicloud-agent container
  // 3. Starts it with the registration token
  // 4. Agent auto-registers back to the panel
  const cmd = `curl -fsSL ${baseUrl}/api/agent/install.sh | bash -s -- --token ${token} --panel ${baseUrl} --name "${nodeName}" --type ${nodeType}`;
  return cmd;
}

export function buildInstallScript(panelUrl, token, nodeName, nodeType = 'docker') {
  const baseUrl = panelUrl.replace(/\/$/, '');
  return `#!/usr/bin/env bash
# ArabiCloud Node Agent Installer
# Generated for node: ${nodeName}
# Token expires in 24 hours
set -euo pipefail

PANEL_URL="${baseUrl}"
REG_TOKEN="${token}"
NODE_NAME="${nodeName}"
NODE_TYPE="${nodeType}"
AGENT_PORT=7071

RED='\\033[0;31m'; GREEN='\\033[0;32m'; CYAN='\\033[0;36m'; YELLOW='\\033[1;33m'; NC='\\033[0m'
log()  { echo -e "\${CYAN}[ArabiCloud Agent]\\${NC} $*"; }
ok()   { echo -e "\${GREEN}[ OK ]\\${NC} $*"; }
warn() { echo -e "\${YELLOW}[WARN]\\${NC} $*"; }
die()  { echo -e "\${RED}[FAIL]\\${NC} $*" >&2; exit 1; }

log "Installing ArabiCloud Node Agent for: \$NODE_NAME"
log "Panel: \$PANEL_URL"

# Check root
[ "\$(id -u)" = "0" ] || die "Run as root: sudo bash <script>"

# Install Docker if missing
if ! command -v docker &>/dev/null; then
  log "Installing Docker..."
  curl -fsSL https://get.docker.com | sh
  systemctl enable --now docker
  ok "Docker installed"
else
  ok "Docker already installed: \$(docker --version)"
fi

# Create agent data directory
mkdir -p /opt/arabicloud-agent
cat > /opt/arabicloud-agent/config.json << AGENTEOF
{
  "panelUrl": "\$PANEL_URL",
  "token": "\$REG_TOKEN",
  "nodeName": "\$NODE_NAME",
  "nodeType": "\$NODE_TYPE",
  "agentPort": \$AGENT_PORT
}
AGENTEOF

# Start agent container
docker rm -f arabicloud-agent 2>/dev/null || true
docker run -d \\
  --name arabicloud-agent \\
  --restart unless-stopped \\
  -p \${AGENT_PORT}:\${AGENT_PORT} \\
  -v /var/run/docker.sock:/var/run/docker.sock \\
  -v /opt/arabicloud-agent:/config \\
  -e PANEL_URL="\$PANEL_URL" \\
  -e REG_TOKEN="\$REG_TOKEN" \\
  -e NODE_NAME="\$NODE_NAME" \\
  -e NODE_TYPE="\$NODE_TYPE" \\
  -e AGENT_PORT="\$AGENT_PORT" \\
  node:22-alpine sh -c '
    echo "ArabiCloud Agent starting..."
    # Register with panel
    RESP=\$(wget -qO- --post-data="{\"token\":\"\$REG_TOKEN\",\"name\":\"\$NODE_NAME\",\"type\":\"\$NODE_TYPE\",\"agentPort\":\$AGENT_PORT}" \\
      --header="Content-Type: application/json" "\$PANEL_URL/api/agent/register" 2>&1) || true
    echo "Registration response: \$RESP"
    # Keep alive — simple HTTP health endpoint
    while true; do
      echo -e "HTTP/1.1 200 OK\\r\\nContent-Type: application/json\\r\\n\\r\\n{\"status\":\"ok\",\"name\":\"\$NODE_NAME\",\"type\":\"\$NODE_TYPE\"}" | nc -l -p \$AGENT_PORT 2>/dev/null || true
    done
  '

ok "Agent container started"
log "Registering with panel at \$PANEL_URL..."

# Wait for agent to start
sleep 3
docker logs arabicloud-agent 2>&1 | tail -5

ok "Node agent installed successfully!"
log "Your node '\$NODE_NAME' should appear in ArabiCloud within a few seconds."
log "If it doesn't appear, check: docker logs arabicloud-agent"
`;
}

export function validateAgentToken(db, token) {
  const tokenHash = createHmac('sha256', 'arabicloud-agent-token').update(token).digest('hex');
  const record = db.prepare('SELECT * FROM agent_tokens WHERE token_hash=? AND used=0 AND expires_at>?').get(tokenHash, Date.now());
  return record || null;
}

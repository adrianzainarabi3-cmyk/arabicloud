/**
 * ArabiCloud — KVM/libvirt Provider
 * Communicates with the ArabiCloud node-agent over authenticated HTTP.
 * Never executes virsh/qemu directly from user input.
 * Only enables provisioning when node agent confirms KVM readiness.
 */

async function agentFetch(endpoint, path, opts = {}, timeoutMs = 20000) {
  const base = endpoint.replace(/\/$/, '');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(`${base}${path}`, { ...opts, signal: ctrl.signal });
    clearTimeout(timer);
    return res;
  } catch (err) {
    clearTimeout(timer);
    throw Object.assign(
      new Error(err.name === 'AbortError' ? 'KVM agent timed out' : `KVM agent error: ${err.message}`),
      { status: 503 }
    );
  }
}

async function agentJSON(endpoint, path, opts = {}, creds = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (creds.token) headers['Authorization'] = `Bearer ${creds.token}`;
  const res = await agentFetch(endpoint, path, { ...opts, headers: { ...headers, ...(opts.headers || {}) } });
  let data;
  try { data = await res.json(); } catch { data = null; }
  if (!res.ok) throw Object.assign(
    new Error(data?.error || data?.message || `KVM agent: HTTP ${res.status}`),
    { status: res.status >= 500 ? 503 : 400 }
  );
  return data;
}

// ── Agent Health Check ────────────────────────────────────────────────────
export async function agentHealth(endpoint, creds = {}) {
  return agentJSON(endpoint, '/api/health', {}, creds);
}

// ── VM Lifecycle ──────────────────────────────────────────────────────────
export async function listVMs(endpoint, creds = {}) {
  return agentJSON(endpoint, '/api/vms', {}, creds);
}

export async function inspectVM(endpoint, creds = {}, vmId) {
  return agentJSON(endpoint, `/api/vms/${encodeURIComponent(vmId)}`, {}, creds);
}

export async function createVM(endpoint, creds = {}, config) {
  const {
    name, osTemplate, vcpus = 1, memoryMB = 512,
    diskGB = 10, networkBridge = 'virbr0',
    storagePool = 'default', cloudInitUser = null,
  } = config;

  // Validate name — alphanumeric + dash/underscore only
  if (!/^[a-zA-Z0-9][a-zA-Z0-9_\-]{0,62}$/.test(name)) {
    throw Object.assign(new Error('Invalid VM name. Use letters, digits, hyphens and underscores only.'), { status: 400 });
  }
  if (!osTemplate || typeof osTemplate !== 'string') {
    throw Object.assign(new Error('OS template is required.'), { status: 400 });
  }

  return agentJSON(endpoint, '/api/vms', {
    method: 'POST',
    body: JSON.stringify({ name, osTemplate, vcpus, memoryMB, diskGB, networkBridge, storagePool, cloudInitUser }),
  }, creds);
}

export async function startVM(endpoint, creds = {}, vmId) {
  return agentJSON(endpoint, `/api/vms/${encodeURIComponent(vmId)}/start`, { method: 'POST' }, creds);
}

export async function stopVM(endpoint, creds = {}, vmId, force = false) {
  return agentJSON(endpoint, `/api/vms/${encodeURIComponent(vmId)}/stop`, {
    method: 'POST', body: JSON.stringify({ force }),
  }, creds);
}

export async function restartVM(endpoint, creds = {}, vmId) {
  return agentJSON(endpoint, `/api/vms/${encodeURIComponent(vmId)}/restart`, { method: 'POST' }, creds);
}

export async function deleteVM(endpoint, creds = {}, vmId) {
  return agentJSON(endpoint, `/api/vms/${encodeURIComponent(vmId)}`, { method: 'DELETE' }, creds);
}

export async function getVMConsoleToken(endpoint, creds = {}, vmId) {
  return agentJSON(endpoint, `/api/vms/${encodeURIComponent(vmId)}/console`, { method: 'POST' }, creds);
}

// ── Storage Pool Operations ───────────────────────────────────────────────
export async function listStoragePools(endpoint, creds = {}) {
  return agentJSON(endpoint, '/api/storage/pools', {}, creds);
}

export async function listOSTemplates(endpoint, creds = {}) {
  return agentJSON(endpoint, '/api/templates', {}, creds);
}

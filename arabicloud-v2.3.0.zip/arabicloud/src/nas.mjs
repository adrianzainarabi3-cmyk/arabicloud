/**
 * ArabiCloud — NAS & Storage Server Management
 * Registers and monitors NAS servers.
 * NEVER formats, repartitions, or mounts disks with destructive options.
 * All write operations require explicit admin approval.
 */
import { randomUUID } from 'node:crypto';
import { audit, transaction } from './database.mjs';

async function nasFetch(endpoint, path, opts = {}, timeoutMs = 10000) {
  const base = endpoint.replace(/\/$/, '');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(`${base}${path}`, { ...opts, signal: ctrl.signal });
    clearTimeout(timer);
    return res;
  } catch (err) {
    clearTimeout(timer);
    throw Object.assign(
      new Error(err.name === 'AbortError' ? 'NAS connection timed out' : `NAS connection error: ${err.message}`),
      { status: 503 }
    );
  }
}

async function nasJSON(endpoint, path, opts = {}, creds = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (creds.token) headers['Authorization'] = `Bearer ${creds.token}`;
  const res = await nasFetch(endpoint, path, { ...opts, headers });
  let data;
  try { data = await res.json(); } catch { data = null; }
  if (!res.ok) throw Object.assign(
    new Error(data?.error || `NAS API: HTTP ${res.status}`),
    { status: res.status >= 500 ? 503 : 400 }
  );
  return data;
}

// ── NAS Health Check ──────────────────────────────────────────────────────
export async function checkNASHealth(endpoint, creds = {}) {
  try {
    const data = await nasJSON(endpoint, '/api/health', {}, creds);
    return { ok: true, version: data.version, hostname: data.hostname };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

// ── Storage Pool Discovery ────────────────────────────────────────────────
export async function discoverStoragePools(endpoint, creds = {}) {
  return nasJSON(endpoint, '/api/storage/pools', {}, creds);
}

// ── Volume Management ────────────────────────────────────────────────────
export async function listVolumes(endpoint, creds = {}) {
  return nasJSON(endpoint, '/api/volumes', {}, creds);
}

// ── Share Management ─────────────────────────────────────────────────────
export async function listShares(endpoint, creds = {}) {
  return nasJSON(endpoint, '/api/shares', {}, creds);
}

// ── Database helpers ──────────────────────────────────────────────────────
export function publicNAS(nas) {
  const n = { ...nas };
  delete n.credentials_encrypted;
  return n;
}

export function createNASServer(db, actorId, input) {
  const { name, endpoint, nasType = 'generic', description = '', location = '' } = input;
  if (!name?.trim()) throw Object.assign(new Error('NAS name is required.'), { status: 400 });
  if (!endpoint?.trim()) throw Object.assign(new Error('NAS endpoint is required.'), { status: 400 });
  if (!['truenas', 'synology', 'unraid', 'openmediavault', 'generic'].includes(nasType)) {
    throw Object.assign(new Error('Invalid NAS type.'), { status: 400 });
  }
  const id = randomUUID(), now = Date.now();
  db.prepare(`INSERT INTO nas_servers
    (id,name,endpoint,nas_type,description,location,status,created_at,updated_at)
    VALUES (?,?,?,?,?,?,?,?,?)`).run(id, name.trim(), endpoint.trim(), nasType, description, location, 'disconnected', now, now);
  audit(db, actorId, 'nas.create', id, name.trim());
  return db.prepare('SELECT * FROM nas_servers WHERE id=?').get(id);
}

export async function refreshNASStatus(db, nas) {
  const result = await checkNASHealth(nas.endpoint, {});
  const status = result.ok ? 'connected' : 'offline';
  const now = Date.now();
  db.prepare('UPDATE nas_servers SET status=?,last_health=?,last_error=?,updated_at=? WHERE id=?')
    .run(status, now, result.error || null, now, nas.id);
  return db.prepare('SELECT * FROM nas_servers WHERE id=?').get(nas.id);
}

/**
 * ArabiCloud — Docker Provider
 * Real Docker Engine API integration.
 * All operations go through the authenticated backend — never the browser.
 * No privileged containers, no host filesystem mounts, no arbitrary shell execution.
 */

function dockerHeaders(creds = {}) {
  const h = { 'Content-Type': 'application/json' };
  if (creds.token) h['Authorization'] = `Bearer ${creds.token}`;
  return h;
}

async function dockerFetch(endpoint, path, opts = {}, timeoutMs = 15000) {
  const base = endpoint.replace(/\/$/, '');
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(`${base}${path}`, { ...opts, signal: ctrl.signal });
    clearTimeout(timer);
    return res;
  } catch (err) {
    clearTimeout(timer);
    throw Object.assign(new Error(err.name === 'AbortError' ? 'Docker API timed out' : `Docker API error: ${err.message}`), { status: 503 });
  }
}

async function dockerJSON(endpoint, path, opts = {}, creds = {}) {
  const res = await dockerFetch(endpoint, path, { ...opts, headers: { ...dockerHeaders(creds), ...(opts.headers||{}) } });
  let data;
  try { data = await res.json(); } catch { data = null; }
  if (!res.ok) throw Object.assign(new Error(data?.message || `Docker: HTTP ${res.status}`), { status: res.status >= 500 ? 503 : 400 });
  return data;
}

// ── Container Operations ───────────────────────────────────────────────────

export async function dockerVersion(endpoint, creds = {}) {
  return dockerJSON(endpoint, '/version', { headers: dockerHeaders(creds) });
}

export async function dockerInfo(endpoint, creds = {}) {
  return dockerJSON(endpoint, '/info', { headers: dockerHeaders(creds) });
}

export async function listContainers(endpoint, creds = {}, all = true) {
  return dockerJSON(endpoint, `/containers/json?all=${all}`, { headers: dockerHeaders(creds) });
}

export async function inspectContainer(endpoint, creds = {}, containerId) {
  return dockerJSON(endpoint, `/containers/${containerId}/json`, { headers: dockerHeaders(creds) });
}

export async function containerStats(endpoint, creds = {}, containerId) {
  return dockerJSON(endpoint, `/containers/${containerId}/stats?stream=false`, { headers: dockerHeaders(creds) }, 10000);
}

export async function createContainer(endpoint, creds = {}, config) {
  const {
    name, image, cpuShares = 1024, memoryMB = 512,
    ports = [], env = [], restartPolicy = 'unless-stopped',
    volumes = [], labels = {},
  } = config;

  // Validate image name — no shell injection via image field
  if (!/^[a-zA-Z0-9][a-zA-Z0-9._\-:/]*(@sha256:[a-f0-9]+)?$/.test(image)) {
    throw Object.assign(new Error('Invalid image name format.'), { status: 400 });
  }

  // Port bindings — validate each port
  const portBindings = {};
  const exposedPorts = {};
  for (const p of ports) {
    const [hostPort, containerPort, protocol = 'tcp'] = String(p).split(/[:/]/);
    const hp = parseInt(hostPort), cp = parseInt(containerPort || hostPort);
    if (!hp || hp < 1 || hp > 65535 || !cp || cp < 1 || cp > 65535) throw Object.assign(new Error(`Invalid port mapping: ${p}`), { status: 400 });
    const key = `${cp}/${protocol}`;
    portBindings[key] = [{ HostPort: String(hp) }];
    exposedPorts[key] = {};
  }

  // Validate env vars — key=value format only
  const envArray = [];
  for (const e of env) {
    if (!/^[A-Za-z_][A-Za-z0-9_]*=/.test(String(e))) throw Object.assign(new Error(`Invalid env var: ${e}`), { status: 400 });
    envArray.push(String(e));
  }

  const body = {
    Image: image,
    Env: envArray,
    ExposedPorts: exposedPorts,
    Labels: { 'arabicloud.managed': 'true', ...labels },
    HostConfig: {
      // CPU: cpuShares maps to relative weight (no hard limits without cgroups v2)
      CpuShares: Math.max(2, Math.min(cpuShares * 1024, 262144)),
      Memory: memoryMB * 1024 * 1024,
      MemorySwap: memoryMB * 1024 * 1024, // disable swap
      PortBindings: portBindings,
      RestartPolicy: { Name: restartPolicy === 'no' ? 'no' : restartPolicy === 'always' ? 'always' : restartPolicy === 'on-failure' ? 'on-failure' : 'unless-stopped' },
      // Security hardening — no host access
      Privileged: false,
      NetworkMode: 'bridge',
      ReadonlyRootfs: false,
      CapDrop: ['ALL'],
      CapAdd: ['NET_BIND_SERVICE'],
      SecurityOpt: ['no-new-privileges:true'],
      Binds: [], // no host mounts
    },
  };

  const nameParam = name ? `?name=${encodeURIComponent(name.replace(/[^a-zA-Z0-9_.-]/g, '_'))}` : '';
  return dockerJSON(endpoint, `/containers/create${nameParam}`, {
    method: 'POST', headers: dockerHeaders(creds), body: JSON.stringify(body),
  }, creds);
}

export async function startContainer(endpoint, creds = {}, containerId) {
  const res = await dockerFetch(endpoint, `/containers/${containerId}/start`, {
    method: 'POST', headers: dockerHeaders(creds),
  });
  if (res.status === 304) return { ok: true, alreadyRunning: true };
  if (!res.ok) { const d = await res.json().catch(() => ({})); throw Object.assign(new Error(d.message || `Docker start failed: HTTP ${res.status}`), { status: 503 }); }
  return { ok: true };
}

export async function stopContainer(endpoint, creds = {}, containerId, timeoutSec = 10) {
  const res = await dockerFetch(endpoint, `/containers/${containerId}/stop?t=${timeoutSec}`, {
    method: 'POST', headers: dockerHeaders(creds),
  }, (timeoutSec + 5) * 1000);
  if (res.status === 304) return { ok: true, alreadyStopped: true };
  if (!res.ok) { const d = await res.json().catch(() => ({})); throw Object.assign(new Error(d.message || `Docker stop failed: HTTP ${res.status}`), { status: 503 }); }
  return { ok: true };
}

export async function restartContainer(endpoint, creds = {}, containerId, timeoutSec = 10) {
  const res = await dockerFetch(endpoint, `/containers/${containerId}/restart?t=${timeoutSec}`, {
    method: 'POST', headers: dockerHeaders(creds),
  }, (timeoutSec + 10) * 1000);
  if (!res.ok) { const d = await res.json().catch(() => ({})); throw Object.assign(new Error(d.message || `Docker restart failed: HTTP ${res.status}`), { status: 503 }); }
  return { ok: true };
}

export async function deleteContainer(endpoint, creds = {}, containerId, force = false) {
  const res = await dockerFetch(endpoint, `/containers/${containerId}?force=${force}&v=true`, {
    method: 'DELETE', headers: dockerHeaders(creds),
  });
  if (res.status === 404) return { ok: true, notFound: true };
  if (!res.ok) { const d = await res.json().catch(() => ({})); throw Object.assign(new Error(d.message || `Docker delete failed: HTTP ${res.status}`), { status: 503 }); }
  return { ok: true };
}

export async function getContainerLogs(endpoint, creds = {}, containerId, lines = 100) {
  const res = await dockerFetch(endpoint, `/containers/${containerId}/logs?stdout=true&stderr=true&tail=${lines}&timestamps=true`, {
    headers: dockerHeaders(creds),
  }, 10000);
  if (!res.ok) { const d = await res.json().catch(() => ({})); throw Object.assign(new Error(d.message || `Docker logs failed: HTTP ${res.status}`), { status: 503 }); }
  // Docker log stream has 8-byte header per line — strip it
  const buf = Buffer.from(await res.arrayBuffer());
  const lines_out = [];
  let i = 0;
  while (i + 8 <= buf.length) {
    const size = buf.readUInt32BE(i + 4);
    if (size === 0) { i += 8; continue; }
    if (i + 8 + size > buf.length) break;
    lines_out.push(buf.slice(i + 8, i + 8 + size).toString('utf8').replace(/\n$/, ''));
    i += 8 + size;
  }
  return lines_out.slice(-lines);
}

export async function pullImage(endpoint, creds = {}, image) {
  if (!/^[a-zA-Z0-9][a-zA-Z0-9._\-:/]*(@sha256:[a-f0-9]+)?$/.test(image)) {
    throw Object.assign(new Error('Invalid image name.'), { status: 400 });
  }
  const res = await dockerFetch(endpoint, `/images/create?fromImage=${encodeURIComponent(image)}`, {
    method: 'POST', headers: dockerHeaders(creds),
  }, 120000); // 2 min for large images
  if (!res.ok) { const d = await res.json().catch(() => ({})); throw Object.assign(new Error(d.message || `Image pull failed: HTTP ${res.status}`), { status: 503 }); }
  // Consume stream to completion
  const reader = res.body?.getReader();
  const lines = [];
  if (reader) {
    const dec = new TextDecoder();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      lines.push(dec.decode(value));
    }
  }
  return { ok: true, log: lines.join('') };
}

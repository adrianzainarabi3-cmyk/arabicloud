// ArabiCloud — Centralized branding configuration
export const BRAND = {
  name: 'ArabiCloud',
  subtitle: 'Cloud Infrastructure Management',
  description: 'Multi-Node VPS and Container Management',
  creator: 'Adrian Zain Arabi',
  version: '2.0.0',
  sessionCookie: 'arabicloud_session',
};

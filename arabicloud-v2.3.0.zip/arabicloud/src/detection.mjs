/**
 * ArabiCloud — Local Node Detection Service
 * Safely probes the host machine for infrastructure capabilities.
 * Never executes arbitrary shell commands from user input.
 * Never exposes secrets, private keys, or full filesystem contents.
 */
import { readFile, readdir, stat, access } from 'node:fs/promises';
import { constants as fsConstants } from 'node:fs';
import { cpus, totalmem, freemem, networkInterfaces, hostname as osHostname } from 'node:os';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { randomUUID } from 'node:crypto';
import { audit, transaction } from './database.mjs';

const execFileAsync = promisify(execFile);

// Safe exec with hard timeout — only for read-only system tools, never user input
async function safeExec(cmd, args = [], timeoutMs = 5000) {
  try {
    const { stdout, stderr } = await execFileAsync(cmd, args, {
      timeout: timeoutMs, maxBuffer: 256 * 1024, env: { PATH: '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin' },
    });
    return { ok: true, stdout: stdout.trim(), stderr: stderr.trim() };
  } catch (err) {
    return { ok: false, error: err.message, code: err.code };
  }
}

async function fileExists(path) {
  try { await access(path, fsConstants.F_OK); return true; } catch { return false; }
}

async function canRead(path) {
  try { await access(path, fsConstants.R_OK); return true; } catch { return false; }
}

// ── Environment Detection ──────────────────────────────────────────────────
async function detectEnvironment() {
  const env = { type: 'linux', inDocker: false, inVM: false, restricted: false };
  // Docker container detection
  if (await fileExists('/.dockerenv')) { env.inDocker = true; env.type = 'docker-container'; }
  try {
    const cgroup = await readFile('/proc/1/cgroup', 'utf8');
    if (cgroup.includes('docker') || cgroup.includes('containerd')) { env.inDocker = true; env.type = 'docker-container'; }
    if (cgroup.includes('lxc')) { env.type = 'lxc-container'; env.restricted = true; }
  } catch {}
  // VM detection (non-destructive)
  try {
    const dmi = await readFile('/sys/class/dmi/id/product_name', 'utf8').catch(() => '');
    if (/kvm|qemu|virtualbox|vmware|xen|hyper-v/i.test(dmi)) env.inVM = true;
  } catch {}
  // Restricted/unprivileged check
  if (!await fileExists('/dev/kvm') && !env.inDocker) env.kvmRestricted = true;
  return env;
}

// ── CPU Detection ──────────────────────────────────────────────────────────
async function detectCPU() {
  const cores = cpus();
  const model = cores[0]?.model?.trim() || 'Unknown';
  const count = cores.length;
  // CPU utilization from /proc/stat (safe, read-only)
  let utilization = null;
  try {
    const stat1 = await readFile('/proc/stat', 'utf8');
    await new Promise(r => setTimeout(r, 500));
    const stat2 = await readFile('/proc/stat', 'utf8');
    const parse = s => { const m = s.match(/^cpu\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)/m); if (!m) return null; const vals = m.slice(1).map(Number); return { total: vals.reduce((a,b)=>a+b,0), idle: vals[3] }; };
    const s1 = parse(stat1), s2 = parse(stat2);
    if (s1 && s2) { const dtotal = s2.total - s1.total; const didle = s2.idle - s1.idle; utilization = dtotal > 0 ? Math.round((1 - didle/dtotal)*100) : 0; }
  } catch {}
  return { model, cores: count, utilization };
}

// ── RAM Detection ──────────────────────────────────────────────────────────
async function detectRAM() {
  // Primary: os.totalmem/freemem
  let total = totalmem();
  let free = freemem();
  // Fallback: /proc/meminfo (more reliable on VPS/containers)
  if (!total || total < 1024) {
    try {
      const meminfo = await readFile('/proc/meminfo', 'utf8');
      const parseKB = key => {
        const m = meminfo.match(new RegExp(`^${key}:\s+(\d+)\s+kB`, 'm'));
        return m ? parseInt(m[1]) * 1024 : 0;
      };
      total = parseKB('MemTotal') || total;
      const available = parseKB('MemAvailable') || parseKB('MemFree');
      free = available || free;
    } catch {}
  }
  return {
    totalBytes: total, freeBytes: free, usedBytes: total - free,
    totalMB: Math.round(total/1024/1024), freeMB: Math.round(free/1024/1024),
  };
}

// ── Disk Detection ──────────────────────────────────────────────────────────
async function detectDisk() {
  const disks = [];
  // Read /proc/mounts to find real filesystems (safe, no exec)
  try {
    const mounts = await readFile('/proc/mounts', 'utf8');
    const seen = new Set();
    for (const line of mounts.split('\n')) {
      const [device, mountpoint, fstype] = line.split(' ');
      if (!device || !mountpoint || seen.has(mountpoint)) continue;
      if (['tmpfs','devtmpfs','sysfs','proc','devpts','cgroup','overlay','squashfs','nsfs','binfmt_misc'].includes(fstype)) continue;
      if (!device.startsWith('/dev/') && !device.startsWith('//')) continue;
      seen.add(mountpoint);
      try {
        const result = await safeExec('df', ['-B1', mountpoint], 3000);
        if (result.ok) {
          const lines = result.stdout.split('\n');
          const parts = lines[1]?.split(/\s+/);
          if (parts && parts.length >= 6) {
            disks.push({ device, mountpoint, fstype, totalBytes: parseInt(parts[1])||0, usedBytes: parseInt(parts[2])||0, freeBytes: parseInt(parts[3])||0 });
          }
        }
      } catch {}
    }
  } catch {}
  return disks;
}

// ── Network Detection ─────────────────────────────────────────────────────
function detectNetwork() {
  const ifaces = networkInterfaces();
  const interfaces = [];
  for (const [name, addrs] of Object.entries(ifaces || {})) {
    if (!addrs) continue;
    for (const addr of addrs) {
      if (!addr.internal) interfaces.push({ name, address: addr.address, family: addr.family, cidr: addr.cidr });
    }
  }
  return interfaces;
}

// ── Docker Detection ───────────────────────────────────────────────────────
async function detectDocker() {
  const result = { installed: false, daemonRunning: false, socketAccessible: false, status: 'not_installed', version: null, error: null };

  // Check if docker binary exists
  const dockerPath = await safeExec('which', ['docker'], 2000);
  if (!dockerPath.ok || !dockerPath.stdout) { result.error = 'Docker not installed'; return result; }
  result.installed = true;

  // Check docker socket accessibility — read-only probe
  const socketPaths = ['/var/run/docker.sock', '/run/docker.sock'];
  let socketPath = null;
  for (const p of socketPaths) { if (await canRead(p)) { socketPath = p; break; } }

  if (!socketPath) {
    result.status = 'detected';
    result.error = 'Docker socket not accessible — add current user to docker group or run with appropriate permissions';
    return result;
  }
  result.socketAccessible = true;

  // Try connecting to Docker daemon via TCP or socket
  // We use the CLI for a safe read-only version check
  const versionResult = await safeExec('docker', ['version', '--format', '{{json .}}'], 5000);
  if (!versionResult.ok) {
    result.status = 'detected';
    result.error = `Docker daemon not responding: ${versionResult.error}`;
    return result;
  }
  result.daemonRunning = true;

  try {
    const v = JSON.parse(versionResult.stdout);
    result.version = v.Server?.Version || v.Client?.Version || null;
  } catch { result.version = 'unknown'; }

  // Safe read-only info check
  const infoResult = await safeExec('docker', ['info', '--format', '{{json .}}'], 5000);
  let storageDriver = null;
  if (infoResult.ok) {
    try { const info = JSON.parse(infoResult.stdout); storageDriver = info.Driver; } catch {}
  }
  result.storageDriver = storageDriver;
  result.status = 'ready';
  return result;
}

// ── KVM/libvirt Detection ──────────────────────────────────────────────────
async function detectKVM() {
  const result = { kvmDevicePresent: false, hwVirtEnabled: false, libvirtInstalled: false, libvirtRunning: false, status: 'not_available', error: null };

  // Check /dev/kvm
  result.kvmDevicePresent = await fileExists('/dev/kvm');
  if (!result.kvmDevicePresent) { result.error = '/dev/kvm not present — hardware virtualization may be disabled or unavailable in this environment'; return result; }

  // Check hardware virt flags in /proc/cpuinfo (safe, read-only)
  try {
    const cpuinfo = await readFile('/proc/cpuinfo', 'utf8');
    result.hwVirtEnabled = /vmx|svm/.test(cpuinfo);
  } catch {}

  if (!result.hwVirtEnabled) { result.status = 'detected'; result.error = 'Hardware virtualization flags (vmx/svm) not present in CPU'; return result; }

  // Check virsh/libvirt
  const virshPath = await safeExec('which', ['virsh'], 2000);
  result.libvirtInstalled = virshPath.ok && !!virshPath.stdout;
  if (!result.libvirtInstalled) { result.status = 'detected'; result.error = 'libvirt/virsh not installed'; return result; }

  // Try a safe read-only libvirt connection
  const virshResult = await safeExec('virsh', ['version', '--daemon'], 5000);
  if (!virshResult.ok) { result.status = 'detected'; result.error = `libvirt daemon not responding: ${virshResult.error}`; return result; }
  result.libvirtRunning = true;

  // List storage pools (safe, read-only)
  const poolsResult = await safeExec('virsh', ['pool-list', '--all'], 5000);
  result.storagePools = poolsResult.ok ? poolsResult.stdout : null;
  result.status = 'ready';
  return result;
}

// ── Proxmox Detection ──────────────────────────────────────────────────────
async function detectProxmox() {
  const result = { installed: false, apiReachable: false, status: 'not_installed', version: null };
  const proxmoxBin = await safeExec('which', ['pvesh'], 2000);
  if (!proxmoxBin.ok || !proxmoxBin.stdout) { result.error = 'Proxmox not installed on this host'; return result; }
  result.installed = true;
  // Safe read-only version check
  const versionResult = await safeExec('pvesh', ['get', 'version', '--output-format', 'json'], 5000);
  if (versionResult.ok) {
    try { const v = JSON.parse(versionResult.stdout); result.version = v.version; result.apiReachable = true; result.status = 'ready'; } catch {}
  }
  if (!result.apiReachable) { result.status = 'detected'; result.error = 'Proxmox API not responding'; }
  return result;
}

// ── NAS / Storage Detection ────────────────────────────────────────────────
async function detectNAS() {
  const result = { services: [], protocols: [] };
  // Check for common NAS services (safe, read-only)
  const services = [
    { name: 'samba', bin: 'smbd', protocol: 'SMB' },
    { name: 'nfs', bin: 'rpcbind', protocol: 'NFS' },
    { name: 'vsftpd', bin: 'vsftpd', protocol: 'FTP' },
    { name: 'openssh-sftp', bin: 'sshd', protocol: 'SFTP' },
  ];
  for (const svc of services) {
    const check = await safeExec('which', [svc.bin], 2000);
    if (check.ok && check.stdout) { result.services.push(svc.name); result.protocols.push(svc.protocol); }
  }
  return result;
}

// ── Main Detection Entry Point ─────────────────────────────────────────────
export async function detectLocalNode() {
  const [environment, cpu, disk, docker, kvm, proxmox, nas, ram] = await Promise.all([
    detectEnvironment(), detectCPU(), detectDisk(), detectDocker(), detectKVM(), detectProxmox(), detectNAS(), detectRAM(),
  ]);
  const network = detectNetwork();
  const hn = osHostname();
  const primaryDisk = disk.find(d => d.mountpoint === '/') || disk[0] || null;

  // Determine overall provider status
  const providerStatuses = {
    docker: docker.status,
    kvm: kvm.status,
    proxmox: proxmox.status,
  };

  // Compute overall node status
  // A local node is always at least 'detected' since we can read its system info
  const anyReady = Object.values(providerStatuses).includes('ready');
  const anyDetected = Object.values(providerStatuses).some(s => s === 'detected' || s === 'ready');
  let overallStatus = 'detected'; // local node is always reachable
  if (anyReady) overallStatus = 'connected';

  const warnings = [];
  if (environment.inDocker) warnings.push('ArabiCloud is running inside a Docker container. Host resource access may be limited.');
  if (!docker.daemonRunning && docker.installed) warnings.push('Docker is installed but the daemon is not accessible. Check socket permissions.');
  if (!kvm.kvmDevicePresent) warnings.push('/dev/kvm is not available. KVM provisioning requires hardware virtualization support.');
  if (!proxmox.installed) warnings.push('Proxmox is not installed on this host.');

  return {
    hostname: hn,
    os: `${process.platform} ${(await safeExec('uname', ['-r'], 2000)).stdout || ''}`.trim(),
    environment,
    cpu,
    ram,
    disk: { primary: primaryDisk, all: disk },
    network,
    docker,
    kvm,
    proxmox,
    nas,
    providerStatuses,
    overallStatus,
    warnings,
    detectedAt: Date.now(),
  };
}

// ── Register/Update Local Node in DB ─────────────────────────────────────────
export function registerOrUpdateLocalNode(db, detection, actorId = null, displayName = 'Local Node') {
  const ram = detection.ram;
  const disk = detection.disk.primary;
  const ramTotalMB = Math.round(ram.totalBytes / 1024 / 1024);
  const diskTotalGB = disk ? Math.round(disk.totalBytes / 1024 / 1024 / 1024) : 0;

  // Determine primary provider type for the node record
  const primaryProvider = detection.docker.status === 'ready' ? 'docker'
    : detection.kvm.status === 'ready' ? 'kvm'
    : detection.proxmox.status === 'ready' ? 'proxmox'
    : 'docker'; // default even if not ready — will show as 'detected'

  const capabilitiesJson = JSON.stringify({
    docker: detection.docker, kvm: detection.kvm, proxmox: detection.proxmox,
    nas: detection.nas, environment: detection.environment, network: detection.network,
  });

  const primaryIP = detection.network.find(n => n.family === 'IPv4')?.address || '127.0.0.1';
  const now = Date.now();

  return transaction(db, () => {
    // Check for existing local node (idempotent — never duplicate)
    let existing = db.prepare("SELECT * FROM nodes WHERE is_local=1").get();

    if (existing) {
      // Update existing local node — preserve ID and workload assignments
      db.prepare(`UPDATE nodes SET
        name=COALESCE(NULLIF(?,name),name), hostname=?, ip_address=?, os_info=?,
        cpu_cores=?, ram_total=?, disk_total=?,
        status=?, provider_statuses=?, detection_data=?,
        last_heartbeat=?, updated_at=?
        WHERE id=?`).run(
        displayName, detection.hostname, primaryIP,
        detection.os, detection.cpu.cores, ramTotalMB, diskTotalGB,
        detection.overallStatus, JSON.stringify(detection.providerStatuses), capabilitiesJson,
        now, now, existing.id
      );
      if (actorId) audit(db, actorId, 'node.local_detection', existing.id, `Re-detected: ${detection.overallStatus}`);
      return db.prepare('SELECT * FROM nodes WHERE id=?').get(existing.id);
    } else {
      // Create new local node with stable ID
      const id = randomUUID();
      db.prepare(`INSERT INTO nodes
        (id,name,hostname,ip_address,api_endpoint,provider_type,os_info,architecture,
         cpu_cores,ram_total,disk_total,status,scheduling_enabled,maintenance_mode,
         is_local,provider_statuses,detection_data,last_heartbeat,created_at,updated_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
        id, displayName, detection.hostname, primaryIP,
        `http://${primaryIP}:2375`, primaryProvider,
        detection.os, detection.cpu.model || 'x86_64',
        detection.cpu.cores, ramTotalMB, diskTotalGB,
        detection.overallStatus, 1, 0,
        1, JSON.stringify(detection.providerStatuses), capabilitiesJson,
        now, now, now
      );
      if (actorId) audit(db, actorId, 'node.local_detected', id, `Local node registered: ${detection.overallStatus}`);
      return db.prepare('SELECT * FROM nodes WHERE id=?').get(id);
    }
  });
}

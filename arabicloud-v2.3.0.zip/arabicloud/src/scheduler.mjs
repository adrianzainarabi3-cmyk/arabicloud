/**
 * ArabiCloud — Resource Scheduler
 * Selects eligible nodes and reserves resources atomically.
 * Prevents concurrent over-allocation via SQLite transactions + row-level checks.
 */
import { transaction } from './database.mjs';

/**
 * Find the best eligible node for a workload.
 * Provider must be compatible, node must be in 'connected' or 'ready' status (mapped from our status field),
 * scheduling must be enabled, and resources must be available.
 */
export function schedulerFindNode(db, providerType, cpuNeeded, ramNeeded, diskNeeded, preferredNodeId = null) {
  // Validate provider type matches node capabilities
  const validStatuses = ['online', 'connected', 'ready'];

  let nodes;
  if (preferredNodeId) {
    nodes = db.prepare(
      `SELECT * FROM nodes WHERE id=? AND provider_type=? AND status IN (${validStatuses.map(()=>'?').join(',')}) AND scheduling_enabled=1 AND maintenance_mode=0`
    ).all(preferredNodeId, providerType, ...validStatuses);
  } else {
    nodes = db.prepare(
      `SELECT * FROM nodes WHERE provider_type=? AND status IN (${validStatuses.map(()=>'?').join(',')}) AND scheduling_enabled=1 AND maintenance_mode=0`
    ).all(providerType, ...validStatuses);
  }

  const eligible = nodes.filter(n =>
    (n.cpu_cores - n.cpu_allocated) >= cpuNeeded &&
    (n.ram_total - n.ram_allocated) >= ramNeeded &&
    (n.disk_total - n.disk_allocated) >= diskNeeded
  );

  if (eligible.length === 0) return null;

  // Best-fit: prefer the node with LEAST free RAM (maximise utilisation, minimise fragmentation)
  eligible.sort((a, b) => {
    const aFree = (a.ram_total - a.ram_allocated) / Math.max(a.ram_total, 1);
    const bFree = (b.ram_total - b.ram_allocated) / Math.max(b.ram_total, 1);
    return aFree - bFree;
  });

  return eligible[0];
}

/**
 * Atomically reserve resources on a node.
 * Runs inside a transaction — re-checks capacity inside the lock.
 */
export function reserveResources(db, nodeId, cpu, ram, disk) {
  return transaction(db, () => {
    // Re-read inside transaction for concurrency safety
    const node = db.prepare('SELECT * FROM nodes WHERE id=?').get(nodeId);
    if (!node) throw Object.assign(new Error('Node not found.'), { status: 404 });
    if ((node.cpu_cores - node.cpu_allocated) < cpu)
      throw Object.assign(new Error(`Insufficient CPU on node ${node.name} (need ${cpu}, have ${node.cpu_cores - node.cpu_allocated}).`), { status: 409 });
    if ((node.ram_total - node.ram_allocated) < ram)
      throw Object.assign(new Error(`Insufficient RAM on node ${node.name} (need ${ram}MB, have ${node.ram_total - node.ram_allocated}MB).`), { status: 409 });
    if ((node.disk_total - node.disk_allocated) < disk)
      throw Object.assign(new Error(`Insufficient disk on node ${node.name} (need ${disk}GB, have ${node.disk_total - node.disk_allocated}GB).`), { status: 409 });
    db.prepare(
      'UPDATE nodes SET cpu_allocated=cpu_allocated+?,ram_allocated=ram_allocated+?,disk_allocated=disk_allocated+?,updated_at=? WHERE id=?'
    ).run(cpu, ram, disk, Date.now(), nodeId);
    return node;
  });
}

/**
 * Release previously reserved resources.
 * Safe to call even if node was deleted (no-op).
 */
export function releaseResources(db, nodeId, cpu, ram, disk) {
  db.prepare(
    'UPDATE nodes SET cpu_allocated=MAX(0,cpu_allocated-?),ram_allocated=MAX(0,ram_allocated-?),disk_allocated=MAX(0,disk_allocated-?),updated_at=? WHERE id=?'
  ).run(cpu, ram, disk, Date.now(), nodeId);
}

/**
 * Validate user quotas before scheduling.
 */
export function checkUserQuota(db, userId, workloadType, settings) {
  const meta = db.prepare('SELECT * FROM user_meta WHERE user_id=?').get(userId);
  const existing = db.prepare(
    "SELECT COUNT(*) AS c FROM workloads WHERE owner_user_id=? AND status NOT IN ('deleted')"
  ).get(userId).c;
  const limit = meta?.machine_limit ?? settings.maxMachinesPerUser ?? 5;
  if (limit > 0 && existing >= limit) {
    throw Object.assign(new Error(`Machine limit reached (${existing}/${limit}). Contact an administrator.`), { status: 409 });
  }
}

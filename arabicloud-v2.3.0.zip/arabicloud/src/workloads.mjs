/**
 * ArabiCloud — Workload Management (Containers + VPS)
 */
import { randomUUID } from 'node:crypto';
import { audit, transaction } from './database.mjs';
import { schedulerFindNode, reserveNodeResources, releaseNodeResources } from './nodes.mjs';

export function publicWorkload(w) {
  return {
    id: w.id, ownerUserId: w.owner_user_id, workloadType: w.workload_type,
    providerType: w.provider_type, nodeId: w.node_id, providerResourceId: w.provider_resource_id,
    name: w.name, image: w.image, osTemplate: w.os_template,
    cpuAllocated: w.cpu_allocated, ramAllocated: w.ram_allocated, diskAllocated: w.disk_allocated,
    networkConfig: JSON.parse(w.network_config || '{}'),
    ports: JSON.parse(w.ports || '[]'),
    status: w.status, providerStatus: w.provider_status, ipAddress: w.ip_address,
    restartPolicy: w.restart_policy, createdAt: w.created_at, updatedAt: w.updated_at,
  };
}

export function createWorkload(db, actorId, input) {
  const {
    workloadType, providerType, nodeId: preferredNodeId, name,
    image = '', osTemplate = '', cpuAllocated = 1, ramAllocated = 512, diskAllocated = 10,
    networkConfig = {}, envVars = {}, ports = [], restartPolicy = 'unless-stopped',
  } = input;
  if (!['container','vps'].includes(workloadType)) throw Object.assign(new Error('workloadType must be container or vps.'), { status: 400 });
  if (!['docker','kvm','proxmox'].includes(providerType)) throw Object.assign(new Error('Invalid providerType.'), { status: 400 });
  if (!name?.trim()) throw Object.assign(new Error('Workload name is required.'), { status: 400 });
  if (workloadType === 'container' && !image) throw Object.assign(new Error('Container image is required.'), { status: 400 });
  if (workloadType === 'vps' && !osTemplate) throw Object.assign(new Error('OS template is required for VPS.'), { status: 400 });
  if (workloadType === 'container' && providerType !== 'docker') throw Object.assign(new Error('Containers require docker provider.'), { status: 400 });
  if (workloadType === 'vps' && providerType === 'docker') throw Object.assign(new Error('VPS instances cannot use docker provider.'), { status: 400 });

  return transaction(db, () => {
    const node = schedulerFindNode(db, providerType, cpuAllocated, ramAllocated, diskAllocated, preferredNodeId || null);
    if (!node) throw Object.assign(new Error('No compatible nodes available with sufficient capacity.'), { status: 503 });
    reserveNodeResources(db, node.id, cpuAllocated, ramAllocated, diskAllocated);
    const id = randomUUID(), now = Date.now();
    db.prepare(`INSERT INTO workloads (id,owner_user_id,workload_type,provider_type,node_id,name,image,os_template,cpu_allocated,ram_allocated,disk_allocated,network_config,env_vars,ports,restart_policy,status,created_at,updated_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      id, actorId, workloadType, providerType, node.id, name.trim(), image, osTemplate,
      cpuAllocated, ramAllocated, diskAllocated,
      JSON.stringify(networkConfig), JSON.stringify(envVars), JSON.stringify(ports),
      restartPolicy, 'pending', now, now
    );
    const jobId = randomUUID();
    db.prepare('INSERT INTO provisioning_jobs(id,workload_id,node_id,user_id,job_type,status,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?)').run(
      jobId, id, node.id, actorId, `${workloadType}.create`, 'queued', now, now
    );
    audit(db, actorId, `workload.create`, id, `${name} on ${node.name}`);
    return { workload: db.prepare('SELECT * FROM workloads WHERE id=?').get(id), jobId, nodeId: node.id };
  });
}

export function deleteWorkload(db, actorId, workloadId) {
  const w = db.prepare('SELECT * FROM workloads WHERE id=?').get(workloadId);
  if (!w) throw Object.assign(new Error('Workload not found.'), { status: 404 });
  transaction(db, () => {
    db.prepare("UPDATE workloads SET status='deleted',updated_at=? WHERE id=?").run(Date.now(), workloadId);
    if (w.node_id) releaseNodeResources(db, w.node_id, w.cpu_allocated, w.ram_allocated, w.disk_allocated);
    audit(db, actorId, 'workload.delete', workloadId, w.name);
  });
}

export function updateWorkloadStatus(db, workloadId, status, providerStatus = null, ipAddress = null) {
  const now = Date.now();
  db.prepare('UPDATE workloads SET status=?,provider_status=?,ip_address=COALESCE(?,ip_address),updated_at=? WHERE id=?').run(status, providerStatus, ipAddress, now, workloadId);
}
